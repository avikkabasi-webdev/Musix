package com.lastwave.app.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.colorControls
import com.kyant.backdrop.highlight.Highlight

/**
 * Always-on "frosted glass" recipe, matching the Genus web app:
 *   background: bg @ 42% + backdrop blur(18) + saturate(1.6) + 1px hairline border.
 *
 * Unlike [liquidGlass], this does not depend on the Liquid Glass experimental
 * toggle - it only needs a capable device (Android 12+, hardware accelerated).
 */

/** Marks content as the layer that [genusGlass] surfaces blur behind them. */
@Composable
fun Modifier.glassSource(backdrop: LayerBackdrop?): Modifier =
    if (backdrop != null && isDeviceGlassCapable()) this.layerBackdrop(backdrop) else this

@Composable
fun Modifier.genusGlass(
    backdrop: Backdrop?,
    shape: Shape,
    tintAlpha: Float = 0.42f,
): Modifier {
    val isDark = LocalIsDarkTheme.current
    val base = MaterialTheme.colorScheme.background
    val rim = if (isDark) Color.White.copy(alpha = 0.16f) else Color.Black.copy(alpha = 0.10f)
    val s = lensSafeGlassShape(shape)
    val capable = isDeviceGlassCapable()
    val body: Modifier = if (backdrop != null && capable) {
        Modifier.drawBackdrop(
            backdrop = backdrop,
            shape = { s },
            highlight = { Highlight.Default },
            effects = {
                colorControls(
                    brightness = 0f,
                    contrast = 1f,
                    saturation = 1.6f,
                )
                blur(18f.dp.toPx())
            },
            onDrawBackdrop = { drawBackdrop -> drawBackdrop() },
            onDrawSurface = { drawRect(base.copy(alpha = tintAlpha)) },
            layerBlock = null,
        )
    } else {
        // No real blur available: a denser translucent fill keeps it readable.
        Modifier.clip(s).background(base.copy(alpha = 0.78f))
    }
    return this.then(body).border(1.dp, rim, s)
}
