package org.futo.inputmethod.latin.uix.actions

import android.content.SharedPreferences
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.booleanResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.edit
import org.futo.inputmethod.latin.R
import org.futo.inputmethod.latin.settings.Settings
import org.futo.inputmethod.latin.uix.Action
import org.futo.inputmethod.latin.uix.ActionWindow
import org.futo.inputmethod.latin.uix.PreferenceUtils
import org.futo.inputmethod.latin.uix.isDirectBootUnlocked
import org.futo.inputmethod.latin.uix.settings.SettingsActivity
import org.futo.inputmethod.latin.uix.theme.Typography

private data class QuickToggle(
    val key: String,
    val default: @Composable () -> Boolean,
    @DrawableRes val icon: Int,
    @StringRes val label: Int
)

private val QuickToggles = listOf(
    QuickToggle(Settings.PREF_AUTO_CORRECTION, { true }, R.drawable.check, R.string.quick_settings_autocorrect),
    QuickToggle(Settings.PREF_SHOW_SUGGESTIONS, { true }, R.drawable.text_prediction, R.string.quick_settings_predictions),
    QuickToggle(Settings.PREF_GESTURE_INPUT, { true }, R.drawable.swipe_icon, R.string.quick_settings_swipe),
    QuickToggle(Settings.PREF_ENABLE_NUMBER_ROW, { false }, R.drawable.numpad, R.string.quick_settings_number_row),
    QuickToggle(
        Settings.PREF_VIBRATE_ON,
        { booleanResource(R.bool.config_default_vibration_enabled) },
        R.drawable.quick_vibrate,
        R.string.quick_settings_haptic
    ),
    QuickToggle(
        Settings.PREF_SOUND_ON,
        { booleanResource(R.bool.config_default_sound_enabled) },
        R.drawable.quick_volume,
        R.string.quick_settings_sound
    ),
)

@Composable
private fun QuickToggleTile(
    prefs: SharedPreferences,
    toggle: QuickToggle,
    modifier: Modifier = Modifier
) {
    val default = toggle.default()
    var enabled by remember { mutableStateOf(prefs.getBoolean(toggle.key, default)) }

    val background = if(enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val foreground = if(enabled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = modifier
            .height(76.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .clickable {
                enabled = !enabled
                prefs.edit { putBoolean(toggle.key, enabled) }
            }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            painterResource(toggle.icon),
            contentDescription = null,
            tint = foreground,
            modifier = Modifier.size(24.dp)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(toggle.label),
            style = Typography.Small,
            color = foreground,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

val QuickSettingsAction = Action(
    icon = R.drawable.settings,
    name = R.string.action_quick_settings_title,
    simplePressImpl = null,
    canShowKeyboard = true,
    windowImpl = { manager, _ ->
        object : ActionWindow() {
            override val onlyShowAboveKeyboard: Boolean = true

            @Composable
            override fun windowName(): String {
                return stringResource(R.string.action_quick_settings_title)
            }

            @Composable
            override fun WindowContents(keyboardShown: Boolean) {
                val context = LocalContext.current
                val prefs = remember { PreferenceUtils.getDefaultSharedPreferences(context) }

                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    QuickToggles.chunked(3).forEach { rowItems ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { toggle ->
                                QuickToggleTile(prefs, toggle, Modifier.weight(1.0f))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    Text(
                        stringResource(R.string.quick_settings_all_settings),
                        style = Typography.Body.Regular,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if(context.isDirectBootUnlocked && !manager.isDeviceLocked()) {
                                    SettingsActivity.openToNavDest(context, "home")
                                } else {
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.action_clipboard_manager_error_device_locked_title),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        }
    }
)
