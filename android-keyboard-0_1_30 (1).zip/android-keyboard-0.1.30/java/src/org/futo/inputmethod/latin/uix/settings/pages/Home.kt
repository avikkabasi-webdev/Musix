package org.futo.inputmethod.latin.uix.settings.pages

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import org.futo.inputmethod.latin.settings.Settings
import org.futo.inputmethod.latin.uix.settings.useSharedPrefsBool
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import org.futo.inputmethod.latin.BuildConfig
import org.futo.inputmethod.latin.R
import org.futo.inputmethod.latin.uix.LocalNavController
import org.futo.inputmethod.latin.uix.TextEditPopupActivity
import org.futo.inputmethod.latin.uix.USE_SYSTEM_VOICE_INPUT
import org.futo.inputmethod.latin.uix.settings.NavigationItem
import org.futo.inputmethod.latin.uix.settings.NavigationItemStyle
import org.futo.inputmethod.latin.uix.settings.UserSetting
import org.futo.inputmethod.latin.uix.settings.UserSettingsMenu
import org.futo.inputmethod.latin.uix.settings.render
import org.futo.inputmethod.latin.uix.settings.useDataStoreValue
import org.futo.inputmethod.latin.uix.settings.userSettingNavigationItem
import org.futo.inputmethod.latin.uix.theme.Typography
import org.futo.inputmethod.updates.ConditionalMigrateUpdateNotice
import org.futo.inputmethod.updates.openManualUpdateCheck

val HomeScreenLite = UserSettingsMenu(
    title = R.string.settings_home_title,
    navPath = "home", registerNavPath = false,
    settings = listOf(
        userSettingNavigationItem(
            title = R.string.settings_check_for_updates_manually,
            style = NavigationItemStyle.Misc,
            navigate = { nav -> nav.context.openManualUpdateCheck() }
        ),

        userSettingNavigationItem(
            title = R.string.language_settings_title,
            style = NavigationItemStyle.HomePrimary,
            navigateTo = "languages",
            icon = R.drawable.globe
        ),

        userSettingNavigationItem(
            title = R.string.settings_keyboard_typing_title,
            style = NavigationItemStyle.HomeSecondary,
            navigateTo = "keyboardAndTyping",
            icon = R.drawable.keyboard
        ),

        userSettingNavigationItem(
            title = SwipeMenu.title,
            style = NavigationItemStyle.HomePrimary,
            navigateTo = SwipeMenu.navPath,
            icon = R.drawable.swipe_icon
        ),

        userSettingNavigationItem(
            title = R.string.prediction_settings_title,
            style = NavigationItemStyle.HomeTertiary,
            navigateTo = PredictiveTextMenu.navPath,
            icon = R.drawable.text_prediction
        ),

        UserSetting(
            name = R.string.voice_input_settings_title
        ) {
            val navController = LocalNavController.current
            NavigationItem(
                title = stringResource(R.string.voice_input_settings_title),
                style = NavigationItemStyle.HomePrimary,
                subtitle = if(useDataStoreValue(USE_SYSTEM_VOICE_INPUT)) {
                    stringResource(R.string.voice_input_settings_builtin_disabled_notice)
                } else { null },
                navigate = { navController!!.navigate(VoiceInputMenu.navPath) },
                icon = painterResource(R.drawable.mic_fill)
            )
        },

        userSettingNavigationItem(
            title = R.string.action_settings_title,
            style = NavigationItemStyle.HomeSecondary,
            navigateTo = "actions",
            icon = R.drawable.smile
        ),

        userSettingNavigationItem(
            title = R.string.theme_settings_title,
            style = NavigationItemStyle.HomeTertiary,
            navigateTo = "themes",
            icon = R.drawable.themes
        ),

        //if(!isPaid) {
        userSettingNavigationItem(
            title = R.string.payment_screen_short_title,
            style = NavigationItemStyle.HomePrimary,
            navigateTo = "payment",
            icon = R.drawable.dollar_sign,
        ).copy(visibilityCheck = {
            useDataStoreValue(IS_ALREADY_PAID) == false
        }, appearInSearchIfVisibilityCheckFailed = false),
        //}

        userSettingNavigationItem(
            title = R.string.help_menu_title,
            style = NavigationItemStyle.HomeSecondary,
            navigateTo = "help",
            icon = R.drawable.help_circle
        ),

        //if(isDeveloper || LocalInspectionMode.current) {
        userSettingNavigationItem(
            title = R.string.dev_settings_title,
            style = NavigationItemStyle.HomeTertiary,
            navigateTo = "developer",
            icon = R.drawable.code
        ).copy(visibilityCheck = {
            useDataStoreValue(IS_DEVELOPER) == true || LocalInspectionMode.current
        }),
        //}

        userSettingNavigationItem(
            title = R.string.misc_settings_title,
            style = NavigationItemStyle.MiscNoArrow,
            navigateTo = "misc",
        ),

        userSettingNavigationItem(
            title = R.string.credits_menu_title,
            style = NavigationItemStyle.MiscNoArrow,
            navigateTo = "credits",
        ),
    )
)

private val IosBlue = Color(0xFF007AFF)
private val IosGreen = Color(0xFF34C759)
private val IosOrange = Color(0xFFFF9500)
private val IosRed = Color(0xFFFF3B30)
private val IosPurple = Color(0xFFAF52DE)
private val IosIndigo = Color(0xFF5856D6)
private val IosPink = Color(0xFFFF2D55)
private val IosGrey = Color(0xFF8E8E93)
private val IosTeal = Color(0xFF30B0C7)

@Composable
private fun HomeGroup(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        content = content
    )
}

@Composable
private fun HomeSectionLabel(text: String) {
    Text(
        text.uppercase(),
        style = Typography.Small,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
        modifier = Modifier.padding(start = 32.dp, top = 24.dp, bottom = 8.dp)
    )
}

@Composable
private fun HomeDivider() {
    Box(
        Modifier
            .padding(start = 58.dp)
            .fillMaxWidth()
            .height(0.5.dp)
            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))
    )
}

@Composable
private fun HomeRow(icon: Int, tint: Color, title: String, value: String?, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(tint),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            Icon(
                painterResource(icon),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1.0f)) {
            Text(title, style = Typography.Body.Regular, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if(value != null) {
                Text(
                    value,
                    style = Typography.Small,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
        Icon(
            painterResource(R.drawable.chevron_right),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreen(navController: NavHostController = rememberNavController()) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val isDeveloper = useDataStoreValue(IS_DEVELOPER)
    val isPaid = useDataStoreValue(IS_ALREADY_PAID)

    val autoCorrectOn = useSharedPrefsBool(Settings.PREF_AUTO_CORRECTION, true).value
    val swipeOn = useSharedPrefsBool(Settings.PREF_GESTURE_INPUT, true).value
    val numberRowOn = useSharedPrefsBool(Settings.PREF_ENABLE_NUMBER_ROW, false).value
    val builtinVoiceDisabled = useDataStoreValue(USE_SYSTEM_VOICE_INPUT)

    val on = stringResource(R.string.home_value_on)
    val off = stringResource(R.string.home_value_off)
    val onOff = { b: Boolean -> if(b) on else off }

    Column {
        Column(
            modifier = Modifier
                .weight(1.0f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
        ) {
            Row(
                Modifier.padding(start = 20.dp, end = 8.dp, top = 40.dp, bottom = 12.dp),
                verticalAlignment = CenterVertically
            ) {
                Text(
                    stringResource(R.string.english_ime_settings),
                    style = Typography.Heading.Medium.copy(
                        fontSize = 34.sp,
                        lineHeight = 40.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier
                        .align(CenterVertically)
                        .weight(1.0f)
                )

                IconButton(onClick = { navController.navigate("search") }) {
                    Icon(Icons.Default.Search, contentDescription = stringResource(
                        R.string.settings_search_menu_title
                    ))
                }
            }

            ConditionalMigrateUpdateNotice()
            ConditionalUnpaidNoticeWithNav(navController)

            // Status + test field
            HomeGroup {
                Row(
                    Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp),
                    verticalAlignment = CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(IosGreen)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        stringResource(R.string.home_ready_to_type),
                        style = Typography.Small,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                Text(
                    stringResource(R.string.settings_try_typing_here),
                    style = Typography.Heading.Regular,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val intent = Intent()
                            intent.setClass(context, TextEditPopupActivity::class.java)
                            intent.setFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            )
                            context.startActivity(intent)
                        }
                        .padding(16.dp)
                )
            }

            // Main categories, each with a live value
            HomeSectionLabel(stringResource(R.string.home_section_keyboard))
            HomeGroup {
                HomeRow(R.drawable.globe, IosBlue,
                    stringResource(R.string.language_settings_title), null
                ) { navController.navigate("languages") }
                HomeDivider()
                HomeRow(R.drawable.themes, IosPink,
                    stringResource(R.string.theme_settings_title), null
                ) { navController.navigate("themes") }
                HomeDivider()
                HomeRow(R.drawable.keyboard, IosGrey,
                    stringResource(R.string.settings_keyboard_typing_title),
                    stringResource(R.string.home_value_number_row, onOff(numberRowOn))
                ) { navController.navigate("keyboardAndTyping") }
                HomeDivider()
                HomeRow(R.drawable.text_prediction, IosPurple,
                    stringResource(R.string.prediction_settings_title),
                    stringResource(R.string.home_value_autocorrect, onOff(autoCorrectOn))
                ) { navController.navigate(PredictiveTextMenu.navPath) }
                HomeDivider()
                HomeRow(R.drawable.swipe_icon, IosIndigo,
                    stringResource(SwipeMenu.title), onOff(swipeOn)
                ) { navController.navigate(SwipeMenu.navPath) }
                HomeDivider()
                HomeRow(R.drawable.mic_fill, IosRed,
                    stringResource(R.string.voice_input_settings_title),
                    onOff(!builtinVoiceDisabled)
                ) { navController.navigate(VoiceInputMenu.navPath) }
                HomeDivider()
                HomeRow(R.drawable.smile, IosOrange,
                    stringResource(R.string.action_settings_title), null
                ) { navController.navigate("actions") }
            }

            // App-level items
            HomeSectionLabel(stringResource(R.string.home_section_app))
            HomeGroup {
                HomeRow(R.drawable.arrow_down, IosTeal,
                    stringResource(R.string.settings_check_for_updates_manually), null
                ) { context.openManualUpdateCheck() }
                HomeDivider()
                HomeRow(R.drawable.settings, IosGrey,
                    stringResource(R.string.misc_settings_title), null
                ) { navController.navigate("misc") }
                HomeDivider()
                HomeRow(R.drawable.help_circle, IosBlue,
                    stringResource(R.string.help_menu_title), null
                ) { navController.navigate("help") }
                if(!isPaid) {
                    HomeDivider()
                    HomeRow(R.drawable.dollar_sign, IosGreen,
                        stringResource(R.string.payment_screen_short_title), null
                    ) { navController.navigate("payment") }
                }
                HomeDivider()
                HomeRow(R.drawable.book, IosOrange,
                    stringResource(R.string.credits_menu_title), null
                ) { navController.navigate("credits") }
                if(isDeveloper) {
                    HomeDivider()
                    HomeRow(R.drawable.code, IosGrey,
                        stringResource(R.string.dev_settings_title), null
                    ) { navController.navigate("developer") }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            if(isPaid || LocalInspectionMode.current) {
                Text(
                    stringResource(R.string.payment_paid_version_indicator),
                    style = Typography.SmallMl,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            Text(
                "v${BuildConfig.VERSION_NAME}",
                style = Typography.Small,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
