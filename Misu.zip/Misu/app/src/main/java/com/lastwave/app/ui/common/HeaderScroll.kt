package com.lastwave.app.ui.common

import androidx.compose.animation.core.animate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.unit.Velocity

/**
 * YouTube-style "hide on scroll down, show on scroll up" for every
 * [ExpressiveHeader] in the app.
 *
 * One instance is created in LastWaveNavHost and the [connection] is attached
 * above the whole NavHost, so any vertical list / scroll container under it
 * drives the header — screens do not need to wire anything themselves.
 */
@Stable
class HeaderScrollState {
    /** 0 = fully shown, -[limit] = fully hidden. */
    var offset by mutableFloatStateOf(0f)

    /** How far (px) the header may slide away. Reported by the header itself. */
    var limit: Float = 0f

    fun reset() {
        offset = 0f
    }

    val connection: NestedScrollConnection = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            val dy = available.y
            if (dy == 0f || limit <= 0f) return Offset.Zero
            val old = offset
            val new = (old + dy).coerceIn(-limit, 0f)
            offset = new
            // Consume what the header used so the list below (which grows /
            // shrinks with the header) doesn't also move by the same amount.
            return Offset(0f, new - old)
        }

        override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
            settle()
            return Velocity.Zero
        }
    }

    /** Snap to fully shown / fully hidden after the finger lifts. */
    suspend fun settle() {
        if (limit <= 0f) return
        val start = offset
        if (start == 0f || start == -limit) return
        val target = if (start > -limit / 2f) 0f else -limit
        animate(start, target) { value, _ -> offset = value }
    }
}

val LocalHeaderScroll = staticCompositionLocalOf<HeaderScrollState?> { null }

@Composable
fun rememberHeaderScrollState(): HeaderScrollState = remember { HeaderScrollState() }
