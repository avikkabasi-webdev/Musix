package com.lastwave.app.ui.common

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.layout.layout
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.lastwave.app.ui.theme.genusGlass


/** Fully rounded pill (grows gracefully into a rounded card if a subtitle
 *  makes it taller). */
private val HeaderShape = RoundedCornerShape(50)

/**
 * The one container every major screen's header sits inside. A floating,
 * glass-style pill: inset from the screen edges, a gap below the status
 * bar, translucent surface with a soft light border and shadow.
 *
 * Window-inset aware: the pill pads itself below the status bar, so callers
 * never add their own top safe-drawing padding above this.
 *
 * For a screen with only a title (a tab root, no back target) pass
 * `onBack = null`; for a pushed screen pass a pop callback and it renders a
 * leading back button in the same tonal family as the trailing [actions].
 */
@Composable
fun ExpressiveHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    backdrop: com.lastwave.app.ui.theme.Backdrop? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val headerScroll = LocalHeaderScroll.current
    Box(
        modifier
            .fillMaxWidth()
            .zIndex(1f)
            .windowInsetsPadding(
                WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
            )
            .layout { measurable, constraints ->
                val placeable = measurable.measure(constraints)
                val h = placeable.height.toFloat()
                // Sits inside the status-bar inset padding, so only the pill
                // itself slides away and the status-bar strip stays.
                val limit = h
                headerScroll?.limit = limit
                val offset = (headerScroll?.offset ?: 0f).coerceIn(-limit, 0f)
                val progress = if (limit > 0f) -offset / limit else 0f
                layout(placeable.width, (h + offset).toInt().coerceAtLeast(0)) {
                    placeable.placeWithLayer(0, offset.toInt()) {
                        alpha = (1f - progress).coerceIn(0f, 1f)
                    }
                }
            }
            .padding(horizontal = 14.dp)
            .padding(top = 6.dp, bottom = 8.dp),
    ) {
        Surface(
            shape = HeaderShape,
            color = Color.Transparent,
            modifier = Modifier
                .fillMaxWidth()
                .genusGlass(backdrop, HeaderShape),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 64.dp)
                    .padding(start = if (onBack != null) 10.dp else 22.dp, end = 10.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (onBack != null) {
                    FilledTonalIconButton(
                        onClick = onBack,
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.7f),
                        ),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(10.dp))
                }

                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        style = if (onBack != null) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                    )
                    subtitle?.let {
                        Text(
                            it,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    actions()
                }
            }
        }
    }
}

/** A trailing action icon for [ExpressiveHeader] (or any other header-style
 *  surface) — a small filled-tonal circular button matching the leading
 *  back button's tone, so every icon in a header reads as one family
 *  instead of each screen picking its own IconButton style. */
@Composable
fun HeaderActionIcon(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
) {
    FilledTonalIconButton(
        onClick = onClick,
        colors = IconButtonDefaults.filledTonalIconButtonColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.7f),
        ),
    ) {
        Icon(icon, contentDescription = contentDescription)
    }
}
