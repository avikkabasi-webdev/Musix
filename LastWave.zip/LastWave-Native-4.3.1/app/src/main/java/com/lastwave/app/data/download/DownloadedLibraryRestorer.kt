package com.lastwave.app.data.download

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.lastwave.app.data.local.SettingsPreferences
import com.lastwave.app.data.local.db.DownloadedTrackDao
import com.lastwave.app.data.local.db.DownloadedTrackEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Rebuilds the Downloads list from the audio files that are still saved on the
 * phone (Music/LastWave/...). The Room table is wiped when the app is
 * uninstalled, but the downloaded files themselves stay in shared storage, so
 * after a reinstall this scans the folder and re-adds every song that is
 * missing from the database.
 */
@Singleton
class DownloadedLibraryRestorer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val downloadedTrackDao: DownloadedTrackDao,
    private val settingsPreferences: SettingsPreferences,
) {

    /** True when the app may read audio files it did not create in this install. */
    fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Returns how many songs were added back to the Downloads list.
     *
     * Runs one time per install (the marker lives in noBackupFilesDir, so it is
     * not restored from a cloud backup). This keeps "Clear history" working:
     * cleared entries are not silently re-added on the next visit.
     */
    suspend fun restore(): Int = withContext(Dispatchers.IO) {
        if (!hasAudioPermission()) return@withContext 0
        val marker = File(context.noBackupFilesDir, RESTORE_DONE_MARKER)
        if (marker.exists()) return@withContext 0
        val added = runCatching { restoreInternal() }
            .onFailure { android.util.Log.w(TAG, "Restore failed", it) }
            .getOrNull()
        if (added != null) {
            runCatching { marker.createNewFile() }
        }
        added ?: 0
    }

    private suspend fun restoreInternal(): Int {
        val folderNames = linkedSetOf(DEFAULT_DIR)
        runCatching { settingsPreferences.settings.first().downloadFolder }
            .getOrNull()
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?.let { folderNames.add(it) }

        val knownKeys = downloadedTrackDao.getAllTrackKeys().toHashSet()
        val knownUris = downloadedTrackDao.getAllList().mapNotNull { it.mediaStoreUri }.toHashSet()
        var added = 0

        for (folder in folderNames) {
            added += scanFolder(folder, knownKeys, knownUris)
        }
        return added
    }

    @Suppress("DEPRECATION")
    private suspend fun scanFolder(
        folder: String,
        knownKeys: MutableSet<String>,
        knownUris: MutableSet<String>,
    ): Int {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
        )
        val useRelativePath = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val selection = if (useRelativePath) {
            "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?"
        } else {
            "${MediaStore.Audio.Media.DATA} LIKE ?"
        }
        val args = if (useRelativePath) {
            arrayOf("Music/$folder/%")
        } else {
            arrayOf("%/Music/$folder/%")
        }

        var added = 0
        context.contentResolver.query(
            collection,
            projection,
            selection,
            args,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC",
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val uriString = uri.toString()
                if (uriString in knownUris) continue

                val displayName = cursor.getString(nameCol).orEmpty()
                val baseName = displayName.substringBeforeLast('.', displayName)
                var title = cursor.getString(titleCol).orEmpty().trim()
                var artist = cursor.getString(artistCol).orEmpty().trim()
                if (artist.equals("<unknown>", ignoreCase = true)) artist = ""
                // Files are named "Artist - Title" by the downloader; use that
                // when the tags are missing.
                if (title.isBlank() || artist.isBlank()) {
                    val parts = baseName.split(" - ", limit = 2)
                    if (parts.size == 2) {
                        if (artist.isBlank()) artist = parts[0].trim()
                        if (title.isBlank()) title = parts[1].trim()
                    }
                }
                if (title.isBlank()) title = baseName.ifBlank { "Unknown title" }
                if (artist.isBlank()) artist = "Unknown Artist"

                val key = TrackDownloadManager.makeDownloadKey(title, artist)
                if (!knownKeys.add(key)) continue

                var album = cursor.getString(albumCol).orEmpty().trim()
                if (album.equals(folder, ignoreCase = true) || album.equals("<unknown>", ignoreCase = true)) {
                    album = ""
                }
                val mime = cursor.getString(mimeCol).orEmpty()
                val extension = displayName.substringAfterLast('.', "").lowercase()
                val badge = when {
                    extension == "flac" || mime.contains("flac") -> "FLAC"
                    extension == "m4a" || extension == "mp4" || mime.contains("mp4") -> "M4A"
                    extension == "opus" || extension == "ogg" || mime.contains("ogg") -> "OPUS"
                    extension == "mp3" || mime.contains("mpeg") -> "MP3"
                    else -> "AUDIO"
                }
                val dataPath = cursor.getString(dataCol).orEmpty()
                val filePath = dataPath.takeIf { it.startsWith("/") } ?: uriString

                val entity = DownloadedTrackEntity(
                    trackKey = key,
                    title = title,
                    artist = artist,
                    album = album,
                    artworkUrl = extractArtwork(uri, id),
                    filePath = filePath,
                    mediaStoreUri = uriString,
                    fileSizeBytes = cursor.getLong(sizeCol),
                    formatBadge = badge,
                    durationMs = cursor.getLong(durationCol),
                    isLossless = badge == "FLAC",
                    downloadedAtMillis = cursor.getLong(addedCol) * 1000L,
                )
                downloadedTrackDao.insert(entity)
                knownUris.add(uriString)
                added++
            }
        }
        return added
    }

    /** Saves the cover art embedded in the file (if any) and returns its file:// URL. */
    private fun extractArtwork(uri: Uri, id: Long): String? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val bytes = retriever.embeddedPicture ?: return null
            val dir = File(context.filesDir, "restored_art").apply { mkdirs() }
            val out = File(dir, "$id.jpg")
            out.writeBytes(bytes)
            Uri.fromFile(out).toString()
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private companion object {
        const val TAG = "DownloadedLibraryRestorer"
        const val DEFAULT_DIR = "LastWave"
        const val RESTORE_DONE_MARKER = "downloads_restored_v1"
    }
}
