package com.dotsgo.app.data.scrape

import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLEncoder

class Store(val key: String, val fetch: (String) -> List<Item>)

/** What kind of thing is being searched. Decides which stores are worth asking. */
enum class Kind { ELECTRONICS, FASHION, BEAUTY, HOME, WATCH, GENERAL }

/** One reader per shopping site. Each returns real products or throws [StoreException]. */
object Stores {

    val all: List<Store> = listOf(
        Store("amazon") { q -> amazon(q) },
        Store("flipkart") { q -> flipkart(q) },
        Store("snapdeal") { q -> snapdeal(q) },
        Store("myntra") { q -> myntra(q) },
        Store("ajio") { q -> ajio(q) },
        Store("nykaa") { q ->
            pageStore(q, "https://www.nykaa.com", "https://www.nykaa.com/search/result/?q=%s&root=search", Regex("/p/\\d+"))
        },
        Store("meesho") { q ->
            pageStore(q, "https://www.meesho.com", "https://www.meesho.com/search?q=%s", Regex("/p/[a-z0-9]+"))
        },
        Store("jiomart") { q ->
            pageStore(q, "https://www.jiomart.com", "https://www.jiomart.com/search/%s", Regex("/p/"), pathStyle = true)
        },
    )

    private val ELECTRONICS_WORDS = setOf(
        "phone", "phones", "mobile", "mobiles", "smartphone", "smartphones", "iphone", "smartwatch", "smartwatches",
        "laptop", "laptops", "macbook", "tablet", "ipad", "tv", "television", "headphone", "headphones", "earbuds",
        "earphones", "earphone", "neckband", "airpods", "speaker", "speakers", "soundbar", "camera", "gopro",
        "powerbank", "charger", "monitor", "keyboard", "mouse", "router", "printer", "console", "playstation",
        "xbox", "ssd", "pendrive", "gpu", "processor", "nothing", "samsung", "oneplus", "redmi", "realme", "poco",
        "vivo", "oppo", "iqoo", "motorola", "moto", "pixel", "xiaomi", "mi", "boat", "noise", "jbl", "sony", "lenovo",
        "hp", "dell", "asus", "acer", "msi", "fitbit", "garmin", "amazfit", "fastrack", "airdopes", "buds",
    )
    private val BEAUTY_WORDS = setOf(
        "lipstick", "serum", "shampoo", "conditioner", "moisturizer", "moisturiser", "perfume", "makeup", "skincare",
        "foundation", "kajal", "eyeliner", "mascara", "sunscreen", "facewash", "cleanser", "toner", "lotion",
        "nailpolish", "compact", "concealer", "blush", "beauty", "cosmetics", "deodorant", "trimmer", "razor",
    )
    private val FASHION_WORDS = setOf(
        "shirt", "shirts", "tshirt", "tshirts", "jeans", "kurta", "kurti", "saree", "sarees", "dress", "dresses",
        "shoes", "shoe", "sneakers", "heels", "sandals", "slippers", "jacket", "hoodie", "sweatshirt", "trousers",
        "shorts", "lehenga", "top", "tops", "leggings", "innerwear", "bra", "socks", "backpack", "handbag", "wallet",
        "belt", "sunglasses", "fashion", "clothing", "clothes", "ethnic", "footwear", "joggers", "chinos", "blazer",
    )
    private val HOME_WORDS = setOf(
        "mixer", "grinder", "fridge", "refrigerator", "washing", "microwave", "cooker", "kettle", "toaster", "fan",
        "heater", "geyser", "ac", "cooler", "purifier", "vacuum", "iron", "blender", "juicer", "induction",
        "bedsheet", "curtain", "pillow", "mattress", "sofa", "table", "chair", "lamp", "decor", "home", "kitchen",
        "furniture", "cookware", "bottle", "airfryer", "fryer", "chimney", "stove",
    )

    fun kindOf(query: String): Kind {
        val words = Regex("[a-z0-9]+").findAll(query.lowercase()).map { it.value }.toList()
        val joined = words.joinToString("")
        fun has(set: Set<String>) = words.any { it in set || (it.length > 3 && it.endsWith("s") && it.dropLast(1) in set) }
        if (words.any { it == "smartwatch" || it == "smartwatches" } || joined.contains("smartwatch")) return Kind.ELECTRONICS
        if (words.contains("smart") && (words.contains("watch") || words.contains("band"))) return Kind.ELECTRONICS
        if (has(BEAUTY_WORDS)) return Kind.BEAUTY
        if (words.any { it == "watch" || it == "watches" }) return Kind.WATCH
        if (has(ELECTRONICS_WORDS)) return Kind.ELECTRONICS
        if (has(FASHION_WORDS)) return Kind.FASHION
        if (has(HOME_WORDS)) return Kind.HOME
        return Kind.GENERAL
    }

    /**
     * Only ask stores that actually sell this kind of thing. Asking Ajio, Nykaa or Meesho for a phone
     * only ever returned accessories (or a "blocked" error), and it slowed every search down.
     */
    fun forQuery(query: String): List<Store> {
        val keys: List<String> = when (kindOf(query)) {
            Kind.ELECTRONICS -> listOf("amazon", "flipkart", "snapdeal", "jiomart")
            Kind.FASHION -> listOf("amazon", "flipkart", "myntra", "ajio", "snapdeal", "meesho")
            Kind.BEAUTY -> listOf("amazon", "flipkart", "nykaa", "myntra", "meesho")
            Kind.HOME -> listOf("amazon", "flipkart", "snapdeal", "jiomart", "meesho")
            Kind.WATCH -> listOf("amazon", "flipkart", "myntra", "ajio", "snapdeal")
            Kind.GENERAL -> listOf("amazon", "flipkart", "snapdeal", "jiomart", "meesho")
        }
        return keys.mapNotNull { k -> all.firstOrNull { it.key == k } }
    }

    private val pagePool = java.util.concurrent.Executors.newCachedThreadPool()

    /** Reads several result pages of one store at once. Page 1 failing is an error; later pages are a bonus. */
    private fun pages(n: Int, read: (Int) -> List<Item>): List<Item> {
        if (n <= 1) return read(1)
        val futures = (1..n).map { p -> pagePool.submit(java.util.concurrent.Callable { read(p) }) }
        val first = try {
            futures[0].get(25, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: java.util.concurrent.ExecutionException) {
            val c = e.cause
            if (c is StoreException) throw c else throw StoreException("could not read the page")
        } catch (e: Exception) {
            throw StoreException("took too long")
        }
        val out = ArrayList<Item>(first)
        for (i in 1 until futures.size) {
            try {
                out.addAll(futures[i].get(15, java.util.concurrent.TimeUnit.SECONDS))
            } catch (e: Exception) {
                // later pages are optional
            }
        }
        return out
    }

    private val CAPTCHA_RX = Regex("api-services-support@amazon|Enter the characters you see|validateCaptcha")

    private fun enc(q: String): String = URLEncoder.encode(q, "UTF-8")

    private fun amazon(q: String): List<Item> = pages(3) { page -> amazonPage(q, page) }

    private fun amazonPage(q: String, page: Int): List<Item> {
        val base = "https://www.amazon.in"
        val url = "$base/s?k=" + enc(q) + if (page > 1) "&page=$page" else ""
        val html = Http.get(url, referer = if (page > 1) "$base/s?k=" + enc(q) else null)
        if (CAPTCHA_RX.containsMatchIn(html)) throw StoreException("showed a bot-check (captcha)")
        val doc = Jsoup.parse(html, base)
        val out = ArrayList<Item>()
        for (el in doc.select("div[data-component-type=\"s-search-result\"]")) {
            val asin = el.attr("data-asin")
            if (asin.length != 10) continue
            if (el.hasClass("AdHolder") || el.selectFirst(".puis-sponsored-label-text, [aria-label*=Sponsored]") != null) continue
            val title = Parsing.clean(el.selectFirst("h2")?.text())
            val price = Parsing.toPrice(el.selectFirst("span.a-price-whole")?.text())
            if (title.isEmpty() || price == null) continue
            val image = el.selectFirst("img.s-image")?.absUrl("src")
            out.add(
                Item(
                    title = title,
                    price = price,
                    url = "$base/dp/$asin",
                    image = if (image != null && image.startsWith("http")) image else null,
                    rating = Parsing.toRating(el.selectFirst("span.a-icon-alt")?.text()),
                    reviews = Parsing.toCount(el.selectFirst("span.a-size-base.s-underline-text")?.text()),
                ),
            )
        }
        return out
    }

    private fun flipkart(q: String): List<Item> = pages(2) { page -> flipkartPage(q, page) }

    private fun flipkartPage(q: String, page: Int): List<Item> {
        val base = "https://www.flipkart.com"
        val html = Http.get("$base/search?q=" + enc(q) + "&otracker=search" + if (page > 1) "&page=$page" else "")
        val items = Parsing.anchorItems(html, base, Regex("/p/itm"))
        if (items.isNotEmpty()) return items
        val out = ArrayList<Item>()
        for (b in Parsing.jsonBlobs(html)) out.addAll(Parsing.walkProducts(b, base))
        return out
    }

    private fun snapdeal(q: String): List<Item> {
        val base = "https://www.snapdeal.com"
        val html = Http.get("$base/search?keyword=" + enc(q) + "&sort=rlvncy")
        return Parsing.anchorItems(html, base, Regex("/product/"))
    }

    private fun myntra(q: String): List<Item> {
        val base = "https://www.myntra.com/"
        val slug = q.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        val html = Http.get("$base$slug?rawQuery=" + enc(q))
        val out = ArrayList<Item>()
        for (b in Parsing.jsonBlobs(html)) out.addAll(Parsing.walkProducts(b, base))
        if (out.isNotEmpty()) return out
        return Parsing.anchorItems(html, base, Regex("/buy"))
    }

    private fun ajio(q: String): List<Item> {
        val base = "https://www.ajio.com"
        val api = "$base/api/search?fields=SITE&currentPage=0&pageSize=45&format=json" +
            "&query=" + enc(q) + "&sortBy=relevance&gridColumns=3&platform=site"
        val text = Http.get(api, accept = "application/json", referer = "$base/")
        val data = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw StoreException("did not return product data")
        }
        return Parsing.walkProducts(data, base)
    }

    /** Sites that mostly build their page with JavaScript: try embedded JSON first, then plain links. */
    private fun pageStore(
        q: String,
        base: String,
        urlTemplate: String,
        linkRx: Regex,
        pathStyle: Boolean = false,
    ): List<Item> {
        val term = if (pathStyle) enc(q).replace("+", "%20") else enc(q)
        val html = Http.get(urlTemplate.replace("%s", term))
        val out = ArrayList<Item>()
        for (b in Parsing.jsonBlobs(html)) out.addAll(Parsing.walkProducts(b, base))
        if (out.isNotEmpty()) return out
        return Parsing.anchorItems(html, base, linkRx)
    }
}
