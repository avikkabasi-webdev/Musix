package com.dotsgo.app.data.scrape

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Reads the stores. Each store is read on its own (so the screen can show real progress),
 * and [search] then merges whatever the stores returned into one answer.
 */
object SearchRepository {

    private const val OK_TTL_MS = 3L * 60L * 60L * 1000L
    private const val FAIL_TTL_MS = 60L * 1000L
    private const val PER_STORE_LIMIT = 60

    /** Items already checked for relevance, each with its match score. */
    private class Outcome(val items: List<Pair<Item, Int>>, val error: String?, val at: Long)

    private val outcomes = ConcurrentHashMap<String, Outcome>()

    private fun norm(q: String): String = q.lowercase().trim().replace(Regex("\\s+"), " ")

    private fun outcomeFor(store: Store, query: String): Outcome {
        val key = "v2|" + store.key + "|" + norm(query)
        val hit = outcomes[key]
        if (hit != null) {
            val ttl = if (hit.error == null) OK_TTL_MS else FAIL_TTL_MS
            if (System.currentTimeMillis() - hit.at < ttl) return hit
        }
        val q = Matching.Query(query)
        val fresh: Outcome = try {
            val raw = store.fetch(query)
            // same listing can appear twice on a store: keep the first
            val seen = HashSet<String>()
            val unique = raw.filter { seen.add(it.title.lowercase() + "|" + it.price) }
            val scored = unique
                .map { it to Matching.score(it.title, q) }
                .filter { it.second > 0 }
            val itemsOnly = Matching.dropPriceOutliers(scored.map { it.first }, q).toSet()
            val kept = scored.filter { it.first in itemsOnly }
            // best match first; within the same match level keep the store's own order (its relevance ranking)
            val ordered = kept
                .withIndex()
                .sortedWith(compareByDescending<IndexedValue<Pair<Item, Int>>> { it.value.second / 8 }.thenBy { it.index })
                .map { it.value }
                .take(PER_STORE_LIMIT)
            Outcome(
                ordered,
                if (ordered.isEmpty()) "no matching products found" else null,
                System.currentTimeMillis(),
            )
        } catch (e: StoreException) {
            Outcome(emptyList(), e.message ?: "failed", System.currentTimeMillis())
        } catch (e: Exception) {
            Outcome(emptyList(), "could not read the page", System.currentTimeMillis())
        }
        outcomes[key] = fresh
        return fresh
    }

    /** Which stores are worth asking for this search (the page shows exactly these). */
    fun plan(query: String): String {
        val arr = JSONArray()
        for (s in Stores.forQuery(query)) arr.put(s.key)
        return JSONObject().put("stores", arr).toString()
    }

    /** Reads one store and reports how it went (used for the live progress on the searching screen). */
    fun searchStore(query: String, storeKey: String): String {
        val store = Stores.all.firstOrNull { it.key == storeKey }
            ?: return JSONObject()
                .put("store", storeKey).put("ok", false).put("count", 0).put("error", "unknown store")
                .toString()
        val o = outcomeFor(store, query)
        return JSONObject()
            .put("store", store.key)
            .put("ok", o.error == null)
            .put("count", o.items.size)
            .put("error", o.error)
            .toString()
    }

    /** Merges all stores into the final list. Stores already read a moment ago are reused. */
    fun search(query: String): String {
        val stores = Stores.forQuery(query)
        val q = Matching.Query(query)
        val status = JSONObject()
        val byStore = LinkedHashMap<String, List<Pair<Item, Int>>>()
        var oldest = System.currentTimeMillis()

        val pool = Executors.newFixedThreadPool(stores.size)
        try {
            val tasks = stores.map { store -> Callable<Outcome> { outcomeFor(store, query) } }
            val futures = pool.invokeAll(tasks, 40, TimeUnit.SECONDS)
            for (i in stores.indices) {
                val name = stores[i].key
                val f = futures[i]
                var error: String? = null
                var good: List<Pair<Item, Int>> = emptyList()
                if (f.isCancelled) {
                    error = "took too long"
                } else {
                    try {
                        val o = f.get()
                        good = o.items
                        error = o.error
                        if (o.error == null && o.at < oldest) oldest = o.at
                    } catch (e: Exception) {
                        error = "could not read the page"
                    }
                }
                if (good.isNotEmpty()) byStore[name] = good
                status.put(
                    name,
                    JSONObject().put("ok", good.isNotEmpty()).put("count", good.size).put("error", error),
                )
            }
        } finally {
            pool.shutdownNow()
        }

        val results = JSONArray()
        for (g in Matching.group(byStore, q)) {
            val sorted = g.stores.entries.sortedBy { it.value.price }
            val storesJson = JSONArray()
            for (e in sorted) {
                val s = e.value
                storesJson.put(
                    JSONObject()
                        .put("store", e.key)
                        .put("price", s.price)
                        .put("rating", s.rating)
                        .put("reviews", s.reviews)
                        .put("url", s.url),
                )
            }
            results.put(
                JSONObject()
                    .put("id", Integer.toHexString(g.title.hashCode()))
                    .put("title", g.title)
                    .put("image", g.image)
                    .put("cheapestPrice", sorted[0].value.price)
                    .put("cheapestStore", sorted[0].key)
                    .put("stores", storesJson),
            )
        }

        return JSONObject()
            .put("results", results)
            .put("status", status)
            .put("timestamp", oldest)
            .toString()
    }
}
