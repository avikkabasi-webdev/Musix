package com.dotsgo.app.data.scrape

import kotlin.math.ln

/**
 * Decides which products really match what was searched, ranks them like a shopping site
 * would (relevance first, then popularity), and merges the same product from different stores.
 */
object Matching {

    private val STOP = setOf(
        "the", "a", "an", "for", "with", "and", "of", "in", "by", "to", "from",
        "buy", "online", "new", "best", "price", "india", "latest", "offer", "deal",
    )
    private val VARIANT = setOf("plus", "pro", "max", "ultra", "mini", "lite", "se", "fe", "air", "neo", "fold", "flip", "turbo")
    private val WORD_RX = Regex("[a-z0-9]+")

    /** Words that mean the listing is NOT the main device (cases, chargers, straps...). */
    internal val ACCESSORY = setOf(
        "case", "cases", "cover", "covers", "bumper", "skin", "skins", "sleeve", "pouch",
        "charger", "adapter", "adaptor", "cable", "cables", "connector",
        "strap", "straps", "protector", "protectors", "guard", "guards", "tempered", "screenguard",
        "film", "stand", "holder", "mount", "tripod", "sticker", "stickers", "decal", "lanyard",
        "keychain", "replacement", "spare", "refill", "repair", "dock", "cradle", "stylus",
        "eartips", "eartip", "cushion", "cushions", "extender", "splitter", "dongle", "popsocket",
    )
    /** Only device searches get accessory filtering (a "backpack" search must keep "laptop bag" etc.). */
    internal val DEVICE = setOf(
        "phone", "mobile", "smartphone", "watch", "smartwatch", "laptop", "tv", "television",
        "headphone", "earbud", "earphone", "tablet", "speaker", "camera", "console", "ipad",
        "iphone", "macbook", "airpod", "buds", "neckband", "soundbar", "monitor", "printer",
    )

    /** Words that mean a cheap / basic phone that nobody searching a generic "phone" wants first. */
    internal val FEATURE_PHONE = setOf("keypad", "feature", "basic", "dual sim keypad", "button")
    internal val CATEGORY_WORDS = setOf(
        "phone", "phones", "mobile", "mobiles", "smartphone", "smartphones", "5g", "4g", "watch",
        "smartwatch", "smartwatches", "laptop", "laptops", "tv", "television", "headphone", "headphones",
        "earbuds", "earphones", "tablet", "tablets", "speaker", "speakers", "camera", "shoes", "shirt",
    )

    fun tokens(text: String): Set<String> =
        WORD_RX.findAll(text.lowercase())
            .map { it.value }
            .filter { it !in STOP && it.length > 1 }
            .toSet()

    internal fun stem(w: String): String = when {
        w.length > 4 && w.endsWith("es") && (w.endsWith("ches") || w.endsWith("shes") || w.endsWith("sses")) -> w.dropLast(2)
        w.length > 3 && w.endsWith("s") && !w.endsWith("ss") -> w.dropLast(1)
        else -> w
    }

    private fun stems(text: String): Set<String> = tokens(text).map { stem(it) }.toSet()

    /** Treat "smart watch" == "smartwatch", "head phones" == "headphones", "i phone" == "iphone". */
    internal fun squash(text: String): String = text.lowercase().replace(Regex("[^a-z0-9]"), "")

    // ───────── what kind of search is this ─────────

    private val PRICE_PHRASE = Regex(
        "(under|below|upto|up to|above|over|less than|within|around)\\s*(rs\\.?|\u20B9)?\\s*\\d[\\d,]*\\s*k?",
        RegexOption.IGNORE_CASE,
    )
    private val FILLER = setOf("under", "below", "upto", "above", "cheap", "cheapest", "top", "good")

    class Query(val raw: String) {
        /** The search without "under 20000" style price phrases (those are not part of a product name). */
        private val text: String = raw.replace(PRICE_PHRASE, " ")
        val tokens: Set<String> = Matching.tokens(text).filter { it !in FILLER }.toSet()
        val stems: Set<String> = tokens.map { Matching.stem(it) }.toSet()
        val squashed: String = Matching.squash(text)
        val wantsAccessory: Boolean = stems.any { it in ACCESSORY || it + "s" in ACCESSORY }
        val isDevice: Boolean = tokens.any { w ->
            Matching.stem(w) in DEVICE || (w.length >= 5 && DEVICE.any { d -> d.length >= 5 && w.contains(d) })
        }
        val wantsFeaturePhone: Boolean = tokens.any { it in FEATURE_PHONE }

        /** Words that identify the product itself (brand + model). Category words are looser. */
        val core: Set<String> = tokens.filter { it !in CATEGORY_WORDS && Matching.stem(it) !in CATEGORY_WORDS }.toSet()

        /** Search is only a generic category ("phone", "smartwatch under 5000"): no brand / model given. */
        val generic: Boolean = core.isEmpty()
        val numericCore: Set<String> = core.filter { w -> w.any { it.isDigit() } }.toSet()
    }

    // ───────── relevance ─────────

    /**
     * 0 = not what was searched. Higher = better match.
     *  - every word of the search must be in the title (brand + model + variant), with
     *    "smart watch"/"smartwatch" style spacing tolerated;
     *  - accessories (cases, chargers, straps) are dropped unless the search asked for one;
     *  - "nothing phone 2a" never returns "nothing phone 2a back cover".
     */
    fun score(title: String, q: Query): Int {
        if (q.tokens.isEmpty()) return 10
        val tStems = stems(title)
        val tSquash = squash(title)
        val tTokens = tokens(title)

        var hits = 0
        for (w in q.stems) {
            if (w in tStems || (w.length >= 4 && tSquash.contains(w))) hits++
        }
        // Whole search must be covered. Allow one miss only on long (4+ word) searches.
        val allowedMiss = if (q.stems.size >= 4) 1 else 0
        if (hits < q.stems.size - allowedMiss) {
            // squashed fallback: "smart watch" vs "smartwatch"
            if (!(q.squashed.length >= 5 && tSquash.contains(q.squashed))) return 0
        }

        // Model numbers must match exactly: "iphone 15" must not return "iphone 15 pro" for a plain search,
        // and "redmi 12" must not accept "redmi 12 5g" and "redmi note 12"... handled by number tokens.
        for (n in q.numericCore) if (n !in tTokens && !tSquash.contains(n)) return 0

        var s = 50
        s += hits * 5

        // accessory handling (device searches only)
        if (q.isDevice && !q.wantsAccessory) {
            val ordered = tokens(title).toList()
            val head = ordered.take(8)
            val isAcc = head.any { it in ACCESSORY || stem(it) in ACCESSORY } ||
                (ordered.lastOrNull()?.let { it in ACCESSORY || stem(it) in ACCESSORY } == true)
            if (isAcc) return 0
            if (tSquash.contains("compatiblewith") || tSquash.contains("compatiblefor")) return 0
        }

        // Variant must agree: searching "iphone 15" should rank plain 15 above "15 pro max".
        val qVar = q.tokens.intersect(VARIANT)
        val tVar = tTokens.intersect(VARIANT)
        if (qVar.isNotEmpty() && !tVar.containsAll(qVar)) return 0
        if (qVar.isEmpty() && tVar.isNotEmpty()) s -= 12

        // Title that starts with the searched words is the product itself.
        val first = tokens(title).firstOrNull()
        if (first != null && first in q.tokens) s += 10

        // Shorter titles = fewer extra words = closer to the search.
        val extra = (tTokens.size - q.tokens.size).coerceAtLeast(0)
        s -= minOf(extra, 20) / 2

        // Generic "phone" search should never lead with keypad / feature phones.
        if (q.generic && !q.wantsFeaturePhone) {
            if (tTokens.any { it in FEATURE_PHONE }) s -= 40
        }
        return s.coerceAtLeast(1)
    }

    fun relevant(title: String, q: Query): Boolean = score(title, q) > 0

    /** Popularity weight so well-reviewed products float up, like on Amazon/Flipkart. */
    fun popularity(item: Item): Double {
        val r = item.rating ?: 0.0
        val n = (item.reviews ?: 0).toDouble()
        return (if (r > 0) r else 3.5) * 2.0 + ln(1.0 + n)
    }

    /**
     * For generic searches ("phone", "smartwatch") junk is mostly very cheap.
     * Drop items under 25% of the median price of the results (accessories, toys, fakes).
     */
    fun dropPriceOutliers(items: List<Item>, q: Query): List<Item> {
        if (items.size < 8) return items
        val sorted = items.map { it.price }.sorted()
        val median = sorted[sorted.size / 2]
        val floor = if (q.generic) (median * 0.30).toInt() else (median * 0.15).toInt()
        val kept = items.filter { it.price >= floor }
        return if (kept.size >= 5) kept else items
    }

    // ───────── merging same product across stores ─────────

    private fun numeric(set: Set<String>): Set<String> = set.filter { w -> w.any { it.isDigit() } }.toSet()

    fun sameProduct(a: Set<String>, b: Set<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        val union = a.union(b).size
        if (union == 0) return false
        val j = a.intersect(b).size.toDouble() / union.toDouble()
        if (j < 0.5) return false
        if (a.intersect(VARIANT) != b.intersect(VARIANT)) return false
        return numeric(a) == numeric(b) || j >= 0.8
    }

    class Group(val tokens: Set<String>, val title: String, var image: String?) {
        val stores = LinkedHashMap<String, Item>()
        var relevance: Int = 0
        var popularity: Double = 0.0
        fun cheapest(): Int = stores.values.minOf { it.price }
    }

    const val MAX_RESULTS = 120

    fun group(byStore: Map<String, List<Pair<Item, Int>>>, q: Query): List<Group> {
        val groups = ArrayList<Group>()
        val longest = byStore.values.maxOfOrNull { it.size } ?: 0
        for (i in 0 until longest) {
            for ((store, items) in byStore) {
                if (i >= items.size) continue
                val (item, rel) = items[i]
                val tk = tokens(item.title)
                var matched = false
                for (g in groups) {
                    if (sameProduct(g.tokens, tk)) {
                        val cur = g.stores[store]
                        if (cur == null || item.price < cur.price) g.stores[store] = item
                        if (g.image == null && item.image != null) g.image = item.image
                        g.relevance = maxOf(g.relevance, rel)
                        g.popularity = maxOf(g.popularity, popularity(item))
                        matched = true
                        break
                    }
                }
                if (!matched) {
                    val g = Group(tk, item.title, item.image)
                    g.stores[store] = item
                    g.relevance = rel
                    g.popularity = popularity(item)
                    groups.add(g)
                }
            }
        }
        // Relevance bucket first (so exact matches lead), then products sold in more stores,
        // then popular ones. Never "cheapest first" - that is what put keypad phones on top.
        return groups
            .sortedWith(
                compareByDescending<Group> { it.relevance / 8 }
                    .thenByDescending { it.stores.size }
                    .thenByDescending { it.popularity }
                    .thenByDescending { it.relevance },
            )
            .take(MAX_RESULTS)
    }
}
