package com.dotsgo.app.ui.web

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.dotsgo.app.data.scrape.SearchRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException

/**
 * Makes the WebView behave like a tiny local website:
 *   https://dotsgo.local/            -> assets/index.html (the dots.go screen)
 *   https://dotsgo.local/api/store   -> reads ONE store (drives the live progress)
 *   https://dotsgo.local/api/search  -> merges all stores into the final list (no server)
 * Anything else (store links) opens outside the app.
 */
class DotsWebViewClient(private val context: Context) : WebViewClient() {

    companion object {
        const val HOST = "dotsgo.local"
        const val START_URL = "https://dotsgo.local/"
    }

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val uri = request?.url ?: return null
        if (uri.host != HOST) return null
        val path = uri.path ?: "/"

        if (path == "/api/plan") {
            val q = (uri.getQueryParameter("q") ?: "").trim().take(120)
            val body = try {
                SearchRepository.plan(q)
            } catch (e: Exception) {
                "{\"stores\":[]}"
            }
            return reply("application/json", "UTF-8", 200, "OK", body.toByteArray(Charsets.UTF_8))
        }

        if (path == "/api/store") {
            val q = (uri.getQueryParameter("q") ?: "").trim().take(120)
            val storeKey = uri.getQueryParameter("store") ?: ""
            val body = if (q.isEmpty()) {
                emptyAnswer("empty query")
            } else {
                try {
                    SearchRepository.searchStore(q, storeKey)
                } catch (e: Exception) {
                    emptyAnswer(e.message ?: "store failed")
                }
            }
            return reply("application/json", "UTF-8", 200, "OK", body.toByteArray(Charsets.UTF_8))
        }

        if (path == "/api/search") {
            val q = (uri.getQueryParameter("q") ?: "").trim().take(120)
            val body = if (q.isEmpty()) {
                emptyAnswer("empty query")
            } else {
                try {
                    SearchRepository.search(q)
                } catch (e: Exception) {
                    emptyAnswer(e.message ?: "search failed")
                }
            }
            return reply("application/json", "UTF-8", 200, "OK", body.toByteArray(Charsets.UTF_8))
        }
        return asset(if (path == "/") "index.html" else path.removePrefix("/"))
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val uri = request?.url ?: return false
        if (uri.host == HOST) return false
        openOutside(uri)
        return true
    }

    private fun openOutside(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // nothing can open this link; ignore
        }
    }

    private fun emptyAnswer(error: String): String =
        JSONObject()
            .put("results", JSONArray())
            .put("status", JSONObject())
            .put("error", error)
            .toString()

    private fun asset(name: String): WebResourceResponse {
        return try {
            val stream = context.assets.open(name)
            val mime = when {
                name.endsWith(".html") -> "text/html"
                name.endsWith(".js") -> "application/javascript"
                name.endsWith(".css") -> "text/css"
                name.endsWith(".png") -> "image/png"
                name.endsWith(".svg") -> "image/svg+xml"
                else -> "application/octet-stream"
            }
            val encoding: String? = if (mime.startsWith("text/") || mime == "application/javascript") "UTF-8" else null
            WebResourceResponse(mime, encoding, 200, "OK", headers(), stream)
        } catch (e: IOException) {
            reply("text/plain", "UTF-8", 404, "Not Found", ByteArray(0))
        }
    }

    private fun reply(mime: String, encoding: String, code: Int, reason: String, bytes: ByteArray): WebResourceResponse =
        WebResourceResponse(mime, encoding, code, reason, headers(), ByteArrayInputStream(bytes))

    private fun headers(): Map<String, String> = mapOf("Cache-Control" to "no-store")
}
