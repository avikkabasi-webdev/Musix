package com.dotsgo.app.data.scrape

import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.parser.Parser
import java.net.URI

/** Helpers that turn a store's page (HTML or embedded JSON) into [Item]s. */
object Parsing {

    private val NUM_RX = Regex("""\d[\d,]*(?:\.\d+)?""")
    private val COUNT_RX = Regex("""([\d.]+)\s*([kKmM]?)""")
    private val PRICE_RX = Regex("""(?:\u20B9|Rs\.?)\s*([\d,]{2,})""")
    private val RATING_RX = Regex("""^\d\.\d$""")
    private val WS_RX = Regex("""\s+""")
    private val ASSIGN_RX = Regex("""window\.[A-Za-z0-9_]+\s*=\s*(?=[\{\[])""")

    private val TITLE_KEYS = listOf("productName", "product_name", "product", "name", "title", "displayName")
    private val PRICE_KEYS = listOf(
        "discountedPrice", "sellingPrice", "selling_price", "offerPrice", "offer_price",
        "salePrice", "finalPrice", "price", "min_price",
    )
    private val PRICE_INNER_KEYS = listOf("value", "amount", "price", "display", "formattedValue")
    private val URL_KEYS = listOf("landingPageUrl", "productUrl", "product_url", "url", "link", "slug", "actionUrl")
    private val IMG_KEYS = listOf(
        "searchImage", "imageUrl", "image_url", "imageURL", "image", "thumbnail", "images",
    )
    private val RATING_KEYS = listOf("averageRating", "avg_rating", "ratingValue", "rating")
    private val COUNT_KEYS = listOf(
        "ratingCount", "reviewCount", "ratingsCount", "review_count", "numberOfRatings", "reviews",
    )

    // ───────── basic value helpers ─────────

    fun clean(s: String?): String = (s ?: "").replace(WS_RX, " ").trim()

    fun toPrice(v: Any?): Int? {
        if (v == null || v is Boolean) return null
        val p: Double = when (v) {
            is Number -> v.toDouble()
            else -> {
                val m = NUM_RX.find(v.toString()) ?: return null
                m.value.replace(",", "").toDoubleOrNull() ?: return null
            }
        }
        return if (p >= 1.0 && p <= 10_000_000.0) Math.round(p).toInt() else null
    }

    fun toRating(v: Any?): Double? {
        if (v == null || v is Boolean) return null
        if (v !is Number && v !is String) return null
        val d: Double = when (v) {
            is Number -> v.toDouble()
            else -> {
                val m = NUM_RX.find(v.toString()) ?: return null
                m.value.replace(",", "").toDoubleOrNull() ?: return null
            }
        }
        return if (d > 0.0 && d <= 5.0) Math.round(d * 10.0) / 10.0 else null
    }

    fun toCount(v: Any?): Int? {
        if (v == null) return null
        if (v is Number) {
            val n = v.toInt()
            return if (n > 0) n else null
        }
        if (v !is String) return null
        val m = COUNT_RX.find(v.replace(",", "")) ?: return null
        val base = m.groupValues[1].toDoubleOrNull() ?: return null
        val mult = when (m.groupValues[2].lowercase()) {
            "k" -> 1000.0
            "m" -> 1000000.0
            else -> 1.0
        }
        val n = (base * mult).toInt()
        return if (n > 0) n else null
    }

    fun resolve(base: String, url: String?): String? {
        if (url.isNullOrBlank()) return null
        val u = url.trim()
        return try {
            URI(base).resolve(u).toString()
        } catch (e: Exception) {
            if (u.startsWith("http")) u else null
        }
    }

    // ───────── JSON embedded in pages ─────────

    private fun parseJson(text: String): Any? {
        val t = text.trim()
        return try {
            if (t.startsWith("{")) JSONObject(t) else if (t.startsWith("[")) JSONArray(t) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun matchClose(s: String, start: Int): Int {
        var depth = 0
        var inStr = false
        var esc = false
        val limit = minOf(s.length, start + 3_000_000)
        var i = start
        while (i < limit) {
            val c = s[i]
            if (inStr) {
                if (esc) {
                    esc = false
                } else if (c == '\\') {
                    esc = true
                } else if (c == '"') {
                    inStr = false
                }
            } else {
                if (c == '"') {
                    inStr = true
                } else if (c == '{' || c == '[') {
                    depth++
                } else if (c == '}' || c == ']') {
                    depth--
                    if (depth == 0) return i
                }
            }
            i++
        }
        return -1
    }

    /** ld+json / application/json scripts and `window.X = {...}` assignments. */
    fun jsonBlobs(html: String): List<Any> {
        val out = ArrayList<Any>()
        try {
            val doc = Jsoup.parse(html)
            for (s in doc.select("script[type=\"application/ld+json\"], script[type=\"application/json\"]")) {
                val parsed = parseJson(s.data())
                if (parsed != null) out.add(parsed)
            }
        } catch (e: Exception) {
            // ignore, fall through to the window.X scan
        }
        for (m in ASSIGN_RX.findAll(html)) {
            if (out.size > 14) break
            val start = m.range.last + 1
            if (start >= html.length) break
            val end = matchClose(html, start)
            if (end > start) {
                val parsed = parseJson(html.substring(start, end + 1))
                if (parsed != null) out.add(parsed)
            }
        }
        return out
    }

    private fun JSONObject.v(key: String): Any? {
        if (!has(key) || isNull(key)) return null
        val x = opt(key)
        if (x is String && x.isBlank()) return null
        if (x is JSONArray && x.length() == 0) return null
        if (x is JSONObject && x.length() == 0) return null
        return x
    }

    private fun JSONObject.firstOf(keys: List<String>): Any? {
        for (k in keys) {
            val x = v(k)
            if (x != null) return x
        }
        return null
    }

    private fun asStr(x: Any?): String? {
        if (x is String) return x
        if (x is JSONArray) return if (x.length() > 0) asStr(x.opt(0)) else null
        if (x is JSONObject) return asStr(x.firstOf(listOf("url", "src", "imageUrl", "value")))
        return null
    }

    private fun productFrom(o: JSONObject, base: String): Item? {
        val rawTitle = o.firstOf(TITLE_KEYS) as? String ?: return null
        var title = clean(Parser.unescapeEntities(rawTitle, false))
        if (title.length < 4) return null

        var pv: Any? = o.firstOf(PRICE_KEYS)
        if (pv is JSONObject) pv = pv.firstOf(PRICE_INNER_KEYS)
        if (pv == null) {
            val offers = o.v("offers")
            val offer: JSONObject? = when (offers) {
                is JSONObject -> offers
                is JSONArray -> offers.optJSONObject(0)
                else -> null
            }
            if (offer != null) pv = offer.firstOf(listOf("price", "lowPrice"))
        }
        val price = toPrice(pv) ?: return null

        val url = asStr(o.firstOf(URL_KEYS))
        val img = asStr(o.firstOf(IMG_KEYS))
        if (url == null && img == null) return null

        val brandV = o.opt("brand")
        val brand = when (brandV) {
            is String -> brandV
            is JSONObject -> brandV.optString("name", "")
            else -> ""
        }
        if (brand.isNotBlank() && !title.lowercase().contains(brand.lowercase())) {
            title = "$brand $title"
        }

        val imgAbs = resolve(base, img)
        return Item(
            title = title,
            price = price,
            url = resolve(base, url),
            image = if (imgAbs != null && imgAbs.startsWith("http")) imgAbs else null,
            rating = toRating(o.firstOf(RATING_KEYS)),
            reviews = toCount(o.firstOf(COUNT_KEYS)),
        )
    }

    /** Finds product-looking objects anywhere inside a JSON structure (breadth-first, keeps page order). */
    fun walkProducts(root: Any, base: String): List<Item> {
        val found = ArrayList<Item>()
        val seen = HashSet<String>()
        val queue = ArrayList<Pair<Any, Int>>()
        queue.add(Pair(root, 0))
        var head = 0
        while (head < queue.size && found.size < 80 && queue.size < 200_000) {
            val entry = queue[head]
            head++
            val cur = entry.first
            val depth = entry.second
            if (depth > 25) continue
            if (cur is JSONArray) {
                for (i in 0 until cur.length()) {
                    val x = cur.opt(i)
                    if (x != null && (x is JSONObject || x is JSONArray)) queue.add(Pair(x, depth + 1))
                }
            } else if (cur is JSONObject) {
                val p = productFrom(cur, base)
                if (p != null && seen.add(p.title.lowercase() + "|" + p.price)) found.add(p)
                val keys = cur.keys()
                while (keys.hasNext()) {
                    val x = cur.opt(keys.next())
                    if (x != null && (x is JSONObject || x is JSONArray)) queue.add(Pair(x, depth + 1))
                }
            }
        }
        return found
    }

    // ───────── plain HTML product cards ─────────

    private fun distinctLinks(el: Element, rx: Regex): Int {
        val keys = HashSet<String>()
        for (a in el.select("a[href]")) {
            val h = a.attr("href")
            if (rx.containsMatchIn(h)) keys.add(h.substringBefore("?"))
            if (keys.size > 1) break
        }
        return keys.size
    }

    private fun firstImage(card: Element): String? {
        for (img in card.select("img")) {
            val s = img.absUrl("src").ifBlank { img.absUrl("data-src") }
            if (s.startsWith("http")) return s
        }
        return null
    }

    private fun cardTitle(anchor: Element, card: Element): String? {
        val t = anchor.attr("title")
        if (t.length >= 8) return clean(t)
        for (el in card.select("[title]")) {
            val x = el.attr("title")
            if (x.length >= 8) return clean(x)
        }
        for (img in card.select("img[alt]")) {
            val x = img.attr("alt")
            if (x.length >= 8) return clean(x)
        }
        for (el in card.select("*")) {
            val x = clean(el.ownText())
            if (x.length >= 12 && !x.startsWith("\u20B9") && !x.startsWith("Rs")) return x
        }
        return null
    }

    private fun cardPrice(card: Element): Int? {
        val dp = card.selectFirst("[data-price]")?.attr("data-price")
        if (!dp.isNullOrBlank()) {
            val p = toPrice(dp)
            if (p != null) return p
        }
        val m = PRICE_RX.find(card.text()) ?: return null
        return toPrice(m.groupValues[1])
    }

    private fun cardRating(card: Element): Double? {
        for (el in card.select("div, span")) {
            val x = el.ownText().trim()
            if (RATING_RX.matches(x)) return toRating(x)
        }
        return null
    }

    /**
     * For server-rendered pages: find links that look like product pages, climb to the card that
     * holds exactly that one product, and read title / price / image from the card.
     */
    fun anchorItems(html: String, base: String, linkRx: Regex): List<Item> {
        val doc = Jsoup.parse(html, base)
        val items = ArrayList<Item>()
        val used = HashSet<String>()
        for (a in doc.select("a[href]")) {
            val href = a.attr("href")
            if (!linkRx.containsMatchIn(href)) continue
            if (!used.add(href.substringBefore("?"))) continue

            var card: Element = a
            var steps = 0
            while (steps < 7) {
                val parent = card.parent() ?: break
                val tag = parent.tagName()
                if (tag == "body" || tag == "html") break
                if (distinctLinks(parent, linkRx) > 1) break
                card = parent
                steps++
            }

            val title = cardTitle(a, card) ?: continue
            val price = cardPrice(card) ?: continue
            items.add(
                Item(
                    title = title,
                    price = price,
                    url = resolve(base, href),
                    image = firstImage(card),
                    rating = cardRating(card),
                    reviews = null,
                ),
            )
        }
        return items
    }
}
