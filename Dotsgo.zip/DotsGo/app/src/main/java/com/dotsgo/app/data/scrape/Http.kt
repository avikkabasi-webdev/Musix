package com.dotsgo.app.data.scrape

import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Plain HTTP from the phone itself. No CORS here, because this is an app, not a web page. */
object Http {

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val jar = object : CookieJar {
        private val store = ConcurrentHashMap<String, List<Cookie>>()

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            val kept = store[url.host].orEmpty().filter { old -> cookies.none { it.name == old.name } }
            store[url.host] = kept + cookies
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val now = System.currentTimeMillis()
            return store[url.host].orEmpty().filter { it.expiresAt > now && it.matches(url) }
        }
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .cookieJar(jar)
        .build()

    fun get(
        url: String,
        accept: String = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        referer: String? = null,
    ): String {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept", accept)
            .header("Accept-Language", "en-IN,en;q=0.9")
        if (referer != null) builder.header("Referer", referer)

        val text: String = try {
            client.newCall(builder.build()).execute().use { resp ->
                val code = resp.code
                if (code == 401 || code == 403 || code == 429 || code == 503) {
                    throw StoreException("blocked the request (HTTP $code)")
                }
                if (!resp.isSuccessful) throw StoreException("HTTP $code")
                val body = resp.body ?: throw StoreException("empty response")
                body.string()
            }
        } catch (e: StoreException) {
            throw e
        } catch (e: UnknownHostException) {
            throw StoreException("no internet connection")
        } catch (e: IOException) {
            throw StoreException("could not connect")
        }
        return text
    }
}
