package com.dotsgo.app.data.scrape

/** One product as read from one store's page. */
data class Item(
    val title: String,
    val price: Int,
    val url: String?,
    val image: String?,
    val rating: Double?,
    val reviews: Int?,
)

/** Thrown when a store can't be read (blocked, captcha, offline...). The message is shown to the user. */
class StoreException(message: String) : Exception(message)
