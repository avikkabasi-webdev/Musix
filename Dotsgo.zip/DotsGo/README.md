# dots.go (Android)

Search once, compare prices across Indian shopping stores. The app reads the stores
itself on your phone: no server, no Firebase, no paid service, no mock data.

Structure matches the LastWave/Misu project (Gradle Kotlin DSL, version catalog,
`app/src/main/java/com/dotsgo/app/...`). Build with `./gradlew assembleDebug`.
