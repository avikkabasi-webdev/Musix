package com.lastwave.app.data.repository

import android.app.WallpaperManager
import android.content.Context
import android.os.Build
import androidx.compose.material3.ColorScheme
import androidx.compose.ui.graphics.Color
import com.lastwave.app.data.artwork.ArtworkNormalizer
import com.lastwave.app.data.artwork.ArtworkRepository
import com.lastwave.app.data.artwork.DeferredArtworkLookup
import com.lastwave.app.data.local.AccentMode
import com.lastwave.app.data.local.MiscSettings
import com.lastwave.app.data.local.SettingsPreferences
import com.lastwave.app.data.local.ThemePreferences
import com.lastwave.app.data.local.ThemePrefs
import com.lastwave.app.ui.theme.Md3SchemeBuilder
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import android.os.Handler
import android.os.Looper
import javax.inject.Inject
import com.lastwave.app.data.local.ThemeMode
import javax.inject.Singleton

data class ThemeUiState(
    val darkColorScheme: ColorScheme,
    val lightColorScheme: ColorScheme,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val colorScheme: ColorScheme,
    val amoled: Boolean,
    val mode: AccentMode,
    /** Raw hex of the manually-picked accent (preset or custom), independent
     *  of [colorScheme] — colorScheme.primary is a generated M3 tone of this
     *  seed, not the seed itself, so it can't be compared back against a
     *  preset's hex to know which one is selected. This can. */
    val accentColorHex: String,
    /** Settings' "Use Application Font" toggle — see ui/theme/Type.kt for
     *  what turning it off falls back to. */
    val useCustomFont: Boolean = true,
    /** Experimental liquid-glass materials (Settings → Experimental). When
     *  true, container roles in [colorScheme] are semi-translucent and the
     *  chrome surfaces get specular glass dressing. */
    val liquidGlass: Boolean = true,
    val md3NavBar: Boolean = false,
    /** True when the "Dynamic Now Playing" artwork override is currently
     *  driving the schemes. LastWaveTheme uses this so S+ system dynamic
     *  (wallpaper) only takes over when no now-playing color is active:
     *  now-playing wins, wallpaper-dynamic is next, manual/mono last. */
    val isNowPlayingThemed: Boolean = false,
)

@Singleton
class ThemeRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val themePreferences: ThemePreferences,
    private val settingsPreferences: SettingsPreferences,
    private val paletteExtractor: NowPlayingPaletteExtractor,
    private val artworkRepository: ArtworkRepository,
    private val homeRepository: HomeRepository,
    private val applicationScope: CoroutineScope,
) {
    /** Hex captured from the device wallpaper, when accentMode == DYNAMIC and
     *  a wallpaper color is available. Null falls back to the manual accent,
     *  same as _applyAccent()'s "dynamic saved but unavailable -> manual" rule. */
    private val dynamicHex = MutableStateFlow<String?>(null)

    /** Cache key (ArtworkNormalizer.cacheKey(name, artist)) of the currently-
     *  scrobbling track, or null when nothing is playing. This is what
     *  actually drives now-playing theming — see the init block below for
     *  why a raw artwork URL isn't tracked directly. */
    private val nowPlayingTrackKey = MutableStateFlow<String?>(null)

    /** Hex extracted from the currently-scrobbling track's artwork, when
     *  "Dynamic Now Playing Theme" is on. Null whenever nothing is playing,
     *  no artwork could be resolved from any provider, or extraction
     *  failed — see the init block below. */
    private val nowPlayingHex = MutableStateFlow<String?>(null)

    private val deferredArtwork = DeferredArtworkLookup(
        scope = applicationScope,
        source = "theme",
        hasMemoryHit = { key -> !artworkRepository.resolved.value[key].isNullOrBlank() },
        resolve = { name, artist ->
            try {
                artworkRepository.resolve(name, artist)
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Exception) {
                android.util.Log.w("ThemeRepository", "Artwork resolution unavailable", error)
            } catch (error: LinkageError) {
                android.util.Log.w("ThemeRepository", "Artwork resolution unsupported on this ROM", error)
            }
        },
    )

    init {
        // Bug fix: this used to read RecentTrack.artworkUrl straight off the
        // Last.fm API response and extract a palette from THAT. Last.fm's
        // own artwork field is blank for a large fraction of tracks — it's
        // exactly why the app already has an iTunes-fallback artwork
        // pipeline (ArtworkRepository) that every other artwork-showing
        // screen goes through. Now-playing theming skipped that pipeline
        // entirely, so on any track where Last.fm itself had no art, this
        // silently produced nothing and the accent never changed — which
        // is likely most of the time. Routing through the same
        // resolve()/resolved combo everything else uses fixes that, and
        // also means it stays reactive: resolve() is async (network +
        // disk cache), so this recomputes automatically the moment a
        // result lands, rather than needing a one-shot synchronous URL.
        applicationScope.launch {
            combine(nowPlayingTrackKey, artworkRepository.resolved) { key, resolvedMap ->
                key?.let { resolvedMap[it] }
            }.distinctUntilChanged().collect { url ->
                nowPlayingHex.value = if (url.isNullOrBlank()) {
                    null
                } else {
                    try {
                        paletteExtractor.extractAccentHex(url)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (error: Exception) {
                        android.util.Log.w("ThemeRepository", "Artwork accent unavailable", error)
                        null
                    } catch (error: LinkageError) {
                        android.util.Log.w("ThemeRepository", "Artwork accent unsupported on this ROM", error)
                        null
                    }
                }
            }
        }

        // Bug fix (Dynamic Color): refreshWallpaperAccent() used to be
        // called ONLY from setMode() — i.e. only at the exact moment the
        // user flips the toggle on. dynamicHex starts back at null every
        // process launch (it's a plain in-memory MutableStateFlow, nothing
        // persists it), so anyone who had Dynamic Color already enabled
        // from a previous session got dynamic == null on cold start, and
        // the `when` below fell straight through to the manual accent —
        // this is why the reported symptom was "wallpaper is purple but
        // the app still shows red": red (#E03030) is the manual accent's
        // own default, not a wallpaper color at all. Populating dynamicHex
        // here, once, whenever DYNAMIC is already the persisted mode,
        // closes that gap.
        applicationScope.launch {
            if (themePreferences.prefs.first().accentMode == AccentMode.DYNAMIC) {
                refreshWallpaperAccent()
            }
        }

        // "Refresh automatically whenever the wallpaper changes" — the
        // system callback for exactly that, rather than only ever
        // re-reading colors on toggle/cold-start. Registered unconditionally
        // (cheap, no permission beyond what getWallpaperColors already
        // needs) so a value is always ready the moment the user switches
        // into Dynamic mode, not just after the next wallpaper change.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            try {
                WallpaperManager.getInstance(context).addOnColorsChangedListener(
                    { _, which ->
                        if (which and WallpaperManager.FLAG_SYSTEM != 0) refreshWallpaperAccent()
                    },
                    Handler(Looper.getMainLooper()),
                )
            } catch (e: Exception) {
                android.util.Log.w("ThemeRepository", "Wallpaper listener unavailable", e)
                // Some OEM configurations restrict this — Dynamic Color
                // simply won't live-update on those devices; the
                // startup/toggle-time refresh above still works.
            } catch (error: LinkageError) {
                android.util.Log.w("ThemeRepository", "Wallpaper listener unsupported on this ROM", error)
            }
        }
    }

    /** Wallpaper seed for DYNAMIC mode on pre-S devices (and as the data-layer
     *  fallback on S+ — the real S+ wallpaper Monet scheme is applied in
     *  LastWaveTheme via dynamicDark/LightColorScheme, which are @Composable
     *  and can never be called from here). Reads only
     *  WallpaperManager.getWallpaperColors(), safe on any thread. */
    private fun getSystemWallpaperColorHex(): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) return null
        return try {
            val colors = WallpaperManager.getInstance(context).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            colors?.primaryColor?.let {
                "#%02X%02X%02X".format(
                    (it.red() * 255).toInt(),
                    (it.green() * 255).toInt(),
                    (it.blue() * 255).toInt(),
                )
            }
        } catch (e: Exception) {
            null
        } catch (error: LinkageError) {
            null
        }
    }

    val uiState: StateFlow<ThemeUiState> = combine(
        themePreferences.prefs,
        dynamicHex,
        nowPlayingHex,
        settingsPreferences.settings,
    ) { prefs: ThemePrefs, dynamic: String?, nowPlaying: String?, misc: MiscSettings ->
        val isAmoled = prefs.amoled
        val isGlass = prefs.liquidGlass
        val nowPlayingActive = misc.dynamicNowPlayingEnabled && nowPlaying != null
        val (darkScheme, lightScheme) = when {
            nowPlayingActive -> {
                val dark = Md3SchemeBuilder.buildDarkScheme(nowPlaying!!, isAmoled, isGlass)
                val light = Md3SchemeBuilder.buildLightScheme(nowPlaying, isGlass)
                dark to light
            }
            prefs.accentMode == AccentMode.MONOCHROME -> {
                val dark = Md3SchemeBuilder.buildMonochromeDarkScheme(isAmoled, isGlass)
                val light = Md3SchemeBuilder.buildMonochromeLightScheme(isGlass)
                dark to light
            }
            prefs.accentMode == AccentMode.DYNAMIC -> {
                // Wallpaper seed for the data layer. On S+ the real Monet
                // dynamic scheme is applied in LastWaveTheme (composable);
                // here we only need a wallpaper-derived fallback so pre-S
                // and cold-start frames already show the wallpaper accent
                // instead of the default red or monochrome.
                val seed = dynamic ?: getSystemWallpaperColorHex() ?: prefs.accentColor
                val dark = Md3SchemeBuilder.buildDarkScheme(seed, isAmoled, isGlass)
                val light = Md3SchemeBuilder.buildLightScheme(seed, isGlass)
                dark to light
            }
            else -> {
                val dark = Md3SchemeBuilder.buildDarkScheme(prefs.accentColor, isAmoled, isGlass)
                val light = Md3SchemeBuilder.buildLightScheme(prefs.accentColor, isGlass)
                dark to light
            }
        }
        ThemeUiState(
            darkColorScheme = darkScheme,
            lightColorScheme = lightScheme,
            themeMode = prefs.themeMode,
            colorScheme = darkScheme,
            amoled = isAmoled,
            mode = prefs.accentMode,
            accentColorHex = prefs.accentColor,
            useCustomFont = misc.useCustomFont,
            liquidGlass = isGlass,
            md3NavBar = prefs.md3NavBar,
            isNowPlayingThemed = nowPlayingActive,
        )
    }.stateIn(
        applicationScope,
        SharingStarted.Eagerly,
        ThemeUiState(
            darkColorScheme = Md3SchemeBuilder.buildMonochromeDarkScheme(false, true),
            lightColorScheme = Md3SchemeBuilder.buildMonochromeLightScheme(true),
            themeMode = ThemeMode.SYSTEM,
            colorScheme = Md3SchemeBuilder.buildMonochromeDarkScheme(false, true),
            amoled = false,
            mode = AccentMode.MONOCHROME,
            accentColorHex = "#E03030",
            useCustomFont = true,
            liquidGlass = true,
            md3NavBar = false,
        ),
    )

    suspend fun setThemeMode(mode: ThemeMode) {
        themePreferences.setThemeMode(mode)
    }

    /** Manual pick always leaves DYNAMIC/MONOCHROME: choosing your own accent
     *  turns Dynamic Color off itself (ThemePreferences persists MANUAL). */
    suspend fun setManualAccent(color: Color) {
        val hex = color.toHex()
        themePreferences.setManualAccent(hex, hex)
    }

    suspend fun setMode(mode: AccentMode) {
        if (mode == AccentMode.DYNAMIC) refreshWallpaperAccent()
        themePreferences.setMode(mode)
    }

    suspend fun setAmoled(enabled: Boolean) = themePreferences.setAmoled(enabled)

    suspend fun setLiquidGlass(enabled: Boolean) = themePreferences.setLiquidGlass(enabled)

    suspend fun setMd3NavBar(enabled: Boolean) = themePreferences.setMd3NavBar(enabled)

    /** Turning this on used to just flip the DataStore flag and wait for
     *  Home's own poll loop to eventually call updateNowPlayingArtwork() —
     *  if the user was sitting on Settings (as anyone testing the toggle
     *  would be) that could mean no visible change until they next visited
     *  Home. Now enabling it also fetches the current now-playing status
     *  directly, so the accent updates right away wherever the toggle was
     *  flipped from, same as Home's own poll cycle would produce. */
    suspend fun setDynamicNowPlaying(enabled: Boolean) {
        settingsPreferences.setDynamicNowPlaying(enabled)
        if (enabled) refreshNowPlayingImmediately()
    }

    private suspend fun refreshNowPlayingImmediately() {
        try {
            val page = homeRepository.fetchRecentTracks(page = 1, limit = 1).getOrNull()
            val track = page?.nowPlaying
            updateNowPlayingArtwork(track?.name, track?.artist?.displayName)
        } catch (e: Exception) {
            // Best-effort only — the regular Home poll loop will catch up
            // once the user visits Home, same as before this method existed.
        }
    }

    fun refreshWallpaperAccent() {
        dynamicHex.value = getSystemWallpaperColorHex()
    }

    /**
     * Called from HomeViewModel whenever the polled "now playing" track
     * changes (including becoming null — nothing scrobbling right now).
     * Cheap to call on every poll tick: the key dedup below means
     * resolve() only fires once per distinct track, not once per poll.
     *
     * Resolution itself goes through ArtworkRepository — the same
     * Last.fm -> iTunes fallback chain and memory/disk cache every other
     * artwork-showing screen uses — so this benefits from whatever's
     * already cached for that track and won't hammer either provider.
     */
    fun updateNowPlayingArtwork(trackName: String?, artistName: String?) {
        if (trackName.isNullOrBlank() || artistName.isNullOrBlank()) {
            nowPlayingTrackKey.value = null
            deferredArtwork.cancel()
            return
        }
        val key = ArtworkNormalizer.cacheKey(trackName, artistName)
        if (key == nowPlayingTrackKey.value) return
        nowPlayingTrackKey.value = key
        deferredArtwork.request(trackName, artistName)
    }

    private fun Color.toHex(): String = "#%02X%02X%02X".format(
        (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt(),
    )
}
