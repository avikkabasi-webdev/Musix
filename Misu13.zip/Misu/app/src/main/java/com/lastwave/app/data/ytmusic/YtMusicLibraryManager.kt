package com.lastwave.app.data.ytmusic

import android.content.Context
import com.lastwave.app.data.generate.GeneratedTrack
import com.lastwave.app.data.generate.StoredTrack
import com.lastwave.app.data.generate.normalizeTrackText
import com.lastwave.app.data.generate.toGenerated
import com.lastwave.app.data.generate.toStored
import com.lastwave.app.data.generate.youtubeVideoIdOrNull
import com.lastwave.app.data.music.InnerTubeMusicApi
import com.lastwave.app.data.music.YouTubeMusicTrack
import com.lastwave.app.data.music.YouTubePlaylistSummary
import com.lastwave.app.data.music.distinctPlaylistSongs
import com.lastwave.app.data.playlist.PlaylistImportManager
import com.lastwave.app.data.playlist.PlaylistRepository
import com.lastwave.app.data.playlist.SavedPlaylist
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.dropWhile
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
private data class YtCachedDetail(
    val id: Long,
    val title: String,
    val subtitle: String,
    val remotePlaylistId: String,
    val remoteArtworkUrl: String? = null,
    val remoteTrackCount: Int? = null,
    val tracks: List<StoredTrack> = emptyList(),
    val cachedAtMillis: Long = 0L,
    val playlistContentVersion: Int = 0,
)

/** Connected YouTube playlists as live library items; importing is optional. */
@Singleton
class YtMusicLibraryManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val auth: YtMusicAuthManager,
    private val preferences: YtMusicPreferences,
    private val innerTube: InnerTubeMusicApi,
    private val importManager: PlaylistImportManager,
    private val playlistRepository: PlaylistRepository,
    private val applicationScope: CoroutineScope,
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val cacheDir by lazy {
        File(context.cacheDir, "yt_remote_playlists").apply { mkdirs() }
    }

    private val _accountPlaylists = MutableStateFlow<List<YouTubePlaylistSummary>>(emptyList())
    val accountPlaylists: StateFlow<List<YouTubePlaylistSummary>> = _accountPlaylists.asStateFlow()
    private val _libraryReady = MutableStateFlow(false)
    val libraryReady: StateFlow<Boolean> = _libraryReady.asStateFlow()
    private val details = ConcurrentHashMap<Long, SavedPlaylist>()
    val playlists: StateFlow<List<SavedPlaylist>> = combine(
        _accountPlaylists,
        preferences.hiddenLibraryPlaylistIds,
        preferences.pinnedLibraryPlaylistIds,
        preferences.playlistMappings.catch { emit(emptyMap()) },
        playlistRepository.playlists,
    ) { account, hiddenIds, pinnedIds, mappings, local ->
        val localIds = local.mapTo(mutableSetOf()) { it.id }
        val linkedRemoteIds = mappings.filterKeys { it in localIds }.values
            .mapTo(mutableSetOf()) { it.remotePlaylistId.removePrefix("VL") }
        val localHasLiked = local.any { it.mode == com.lastwave.app.data.playlist.LIKED_SONGS_MODE }
        account.filterNot {
            it.id in hiddenIds ||
            it.id.removePrefix("VL") in linkedRemoteIds ||
            (localHasLiked && (it.id == "LM" || it.id == "FEmusic_liked_videos" || it.id.removePrefix("VL") == "LM"))
        }.map { summary ->
            summaryToPlaylist(summary).copy(isPinned = summary.id in pinnedIds)
        }
    }.stateIn(applicationScope, SharingStarted.Eagerly, emptyList())

    private val remoteIdsByLocalId = ConcurrentHashMap<Long, String>()
    private val ownedPlaylistCache = ConcurrentHashMap<Long, Pair<Long, com.lastwave.app.data.music.YtOwnedPlaylist>>()
    private val ownedPlaylistLocks = ConcurrentHashMap<Long, Mutex>()
    private val knownArtworkByRemoteId = ConcurrentHashMap<String, String>()
    private val artworkRequests = ConcurrentHashMap.newKeySet<String>()
    private val artworkRetryAfter = ConcurrentHashMap<String, Long>()
    private val artworkRequestLimiter = Semaphore(4)
    private val refreshMutex = Mutex()

    init {
        applicationScope.launch(Dispatchers.IO) {
            try {
                preferences.cachedLibraryPlaylists().forEach { item ->
                    item.artworkUrl?.takeIf(String::isNotBlank)?.let {
                        knownArtworkByRemoteId[item.id] = it
                    }
                }
                cacheDir.listFiles()?.forEach { file ->
                    val raw = file.readText()
                    val cached = json.decodeFromString<YtCachedDetail>(raw)
                    cached.remoteArtworkUrl?.takeIf(String::isNotBlank)?.let {
                        knownArtworkByRemoteId[cached.remotePlaylistId] = it
                    }
                }
            } catch (_: Exception) {}
        }
        applicationScope.launch {
            val persistedConnection = preferences.connection.first()
            auth.connection.first { it == persistedConnection }
            handleConnection(persistedConnection)
            auth.connection.dropWhile { it == persistedConnection }.collect(::handleConnection)
        }
        // InnerTube has no push subscription. Short foreground-process polling
        // gives connected playlists near-real-time behavior without importing.
        applicationScope.launch {
            while (true) {
                delay(REALTIME_REFRESH_MS)
                if (auth.connection.value.isConnected) refresh()
            }
        }
    }

    private suspend fun handleConnection(connection: YtConnection) {
        if (connection.isConnected) {
            if (_accountPlaylists.value.isEmpty()) {
                val cached = preferences.cachedLibraryPlaylists().map { it.toSummary() }
                if (cached.isNotEmpty()) publish(cached)
            }
            val visibleRemoteIds = preferences.hiddenLibraryPlaylistIds.first().let { hiddenIds ->
                _accountPlaylists.value.mapNotNull { it.id.takeUnless(hiddenIds::contains) }.toSet()
            }
            playlists.first { projected ->
                projected.mapNotNull(SavedPlaylist::remotePlaylistId).toSet() == visibleRemoteIds
            }
            _libraryReady.value = true
            refresh()
            return
        }

        remoteIdsByLocalId.clear()
        details.clear()
        knownArtworkByRemoteId.clear()
        artworkRetryAfter.clear()
        _accountPlaylists.value = emptyList()
        clearDiskCache()
        _libraryReady.value = true
    }

    suspend fun refresh() = refreshMutex.withLock {
        withContext(Dispatchers.IO) {
            if (!auth.connection.value.isConnected) return@withContext
            try {
                val fetched = innerTube.fetchLibraryPlaylists().distinctBy { it.id }
                // ArchiveTune uses the same non-destructive rule: an empty
                // library response is not authoritative. InnerTube can return
                // a structurally valid but empty page while auth/config is
                // settling, so never replace the last visible snapshot with it.
                if (fetched.isEmpty()) return@withContext
                val stablePlaylists = publish(fetched)
                preferences.setCachedLibraryPlaylists(stablePlaylists.map { it.toCache() })
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                // Keep the last successful account library visible while offline.
            }
        }
    }

    private fun publish(account: List<YouTubePlaylistSummary>): List<YouTubePlaylistSummary> {
        // Keep the complete account snapshot. Visibility is a separate,
        // persisted projection, so refresh/import/sync cannot reset it.
        // The account's Liked Music (LM) is not returned by
        // FEmusic_liked_playlists, so inject it as a synthetic head entry —
        // importing it merges into the local Liked Songs playlist.
        val withLiked = if (account.any { it.id.removePrefix("VL") == "LM" }) {
            account
        } else {
            listOf(
                YouTubePlaylistSummary(
                    id = LIKED_MUSIC_REMOTE_ID,
                    title = "Liked Music",
                    author = "YouTube Music",
                    trackCountText = null,
                    artworkUrl = null,
                ),
            ) + account
        }
        val previous = _accountPlaylists.value.associateBy(YouTubePlaylistSummary::id)
        val stableAccount = withLiked.map { summary ->
            val previousSummary = previous[summary.id]
            val localId = stableRemoteId(summary.id)
            val diskArtwork = readFromDiskCache(localId)?.remoteArtworkUrl
            val resolvedArt = summary.artworkUrl.normalizedRemoteArtwork()
                ?: knownArtworkByRemoteId[summary.id]?.normalizedRemoteArtwork()
                ?: (previousSummary?.artworkUrl).normalizedRemoteArtwork()
                ?: diskArtwork.normalizedRemoteArtwork()
            if (!resolvedArt.isNullOrBlank()) {
                knownArtworkByRemoteId[summary.id] = resolvedArt
            }
            summary.copy(
                artworkUrl = resolvedArt,
                trackCountText = summary.trackCountText?.takeIf { parseTrackCount(it) != null }
                    ?: previousSummary?.trackCountText,
            )
        }
        val allRemote = stableAccount.map(::summaryToPlaylist)
        _accountPlaylists.value = stableAccount
        remoteIdsByLocalId.clear()
        allRemote.forEach { playlist ->
            playlist.remotePlaylistId?.let { remoteIdsByLocalId[playlist.id] = it }
        }
        // Fill missing covers without downloading every continuation page of
        // large connected playlists.
        applicationScope.launch {
            allRemote.filter { it.remoteArtworkUrl.isNullOrBlank() }.forEach { playlist ->
                val remoteId = playlist.remotePlaylistId ?: return@forEach
                if (System.currentTimeMillis() < (artworkRetryAfter[remoteId] ?: 0L)) return@forEach
                if (!artworkRequests.add(remoteId)) return@forEach
                launch(Dispatchers.IO) {
                    try {
                        artworkRequestLimiter.withPermit {
                            val cached = readFromDiskCache(playlist.id)
                            if (cached != null) details.putIfAbsent(playlist.id, cached)
                            val cachedArtwork = (cached?.remoteArtworkUrl).normalizedRemoteArtwork()
                                ?: knownArtworkByRemoteId[remoteId]?.normalizedRemoteArtwork()
                                ?: cached?.tracks?.firstNotNullOfOrNull {
                                    it.artworkUrl?.takeIf(String::isNotBlank)
                                }
                            val artwork = (cachedArtwork ?: innerTube.fetchPlaylistArtwork(remoteId))
                                .normalizedRemoteArtwork()
                            if (artwork == null) {
                                artworkRetryAfter[remoteId] = System.currentTimeMillis() + ARTWORK_RETRY_DELAY_MS
                            } else {
                                artworkRetryAfter.remove(remoteId)
                                publishArtwork(remoteId, artwork)
                            }
                        }
                    } finally {
                        artworkRequests.remove(remoteId)
                    }
                }
            }
        }
        return stableAccount
    }

    private fun readFromDiskCache(localId: Long): SavedPlaylist? {
        return try {
            val file = File(cacheDir, "$localId.json")
            if (!file.exists()) return null
            val raw = file.readText()
            val cached = json.decodeFromString<YtCachedDetail>(raw)
            if (cached.playlistContentVersion != PLAYLIST_CONTENT_VERSION) return null
            SavedPlaylist(
                id = cached.id,
                title = cached.title,
                subtitle = cached.subtitle,
                mode = "youtube_remote",
                tracks = cached.tracks.map(StoredTrack::toGenerated),
                createdAtMillis = 0L,
                remotePlaylistId = cached.remotePlaylistId,
                remoteArtworkUrl = cached.remoteArtworkUrl,
                remoteTrackCount = cached.remoteTrackCount,
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun writeToDiskCache(localId: Long, playlist: SavedPlaylist) {
        if (playlist.remoteTrackCount == null) return
        try {
            val file = File(cacheDir, "$localId.json")
            val cached = YtCachedDetail(
                id = playlist.id,
                title = playlist.title,
                subtitle = playlist.subtitle,
                remotePlaylistId = playlist.remotePlaylistId ?: return,
                remoteArtworkUrl = playlist.remoteArtworkUrl,
                remoteTrackCount = playlist.remoteTrackCount,
                tracks = playlist.tracks.map(GeneratedTrack::toStored),
                cachedAtMillis = System.currentTimeMillis(),
                playlistContentVersion = PLAYLIST_CONTENT_VERSION,
            )
            file.writeText(json.encodeToString(cached))
        } catch (_: Exception) {
        }
    }

    private fun clearDiskCache() {
        try {
            cacheDir.listFiles()?.forEach { it.delete() }
        } catch (_: Exception) {
        }
    }

    suspend fun loadDetail(
        localId: Long,
        onUpdate: ((SavedPlaylist) -> Unit)? = null,
    ): SavedPlaylist? = withContext(Dispatchers.IO) {
        // 1. Check in-memory cache for immediate zero-latency result
        details[localId]?.takeIf { it.tracks.isNotEmpty() && it.remoteTrackCount != null }?.let { mem ->
            onUpdate?.invoke(mem)
            return@withContext mem
        }

        // 2. Check persistent disk cache for instant startup load
        val disk = readFromDiskCache(localId)
        if (disk != null && disk.tracks.isNotEmpty() && disk.remoteTrackCount != null) {
            details[localId] = disk
            onUpdate?.invoke(disk)
            // Trigger background refresh so any playlist changes on YouTube are updated
            applicationScope.launch {
                refreshDetailFromNetwork(localId, onUpdate)
            }
            return@withContext disk
        }

        var remoteId = remoteIdsByLocalId[localId]
        if (remoteId == null) {
            refresh()
            remoteId = remoteIdsByLocalId[localId]
        }
        val resolvedRemoteId = remoteId ?: return@withContext disk

        val summary = _accountPlaylists.value.firstOrNull { stableRemoteId(it.id) == localId || it.id == resolvedRemoteId }

        // Immediately seed details and UI with summary to avoid blank flash/0 songs
        if (summary != null) {
            val stub = disk ?: summaryToPlaylist(summary)
            details[localId] = stub
            onUpdate?.invoke(stub)
        }

        refreshDetailFromNetwork(localId, onUpdate)
    }

    private suspend fun refreshDetailFromNetwork(
        localId: Long,
        onUpdate: ((SavedPlaylist) -> Unit)? = null,
    ): SavedPlaylist? = withContext(Dispatchers.IO) {
        val remoteId = remoteIdsByLocalId[localId] ?: return@withContext details[localId]
        val summary = _accountPlaylists.value.firstOrNull { stableRemoteId(it.id) == localId || it.id == remoteId }

        val result = innerTube.fetchPlaylist(remoteId) { partialSongs ->
            val partialArtwork = summary?.artworkUrl?.takeIf(String::isNotBlank)
                ?: partialSongs.firstNotNullOfOrNull { it.artworkUrl?.takeIf(String::isNotBlank) }
            publishArtwork(remoteId, partialArtwork)
            val partialPlaylist = SavedPlaylist(
                id = localId,
                title = summary?.title?.takeIf { it.isNotBlank() } ?: "YouTube Playlist",
                subtitle = "YouTube Music • Connected account",
                mode = "youtube_remote",
                tracks = partialSongs.distinctPlaylistSongs().map(YouTubeMusicTrack::toGeneratedTrack),
                createdAtMillis = 0L,
                remotePlaylistId = remoteId,
                remoteArtworkUrl = partialArtwork,
                remoteTrackCount = null,
            )
            details[localId] = partialPlaylist
            onUpdate?.invoke(partialPlaylist)
        } ?: run {
            val fallback = details[localId] ?: readFromDiskCache(localId)
            if (fallback != null) onUpdate?.invoke(fallback)
            return@withContext fallback
        }

        val title = if (result.title.isNotBlank() && result.title != "Imported Playlist") {
            result.title
        } else {
            summary?.title?.takeIf { it.isNotBlank() } ?: "YouTube Playlist"
        }
        val artworkUrl = result.artworkUrl?.takeIf(String::isNotBlank)
            ?: summary?.artworkUrl?.takeIf(String::isNotBlank)
            ?: result.tracks.firstNotNullOfOrNull { it.artworkUrl?.takeIf(String::isNotBlank) }
        publishArtwork(remoteId, artworkUrl)
        val trackCount = result.trackCount

        val playlist = SavedPlaylist(
            id = localId,
            title = title,
            subtitle = "YouTube Music • Connected account",
            mode = "youtube_remote",
            tracks = result.tracks.distinctPlaylistSongs().map(YouTubeMusicTrack::toGeneratedTrack),
            createdAtMillis = 0L,
            remotePlaylistId = result.id,
            remoteArtworkUrl = artworkUrl,
            // Track count is unknown when continuation pages failed — leave it
            // null so loadDetail treats this as refreshable instead of
            // serving a truncated snapshot as final.
            remoteTrackCount = trackCount.takeIf { result.isComplete },
        )
        details[localId] = playlist
        if (result.isComplete) {
            writeToDiskCache(localId, playlist)
            updateRemoteTrackCount(remoteId, trackCount)
        }
        onUpdate?.invoke(playlist)
        playlist
    }

    private fun publishArtwork(remoteId: String, artworkUrl: String?) {
        val resolvedArtwork = artworkUrl.normalizedRemoteArtwork() ?: return
        knownArtworkByRemoteId[remoteId] = resolvedArtwork
        _accountPlaylists.update { playlists ->
            playlists.map { summary ->
                if (summary.id == remoteId && summary.artworkUrl.isNullOrBlank()) {
                    summary.copy(artworkUrl = resolvedArtwork)
                } else {
                    summary
                }
            }
        }
        val localId = stableRemoteId(remoteId)
        details[localId]?.let { cur ->
            if (cur.remoteArtworkUrl.isNullOrBlank()) {
                val updated = cur.copy(remoteArtworkUrl = resolvedArtwork)
                details[localId] = updated
                writeToDiskCache(localId, updated)
            }
        }
        applicationScope.launch(Dispatchers.IO) {
            preferences.setCachedLibraryPlaylists(_accountPlaylists.value.map { it.toCache() })
        }
    }

    private fun String?.normalizedRemoteArtwork(): String? {
        val value = this?.trim()?.takeIf(String::isNotBlank) ?: return null
        val normalized = when {
            value.startsWith("//") -> "https:$value"
            value.startsWith("https://") || value.startsWith("http://") -> value
            else -> null
        }
        return normalized?.let {
            if ((it.contains("googleusercontent.com") || it.contains("ggpht.com")) && '=' in it) {
                it.substringBeforeLast('=') + "=w512-h512-l90-rj"
            } else {
                it
            }
        }
    }

    suspend fun addTrack(
        localId: Long,
        track: GeneratedTrack,
        allowDuplicate: Boolean = false,
    ): Boolean = withContext(Dispatchers.IO) {
        val cachedPlaylist = details[localId] ?: readFromDiskCache(localId)
        val remoteId = cachedPlaylist?.remotePlaylistId
            ?: remoteIdsByLocalId[localId]
            ?: _accountPlaylists.value.firstOrNull { stableRemoteId(it.id) == localId }?.id
            ?: return@withContext false
        val exactVideoId = track.youtubeVideoIdOrNull()
        // Remote writes require an explicit YouTube identity on the track
        // itself (watch URL / videoId). A fuzzy search guess must never be
        // pushed: a wrong guess lands as a song the user never added in
        // their YouTube playlist, and the next sync pass then pulls it back
        // into the local copy — phantom + duplicated songs on both sides.
        // Same rule as the sync-path push guard in YtMusicSyncManager.
        val videoId = exactVideoId ?: return@withContext false
        val match: YouTubeMusicTrack? = null
        if (!allowDuplicate) {
            val playlist = cachedPlaylist?.takeIf { it.tracks.isNotEmpty() } ?: loadDetail(localId)
            if (playlist != null && playlist.tracks.any { it.matches(track, match) }) return@withContext false
        }
        val added = innerTube.addVideosToRemotePlaylist(remoteId, listOf(videoId))
        if (added) {
            ownedPlaylistCache.remove(localId)
            details.remove(localId)
            File(cacheDir, "$localId.json").delete()
            val currentCount = cachedPlaylist?.remoteTrackCount
                ?: cachedPlaylist?.tracks?.size
                ?: _accountPlaylists.value.firstOrNull { it.id == remoteId }?.trackCountText?.substringBefore(' ')?.replace(",", "")?.toIntOrNull()
                ?: 0
            updateRemoteTrackCount(remoteId, currentCount + 1)
        }
        added
    }

    /**
     * Mirrors a like/unlike from the player onto the connected YouTube Music
     * account. Best effort by design: a failure returns false for the caller
     * to surface, never to undo the local like.
     *
     * Returns true — explicitly not a failure — when there is nothing to
     * mirror: no account connected, or the track carries no YouTube videoId
     * (an imported local file). Those cases must not read as errors.
     */
    suspend fun mirrorLikeToYouTube(track: GeneratedTrack, loved: Boolean): Boolean {
        if (!auth.connection.value.isConnected) return true
        val videoId = track.youtubeVideoIdOrNull() ?: return true
        return if (loved) innerTube.likeVideo(videoId) else innerTube.removeVideoLike(videoId)
    }

    suspend fun findDuplicatePlaylistIds(
        localIds: Set<Long>,
        track: GeneratedTrack,
    ): Set<Long> = withContext(Dispatchers.IO) {
        if (localIds.isEmpty()) return@withContext emptySet()
        val directVideoId = track.youtubeVideoIdOrNull()
        val match = if (directVideoId == null) innerTube.findBestMatchOrNull(track.name, track.artist) else null
        localIds.filterTo(mutableSetOf()) { localId ->
            val cached = details[localId] ?: readFromDiskCache(localId)
            if (cached != null && cached.tracks.isNotEmpty()) {
                if (cached.tracks.any { it.matches(track, match) }) {
                    return@filterTo true
                }
            }
            val playlist = refreshDetailFromNetwork(localId) ?: loadDetail(localId)
            playlist?.tracks?.any { it.matches(track, match) } == true
        }
    }

    suspend fun findCachedDuplicatePlaylistIds(
        localIds: Set<Long>,
        track: GeneratedTrack,
    ): Set<Long> = withContext(Dispatchers.IO) {
        if (localIds.isEmpty()) return@withContext emptySet()
        val directVideoId = track.youtubeVideoIdOrNull()
        localIds.filterTo(mutableSetOf()) { localId ->
            val playlist = details[localId] ?: readFromDiskCache(localId)
            playlist?.tracks?.any { cachedTrack ->
                val cachedVideoId = cachedTrack.youtubeVideoIdOrNull()
                (directVideoId != null && cachedVideoId != null && cachedVideoId == directVideoId) ||
                    cachedTrack.key == track.key ||
                    (cachedTrack.name.equals(track.name, ignoreCase = true) && cachedTrack.artist.equals(track.artist, ignoreCase = true))
            } == true
        }
    }

    private fun GeneratedTrack.matches(original: GeneratedTrack, match: YouTubeMusicTrack?): Boolean {
        val videoId = youtubeVideoIdOrNull()
        val originalVideoId = original.youtubeVideoIdOrNull()
        return (videoId != null && videoId == originalVideoId) ||
            videoId == match?.videoId ||
            key == original.key ||
            (match != null && key == "${match.title.normalizeTrackText()}|${match.artist.normalizeTrackText()}".lowercase()) ||
            (name.equals(original.name, ignoreCase = true) && artist.equals(original.artist, ignoreCase = true))
    }

    suspend fun removeTrack(localId: Long, index: Int): SavedPlaylist? = withContext(Dispatchers.IO) {
        val playlist = loadDetail(localId) ?: return@withContext null
        val remoteId = playlist.remotePlaylistId ?: return@withContext null
        val target = playlist.tracks.getOrNull(index) ?: return@withContext playlist
        val targetVideoId = target.youtubeVideoIdOrNull() ?: return@withContext playlist
        val owned = getOwnedPlaylist(localId, remoteId, targetVideoId) ?: return@withContext playlist
        val item = owned.items.firstOrNull { it.videoId == targetVideoId && it.setVideoId != null }
        if (item != null) {
            if (!innerTube.removeVideosFromRemotePlaylist(remoteId, listOf(item.setVideoId!! to item.videoId))) {
                return@withContext playlist
            }
        } else if (!owned.complete) {
            return@withContext playlist
        }
        val remainingTracks = playlist.tracks.filterIndexed { i, _ -> i != index }
        val updatedPlaylist = playlist.copy(
            tracks = remainingTracks,
            remoteTrackCount = playlist.remoteTrackCount?.let { maxOf(0, it - 1) },
        )
        ownedPlaylistCache[localId] = System.currentTimeMillis() to owned.copy(
            items = if (item != null) owned.items.filterNot { it.setVideoId == item.setVideoId } else owned.items,
        )
        details[localId] = updatedPlaylist
        writeToDiskCache(localId, updatedPlaylist)
        updatedPlaylist.remoteTrackCount?.let { updateRemoteTrackCount(remoteId, it) }
        updatedPlaylist
    }

    private suspend fun getOwnedPlaylist(
        localId: Long,
        remoteId: String,
        targetVideoId: String?,
    ): com.lastwave.app.data.music.YtOwnedPlaylist? {
        val now = System.currentTimeMillis()
        ownedPlaylistCache[localId]?.takeIf {
            now - it.first < OWNED_PLAYLIST_CACHE_TTL_MS &&
                (targetVideoId == null || it.second.items.any { item -> item.videoId == targetVideoId && item.setVideoId != null })
        }?.let { return it.second }
        return ownedPlaylistLocks.getOrPut(localId) { Mutex() }.withLock {
            val lockedNow = System.currentTimeMillis()
            ownedPlaylistCache[localId]
                ?.takeIf {
                    lockedNow - it.first < OWNED_PLAYLIST_CACHE_TTL_MS &&
                        (targetVideoId == null || it.second.items.any { item -> item.videoId == targetVideoId && item.setVideoId != null })
                }
                ?.let { return@withLock it.second }
            innerTube.fetchOwnedPlaylist(remoteId, targetVideoId)?.let { fetched ->
                ownedPlaylistCache[localId] = lockedNow to fetched
                fetched
            }
        }
    }

    private fun updateRemoteTrackCount(remoteId: String, count: Int) {
        _accountPlaylists.value = _accountPlaylists.value.map { summary ->
            if (summary.id == remoteId || summary.id.removePrefix("VL") == remoteId.removePrefix("VL")) {
                summary.copy(trackCountText = "$count tracks")
            } else {
                summary
            }
        }
    }

    suspend fun makeLocal(localId: Long): SavedPlaylist? = withContext(Dispatchers.IO) {
        val remote = loadDetail(localId) ?: return@withContext null
        val remoteId = remote.remotePlaylistId ?: return@withContext null
        val result = innerTube.fetchPlaylist(remoteId) ?: return@withContext null
        // Liked Music merges into the built-in Liked Songs — never a mapped
        // `custom` copy, since LM is not editable via the playlist-edit API.
        val saved = if (PlaylistImportManager.isYtLikedId(result.id)) {
            importManager.importYtLikedIntoLikedSongs(result)
        } else {
            importManager.importOwnedYouTubePlaylist(result)
        }
        details.remove(localId)
        File(cacheDir, "$localId.json").delete()
        refresh()
        saved
    }

    suspend fun togglePinned(localId: Long, isPinned: Boolean) {
        val remoteId = remoteIdsByLocalId[localId]
            ?: details[localId]?.remotePlaylistId
            ?: _accountPlaylists.value.firstOrNull { stableRemoteId(it.id) == localId }?.id
            ?: return
        preferences.setPinned(remoteId, isPinned)
        details[localId]?.let { cur ->
            val updated = cur.copy(isPinned = isPinned)
            details[localId] = updated
            writeToDiskCache(localId, updated)
        }
    }

    private fun summaryToPlaylist(summary: YouTubePlaylistSummary): SavedPlaylist {
        val id = stableRemoteId(summary.id)
        val count = if (summary.id.removePrefix("VL") == "LM") {
            details[id]?.remoteTrackCount
        } else {
            summary.trackCountText?.let(::parseTrackCount)
        }
        val artwork = summary.artworkUrl ?: knownArtworkByRemoteId[summary.id]
        return SavedPlaylist(
            id = id,
            title = summary.title,
            subtitle = "YouTube Music • Connected account",
            mode = "youtube_remote",
            tracks = emptyList(),
            createdAtMillis = 0L,
            remotePlaylistId = summary.id,
            remoteArtworkUrl = artwork,
            remoteTrackCount = count,
        )
    }

    private fun parseTrackCount(text: String): Int? {
        val match = Regex("""([\d,.]+)\s*([KMB]?)""", RegexOption.IGNORE_CASE).find(text) ?: return null
        val value = match.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        val multiplier = when (match.groupValues[2].uppercase()) {
            "K" -> 1_000
            "M" -> 1_000_000
            "B" -> 1_000_000_000
            else -> 1
        }
        return (value * multiplier).toInt().coerceAtLeast(0)
    }

    private fun stableRemoteId(remoteId: String): Long {
        var hash = -0x340d631b7bdddcdbL
        remoteId.forEach { char ->
            hash = (hash xor char.code.toLong()) * 0x100000001b3L
        }
        return hash or Long.MIN_VALUE
    }

    private fun YtCachedLibraryPlaylist.toSummary() = YouTubePlaylistSummary(
        id = id,
        title = title,
        author = author,
        trackCountText = trackCountText,
        artworkUrl = artworkUrl,
    )

    private fun YouTubePlaylistSummary.toCache() = YtCachedLibraryPlaylist(
        id = id,
        title = title,
        author = author,
        trackCountText = trackCountText,
        artworkUrl = artworkUrl,
    )

    private companion object {
        const val LIKED_MUSIC_REMOTE_ID = "LM"
        const val PLAYLIST_CONTENT_VERSION = 2
        const val REALTIME_REFRESH_MS = 8_000L
        const val ARTWORK_RETRY_DELAY_MS = 5 * 60 * 1000L
        const val OWNED_PLAYLIST_CACHE_TTL_MS = 10 * 60 * 1000L
    }
}

internal fun YouTubeMusicTrack.toGeneratedTrack() = GeneratedTrack(
    name = title,
    artist = artist,
    album = album,
    artworkUrl = artworkUrl,
    url = "https://music.youtube.com/watch?v=$videoId",
)
