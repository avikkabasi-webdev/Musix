package com.lastwave.app.util

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.app.Activity
import android.content.ClipData
import android.content.ContextWrapper
import android.graphics.Bitmap
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.lastwave.app.data.generate.GeneratedTrack
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Native equivalent of bridge.js's saveFile()/shareFileContent(): writes an
 * export file to the app's external Documents dir (survives uninstall on
 * API<29's scoped-storage-exempt path, and is user-visible via a file
 * manager either way) and/or opens a system share sheet for it via
 * FileProvider — matching the original's Save + Share export actions.
 */
@Singleton
class FileExportHelper @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    companion object {
        private const val PUBLIC_EXPORT_SUBDIR = "LastWave"
        private const val PUBLIC_BACKUP_SUBDIR = "LastWave/Backups"
        private const val PUBLIC_PLAYLIST_SUBDIR = "LastWave/Playlists"
        private const val PLAYLIST_MIRROR_FILENAME = "lastwave-playlists.json"
        private const val PLAYLIST_RECOVERY_FILENAME = "lastwave-playlists-recovery.json"
        private const val MIRROR_PREFS = "playlist_file_mirror"
        private const val MIRROR_URI_KEY = "persisted_uri"
    }

    private fun documentsDir(): File {
        val dir = context.getExternalFilesDir("Documents") ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Writes [content] to a file named [filename] under app-external
     *  Documents/. Returns the written File on success. */
    fun saveToDocuments(filename: String, content: String): File {
        val file = File(documentsDir(), filename)
        file.writeText(content)
        return file
    }

    /** Writes [content] to a Uri the user picked via Storage Access
     *  Framework (ACTION_CREATE_DOCUMENT / CreateDocument contract).
     *
     *  Used for Backup export instead of [saveToDocuments]: files written
     *  under getExternalFilesDir() live in the app-private
     *  Android/data/<package>/ tree, which the system's document picker
     *  (the same picker Restore uses to open a file) does not browse into
     *  on modern Android — the backup would exist but be unreachable from
     *  Restore's file picker. Writing through a SAF Uri the user chose
     *  themselves guarantees the file is somewhere they can navigate back
     *  to later. */
    suspend fun writeTextToUri(uri: Uri, content: String): Long = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        runCatching {
            resolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        }
        val bytes = content.toByteArray(Charsets.UTF_8)
        var writeSucceeded = false

        // Attempt 1: ParcelFileDescriptor with direct hardware descriptor sync (bypasses buffered filesystem lag)
        val pfd = runCatching {
            resolver.openFileDescriptor(uri, "rwt")
                ?: resolver.openFileDescriptor(uri, "wt")
                ?: resolver.openFileDescriptor(uri, "w")
        }.getOrNull()

        if (pfd != null) {
            try {
                pfd.use { descriptor ->
                    java.io.FileOutputStream(descriptor.fileDescriptor).use { fos ->
                        fos.write(bytes)
                        fos.flush()
                        try {
                            descriptor.fileDescriptor.sync()
                        } catch (syncErr: Exception) {
                            // Ignored if provider doesn't support direct sync
                        }
                    }
                }
                writeSucceeded = true
            } catch (pfdError: Exception) {
                writeSucceeded = false
            }
        }

        // Attempt 2: Standard OutputStream fallback if PFD was rejected by DocumentProvider
        if (!writeSucceeded) {
            val stream = runCatching { resolver.openOutputStream(uri, "wt") }.getOrNull()
                ?: runCatching { resolver.openOutputStream(uri, "w") }.getOrNull()
                ?: resolver.openOutputStream(uri)
                ?: throw IOException("Couldn't open output stream for $uri")

            stream.use { output ->
                output.write(bytes)
                output.flush()
            }
        }

        bytes.size.toLong()
    }

    /** Reads raw text content from a SAF Uri on Dispatchers.IO. */
    suspend fun readTextFromUri(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            context.contentResolver.openInputStream(uri)?.use { input ->
                input.bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Opens the system share sheet for [filename]/[content] via
     *  FileProvider — mirrors shareFileContent()'s mime-typed file share. */
    fun shareFile(filename: String, content: String, mimeType: String) {
        val file = saveToDocuments(filename, content)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Share playlist").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Plain-text share fallback (used if file sharing isn't available for
     *  some reason) — mirrors shareText(). */
    fun shareText(text: String, subject: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /**
     * Unwraps [Context] hierarchy to find an [Activity] context for launching share dialogs.
     */
    private fun findActivity(context: Context): Activity? {
        var ctx = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    /**
     * Cache hygiene for share cards: purges files older than 24h and enforces a 10-file cap.
     */
    fun cleanLyricsCardCache(cacheDir: File) {
        val dir = File(cacheDir, "shared/lyrics_cards")
        if (!dir.exists()) return
        val files = dir.listFiles() ?: return
        val now = System.currentTimeMillis()
        val maxAge = 24 * 60 * 60 * 1000L

        for (file in files) {
            if (now - file.lastModified() > maxAge) {
                file.delete()
            }
        }

        val remaining = dir.listFiles() ?: return
        if (remaining.size > 10) {
            val sorted = remaining.sortedBy { it.lastModified() }
            val excess = remaining.size - 10
            for (i in 0 until excess) {
                sorted[i].delete()
            }
        }
    }

    /**
     * Exports a rendered bitmap to cacheDir/shared/lyrics_cards and triggers the system
     * share sheet via FileProvider with image/png and ClipData uri grant.
     */
    suspend fun shareImage(
        activityContext: Context,
        bitmap: Bitmap,
        title: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            cleanLyricsCardCache(context.cacheDir)
            val dir = File(context.cacheDir, "shared/lyrics_cards")
            if (!dir.exists()) dir.mkdirs()

            val sanitized = sanitizeFilename(title)
            val timestamp = System.currentTimeMillis()
            val file = File(dir, "lyrics_${sanitized}_$timestamp.png")

            file.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            }

            val authority = "${context.packageName}.provider"
            val uri = FileProvider.getUriForFile(context, authority, file)

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("Lyrics Card", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, "Share lyrics").apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val activity = findActivity(activityContext)
            if (activity != null) {
                activity.startActivity(chooser)
            } else {
                context.startActivity(chooser)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Saves a rendered card bitmap to Pictures/LastWave via MediaStore.Images
     * with IS_PENDING handling for API 29+.
     */
    suspend fun saveImageToGallery(
        bitmap: Bitmap,
        title: String,
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val sanitized = sanitizeFilename(title)
            val filename = "lyrics_${sanitized}_${System.currentTimeMillis()}.png"
            val relativePath = "${Environment.DIRECTORY_PICTURES}/LastWave"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Failed to create MediaStore entry for $filename")

            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            } ?: throw IOException("Failed to open output stream for $uri")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val updateValues = ContentValues().apply {
                    put(MediaStore.Images.Media.IS_PENDING, 0)
                }
                resolver.update(uri, updateValues, null, null)
            }

            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun sanitizeFilename(title: String): String =
        title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "playlist" }

    /**
     * Auto-saves a generated playlist as an M3U file to the public
     * Download/LastWave/ folder — separate from [saveToDocuments]'s
     * app-private export copy, and visible outside the app / after
     * uninstall. Always runs off the main thread. Never throws: genuine
     * failures come back as [Result.failure] for the caller to decide
     * whether to surface; an already-existing file (same playlist saved
     * before) is treated as success, not a failure, so callers don't
     * need their own duplicate-save tracking.
     */
    suspend fun savePlaylistToPublicDownloads(title: String, tracks: List<GeneratedTrack>): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val filename = "${sanitizeFilename(title)}.m3u"
                val content = PlaylistExportFormat.toM3u(title, tracks)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveViaMediaStore(filename, content)
                } else {
                    saveViaLegacyFile(filename, content)
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** Writes the complete playlist library to a user-visible JSON file
     * that lives outside app-private/cache storage and survives uninstall. */
    suspend fun writePublicPlaylistMirror(content: String): Result<Unit> = withContext(Dispatchers.IO) {
        // Write a complete recovery generation first. If the process or
        // device stops while the primary is being replaced, startup can
        // still recover the same snapshot from this companion file.
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                writeMirrorViaMediaStore(PLAYLIST_RECOVERY_FILENAME, content)
            } else {
                writeMirrorViaLegacyFile(PLAYLIST_RECOVERY_FILENAME, content)
            }
        }
        persistedPlaylistMirrorUri()?.let { uri ->
            runCatching { writeTextToUri(uri, content) }
                .onSuccess { return@withContext Result.success(Unit) }
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                writeMirrorViaMediaStore(PLAYLIST_MIRROR_FILENAME, content)
            } else {
                writeMirrorViaLegacyFile(PLAYLIST_MIRROR_FILENAME, content)
            }
        }
    }

    /** Reads the public mirror automatically when Android still grants
     * access. A clean reinstall can require selecting the file once. */
    suspend fun readPublicPlaylistMirror(): Result<String?> = withContext(Dispatchers.IO) {
        persistedPlaylistMirrorUri()?.let { uri ->
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()?.let { return@withContext Result.success(it) }
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) readMirrorViaMediaStore(PLAYLIST_MIRROR_FILENAME)
            else readMirrorViaLegacyFile(PLAYLIST_MIRROR_FILENAME)
        }
    }

    suspend fun readPublicPlaylistRecovery(): Result<String?> = withContext(Dispatchers.IO) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) readMirrorViaMediaStore(PLAYLIST_RECOVERY_FILENAME)
            else readMirrorViaLegacyFile(PLAYLIST_RECOVERY_FILENAME)
        }
    }

    /** Reconnects a mirror selected via ACTION_OPEN_DOCUMENT so subsequent
     * edits keep updating that exact file. */
    fun rememberPlaylistMirrorUri(uri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        context.getSharedPreferences(MIRROR_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(MIRROR_URI_KEY, uri.toString())
            .apply()
    }

    private fun persistedPlaylistMirrorUri(): Uri? =
        context.getSharedPreferences(MIRROR_PREFS, Context.MODE_PRIVATE)
            .getString(MIRROR_URI_KEY, null)
            ?.let(Uri::parse)

    private fun publicDownloadUri(filename: String): Uri? {
        val resolver = context.contentResolver
        val candidatePaths = listOf(
            "${Environment.DIRECTORY_DOWNLOADS}/$PUBLIC_BACKUP_SUBDIR/",
            "${Environment.DIRECTORY_DOWNLOADS}/$PUBLIC_EXPORT_SUBDIR/",
        )
        for (relativePath in candidatePaths) {
            val uri = resolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads._ID),
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?",
                arrayOf(filename, relativePath),
                "${MediaStore.Downloads.DATE_MODIFIED} DESC",
            )?.use { cursor ->
                if (!cursor.moveToFirst()) null
                else Uri.withAppendedPath(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)).toString(),
                )
            }
            if (uri != null) return uri
        }
        return null
    }

    private fun writeMirrorViaMediaStore(filename: String, content: String) {
        val resolver = context.contentResolver
        val existing = runCatching { publicDownloadUri(filename) }.getOrNull()
        if (existing != null) {
            val updated = runCatching {
                resolver.openOutputStream(existing, "wt")?.use {
                    it.write(content.toByteArray())
                } ?: throw IOException("Couldn't write $filename")
            }.isSuccess
            if (updated) return
        }

        val uri = resolver.insert(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, "application/json")
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$PUBLIC_BACKUP_SUBDIR")
            },
        ) ?: throw IOException("MediaStore refused to create $filename")
        resolver.openOutputStream(uri, "wt")?.use { it.write(content.toByteArray()) }
            ?: throw IOException("Couldn't write $filename")
    }

    private fun readMirrorViaMediaStore(filename: String): String? {
        val uri = publicDownloadUri(filename) ?: return null
        return context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
    }

    private fun writeMirrorViaLegacyFile(filename: String, content: String) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (!granted) throw SecurityException("Storage permission is required")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), PUBLIC_BACKUP_SUBDIR)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Couldn't create ${dir.path}")
        File(dir, filename).writeText(content)
    }

    private fun readMirrorViaLegacyFile(filename: String): String? {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (!granted) throw SecurityException("Storage permission is required")
        val candidateDirs = listOf(
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), PUBLIC_BACKUP_SUBDIR),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), PUBLIC_EXPORT_SUBDIR),
        )
        for (dir in candidateDirs) {
            val file = File(dir, filename)
            if (file.exists()) return file.readText()
        }
        return null
    }

    /** API 29+: MediaStore Downloads; no permission is needed for files
     * created by the current app installation. */
    private fun saveViaMediaStore(filename: String, content: String) {
        val resolver = context.contentResolver
        val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/$PUBLIC_PLAYLIST_SUBDIR"

        val alreadyExists = resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Downloads._ID),
            "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?",
            arrayOf(filename, "$relativePath/"),
            null,
        )?.use { it.moveToFirst() } ?: false
        if (alreadyExists) return

        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "audio/x-mpegurl")
            put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("MediaStore refused to create $filename")
        resolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            ?: throw IOException("Couldn't open output stream for $filename")
    }

    /** API 24-28: legacy public-storage File access, gated on the
     *  (dangerous, runtime-requested) WRITE_EXTERNAL_STORAGE permission.
     *  There's no Activity/UI context available from this layer to prompt
     *  for that permission, so if it isn't already granted this is a
     *  silent no-op rather than a crash or a confusing background error —
     *  the playlist is already safely stored in Room either way. */
    private fun saveViaLegacyFile(filename: String, content: String) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (!granted) return

        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), PUBLIC_PLAYLIST_SUBDIR)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Couldn't create ${dir.path}")
        val file = File(dir, filename)
        if (file.exists()) return
        file.writeText(content)
    }
}

/** Port of playlist.js's exportAsCsv()/exportAsM3u() content builders — pure
 *  functions kept outside the DI class for easy testing. */
object PlaylistExportFormat {
    private fun csvEscape(value: String): String {
        val needsQuoting = value.contains(',') || value.contains('"') || value.contains('\n')
        val escaped = value.replace("\"", "\"\"")
        return if (needsQuoting) "\"$escaped\"" else escaped
    }

    fun toCsv(tracks: List<GeneratedTrack>): String {
        val header = "Track,Artist"
        val rows = tracks.joinToString("\n") { "${csvEscape(it.name)},${csvEscape(it.artist)}" }
        return "$header\n$rows"
    }

    /** [templateLabel] matches the mode->label mapping used in the M3U
     *  filename, e.g. "AiMix", "MyRecommendation", "ByGenre",
     *  "SimilarTracks", "MyMix". */
    fun templateLabelFor(mode: String): String = when (mode) {
        "recommendations" -> "MyRecommendation"
        "tag" -> "ByGenre"
        "similar-tracks", "start-mix" -> "SimilarTracks"
        "mix" -> "MyMix"
        "discover" -> "AiMix"
        else -> "AiMix"
    }

    fun toM3u(title: String, tracks: List<GeneratedTrack>): String {
        val sb = StringBuilder()
        sb.append("#EXTM3U\n")
        sb.append("#PLAYLIST:$title\n")
        for (t in tracks) {
            sb.append("#EXTINF:-1,${t.artist} - ${t.name}\n")
            sb.append(if (t.url.isNotBlank()) t.url else "").append('\n')
        }
        return sb.toString()
    }
}
