package com.nothinggallery.app.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {

    /** Loads every image and video on the device, newest first. Works on Android 7+. */
    suspend fun load(): List<MediaItem> = withContext(Dispatchers.IO) {
        val result = ArrayList<MediaItem>()
        query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, isVideo = false, out = result)
        query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, isVideo = true, out = result)
        result.sortByDescending { it.dateMillis }
        result
    }

    private fun query(base: Uri, isVideo: Boolean, out: MutableList<MediaItem>) {
        val pathColumn = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.MediaColumns.RELATIVE_PATH
        } else {
            @Suppress("DEPRECATION")
            MediaStore.MediaColumns.DATA
        }

        val projection = ArrayList<String>().apply {
            add(MediaStore.MediaColumns._ID)
            add(MediaStore.MediaColumns.DISPLAY_NAME)
            add(MediaStore.MediaColumns.MIME_TYPE)
            add(MediaStore.MediaColumns.DATE_ADDED)
            add(MediaStore.Images.Media.DATE_TAKEN)
            add(MediaStore.MediaColumns.SIZE)
            add(MediaStore.MediaColumns.WIDTH)
            add(MediaStore.MediaColumns.HEIGHT)
            add(MediaStore.Images.Media.BUCKET_ID)
            add(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            add(pathColumn)
            if (isVideo) add(MediaStore.Video.Media.DURATION)
        }.toTypedArray()

        context.contentResolver.query(
            base, projection, null, null,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iW = c.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
            val iH = c.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
            val iBucketId = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val iPath = c.getColumnIndexOrThrow(pathColumn)
            val iDur = if (isVideo) c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION) else -1

            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val taken = c.getLong(iTaken)
                val date = if (taken > 0) taken else c.getLong(iAdded) * 1000L
                val rawPath = c.getString(iPath) ?: ""
                // Before Android 10 the column is the full file path; keep just the folder.
                val path = if (Build.VERSION.SDK_INT >= 29) rawPath else rawPath.substringBeforeLast('/', "")
                out.add(
                    MediaItem(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        name = c.getString(iName) ?: "",
                        mime = c.getString(iMime) ?: "",
                        isVideo = isVideo,
                        dateMillis = date,
                        size = c.getLong(iSize),
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        durationMs = if (iDur >= 0) c.getLong(iDur) else 0L,
                        bucketId = c.getLong(iBucketId),
                        bucket = c.getString(iBucket) ?: "",
                        path = path,
                    )
                )
            }
        }
    }
}
