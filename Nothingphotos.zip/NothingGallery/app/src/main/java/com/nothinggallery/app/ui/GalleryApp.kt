package com.nothinggallery.app.ui

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.nothinggallery.app.data.MediaItem
import com.nothinggallery.app.data.buildAlbums
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val NavHeight = 110.dp

@Composable
fun GalleryApp(vm: GalleryViewModel) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme

    var granted by remember { mutableStateOf(hasMediaAccess(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasMediaAccess(context) }

    // Re-check on resume: the user may have changed the permission in system settings.
    LifecycleResumeEffect(Unit) {
        granted = hasMediaAccess(context)
        onPauseOrDispose { }
    }
    LaunchedEffect(granted) { vm.setAccess(granted) }

    // Android 11+: one system "move to trash" confirmation for the whole batch.
    // Android 10: files are deleted one by one, asking permission per file when required.
    var pendingTrash by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var legacyQueue by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var legacyDeleted by remember { mutableStateOf<List<String>>(emptyList()) }
    var legacyTick by remember { mutableIntStateOf(0) }

    val trashLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val ok = result.resultCode == Activity.RESULT_OK
        if (Build.VERSION.SDK_INT >= 30) {
            if (ok) vm.onTrashed(pendingTrash.map { it.key })
            pendingTrash = emptyList()
        } else if (ok) {
            legacyTick++            // permission granted: retry the same file
        } else {
            legacyQueue = emptyList() // user declined: stop (already deleted files are finalized below)
        }
    }

    LaunchedEffect(legacyQueue, legacyTick) {
        if (legacyQueue.isEmpty()) {
            if (legacyDeleted.isNotEmpty()) {
                vm.onTrashed(legacyDeleted)
                legacyDeleted = emptyList()
            }
            return@LaunchedEffect
        }
        val head = legacyQueue.first()
        try {
            withContext(Dispatchers.IO) { context.contentResolver.delete(head.uri, null, null) }
            legacyDeleted = legacyDeleted + head.key
            legacyQueue = legacyQueue.drop(1)
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                trashLauncher.launch(
                    IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build()
                )
            } else {
                legacyQueue = legacyQueue.drop(1)
            }
        } catch (_: Exception) {
            legacyQueue = legacyQueue.drop(1) // skip files that can't be deleted
        }
    }

    val requestTrash: (List<MediaItem>) -> Unit = { list ->
        if (list.isNotEmpty()) {
            if (Build.VERSION.SDK_INT >= 30) {
                pendingTrash = list
                try {
                    val request = MediaStore.createTrashRequest(
                        context.contentResolver, list.map { it.uri }, true
                    )
                    trashLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                } catch (_: Exception) {
                    pendingTrash = emptyList()
                }
            } else {
                legacyDeleted = emptyList()
                legacyQueue = list
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = scheme.background,
        contentColor = scheme.onBackground,
    ) {
        if (!granted) {
            PermissionScreen(
                onAllow = { permissionLauncher.launch(mediaPermissions()) },
                onSettings = {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", context.packageName, null)
                        )
                    )
                },
            )
        } else {
            GalleryContent(vm, requestTrash)
        }
    }
}

@Composable
private fun GalleryContent(vm: GalleryViewModel, requestTrash: (List<MediaItem>) -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val items = vm.items
    val favorites = vm.favorites
    val selection = vm.selection
    val favItems = remember(items, favorites) { items.filter { it.key in favorites } }
    val albums = remember(items) { buildAlbums(items) }
    val selectedItems = remember(items, selection) { items.filter { it.key in selection } }
    val selecting = selection.isNotEmpty()
    val albumId = vm.openAlbumId

    BackHandler(enabled = vm.viewer != null) { vm.closeViewer() }
    BackHandler(enabled = vm.viewer == null && selecting) { vm.clearSelection() }
    BackHandler(enabled = vm.viewer == null && !selecting && albumId != null) { vm.closeAlbum() }

    Box(Modifier.fillMaxSize()) {
        val emptyText = if (vm.loaded) "NOTHING HERE" else "LOADING"

        fun openGrid(list: List<MediaItem>, index: Int, item: MediaItem) {
            if (selecting) vm.toggleSelect(item.key) else vm.openViewer(list, index)
        }

        if (albumId != null) {
            val list = remember(items, albumId) { items.filter { it.bucketId == albumId } }
            MediaGrid(
                items = list,
                selection = selection,
                favorites = favorites,
                grouped = false,
                bottomPadding = NavHeight,
                header = {
                    AlbumHeader(
                        name = list.firstOrNull()?.bucket ?: "",
                        count = list.size,
                        onBack = { vm.closeAlbum() },
                    )
                },
                empty = { EmptyState(emptyText, "") },
                onClick = { i, m -> openGrid(list, i, m) },
                onLongClick = { vm.toggleSelect(it.key) },
            )
        } else when (tab) {
            0 -> MediaGrid(
                items = items,
                selection = selection,
                favorites = favorites,
                grouped = true,
                bottomPadding = NavHeight,
                header = { DotHeader("GALLERY", "${items.size} ITEMS") },
                empty = { EmptyState(emptyText, "TAKE A PHOTO TO GET STARTED") },
                onClick = { i, m -> openGrid(items, i, m) },
                onLongClick = { vm.toggleSelect(it.key) },
            )

            1 -> AlbumsGrid(
                albums = albums,
                bottomPadding = NavHeight,
                header = { DotHeader("ALBUMS", "${albums.size} COLLECTIONS", horizontal = 4.dp) },
                empty = { EmptyState(emptyText, "") },
                onOpen = { vm.openAlbum(it.id) },
            )

            else -> MediaGrid(
                items = favItems,
                selection = selection,
                favorites = favorites,
                grouped = false,
                bottomPadding = NavHeight,
                header = { DotHeader("FAVORITES", "${favItems.size} ITEMS") },
                empty = { EmptyState(if (vm.loaded) "NO FAVORITES" else "LOADING", "TAP THE HEART ON ANY PHOTO") },
                onClick = { i, m -> openGrid(favItems, i, m) },
                onLongClick = { vm.toggleSelect(it.key) },
            )
        }

        Box(Modifier.align(Alignment.BottomCenter)) {
            if (selecting) {
                SelectionBar(
                    count = selection.size,
                    allFavorite = selection.all { it in favorites },
                    onClose = { vm.clearSelection() },
                    onShare = { shareItems(context, selectedItems) },
                    onFavorite = { vm.toggleFavorite(selection) },
                    onTrash = { requestTrash(selectedItems) },
                )
            } else {
                NavPill(selected = tab, onSelect = {
                    vm.closeAlbum()
                    tab = it
                })
            }
        }

        vm.viewer?.let { v ->
            ViewerScreen(
                state = v,
                favorites = favorites,
                onClose = { vm.closeViewer() },
                onFavorite = { vm.toggleFavorite(listOf(it.key)) },
                onShare = { shareItems(context, listOf(it)) },
                onTrash = { requestTrash(listOf(it)) },
                onPlay = { playVideo(context, it) },
            )
        }
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit, onSettings: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        DotText("ACCESS", dot = 6.dp)
        Spacer(Modifier.size(28.dp))
        MonoText(
            "ALLOW ACCESS TO YOUR PHOTOS AND VIDEOS TO SHOW YOUR GALLERY.",
            size = 12.sp, color = scheme.onSurfaceVariant, maxLines = 4,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.size(32.dp))
        Row(
            Modifier
                .clip(CircleShape)
                .background(scheme.onBackground)
                .clickable(onClick = onAllow)
                .padding(horizontal = 36.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(NothingRed))
            Spacer(Modifier.width(10.dp))
            MonoText("ALLOW", size = 13.sp, weight = FontWeight.Bold, color = scheme.background)
        }
        Spacer(Modifier.size(12.dp))
        TextButton(onClick = onSettings) {
            MonoText("OPEN SETTINGS", size = 11.sp, color = scheme.onSurfaceVariant)
        }
    }
}
