(function () {
  if (window.__androidShim) return;
  var B = window.AndroidBridge;
  if (!B) return;
  window.__androidShim = true;

  var CHUNK = 768 * 1024; // multiple of 3 so each base64 chunk is clean

  function sendBlob(blob, name, forShare) {
    return new Promise(function (resolve, reject) {
      var id = B.begin(String(name || 'file'), blob.type || 'application/octet-stream', !!forShare);
      var off = 0;
      (function next() {
        if (off >= blob.size) {
          try { B.end(id); } catch (e) { return reject(e); }
          return resolve(id);
        }
        var fr = new FileReader();
        fr.onload = function () {
          var s = String(fr.result);
          try { B.chunk(id, s.substring(s.indexOf(',') + 1)); } catch (e) { return reject(e); }
          off += CHUNK;
          next();
        };
        fr.onerror = function () { reject(fr.error); };
        fr.readAsDataURL(blob.slice(off, off + CHUNK));
      })();
    });
  }

  // <a download href="blob:..."> is silently ignored inside a WebView, so save through the app.
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var a = this;
    if (a.hasAttribute('download') && /^blob:/.test(a.href)) {
      fetch(a.href)
        .then(function (r) { return r.blob(); })
        .then(function (b) { return sendBlob(b, a.getAttribute('download') || 'file', false); })
        .catch(function () {});
      return;
    }
    return origClick.apply(this, arguments);
  };

  // Native share sheet for files and text.
  navigator.canShare = function (d) {
    return !!(d && ((d.files && d.files.length) || d.text || d.url || d.title));
  };
  navigator.share = function (d) {
    d = d || {};
    if (d.files && d.files.length) {
      var ids = [];
      return Array.prototype.reduce.call(d.files, function (p, f) {
        return p.then(function () {
          return sendBlob(f, f.name, true).then(function (id) { ids.push(id); });
        });
      }, Promise.resolve()).then(function () {
        B.shareFiles(ids.join(','));
      });
    }
    B.shareText(String(d.title || ''), String(d.text || ''), String(d.url || ''));
    return Promise.resolve();
  };

  // Android back button: close whatever is open (viewer, sheet, selection...) via the app's own Escape handling.
  function sig() {
    var n = document.getElementsByTagName('*').length, len = 0;
    ['app', 'ov', 'ed', 'bar'].forEach(function (id) {
      var e = document.getElementById(id);
      if (e) len += e.innerHTML.length;
    });
    return n + '/' + len + '/' + document.body.className;
  }
  window.__androidBack = function () {
    var before = sig();
    var t = document.activeElement || document;
    t.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    setTimeout(function () { B.backResult(sig() !== before); }, 450);
  };

  // Colour reported to the native side so status/navigation bars match the current screen.
  window.__androidBarColor = function () {
    try {
      if (document.querySelector('.vw,.ed')) return '#000000';
      return getComputedStyle(document.documentElement).getPropertyValue('--bg').trim();
    } catch (e) { return ''; }
  };
})();
