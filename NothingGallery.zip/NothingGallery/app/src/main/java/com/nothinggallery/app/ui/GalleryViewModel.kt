package com.nothinggallery.app.ui

import android.app.Application
import android.content.Context
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nothinggallery.app.data.MediaItem
import com.nothinggallery.app.data.MediaRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ViewerState(val list: List<MediaItem>, val index: Int)

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val prefs = app.getSharedPreferences("nothing_gallery", Context.MODE_PRIVATE)
    private var hasAccess = false
    private var loadJob: Job? = null

    var items by mutableStateOf<List<MediaItem>>(emptyList())
        private set
    var loaded by mutableStateOf(false)
        private set
    var favorites by mutableStateOf<Set<String>>(
        prefs.getStringSet(KEY_FAVORITES, emptySet())?.toSet() ?: emptySet()
    )
        private set
    var selection by mutableStateOf<Set<String>>(emptySet())
        private set
    var openAlbumId by mutableStateOf<Long?>(null)
        private set
    var viewer by mutableStateOf<ViewerState?>(null)
        private set

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            refresh(400)
        }
    }

    init {
        val resolver = app.contentResolver
        resolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
        resolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
    }

    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(observer)
    }

    fun setAccess(granted: Boolean) {
        hasAccess = granted
        if (granted) refresh()
    }

    fun refresh(delayMs: Long = 0L) {
        if (!hasAccess) return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (delayMs > 0) delay(delayMs)
            val result = runCatching { repo.load() }.getOrNull() ?: return@launch
            items = result
            loaded = true
            reconcile()
        }
    }

    /** Drops selection / viewer / album state that points at items that no longer exist. */
    private fun reconcile() {
        val present = HashSet<String>(items.size)
        items.forEach { present.add(it.key) }

        if (selection.isNotEmpty()) selection = selection.filter { it in present }.toSet()

        viewer?.let { v ->
            val kept = v.list.filter { it.key in present }
            viewer = when {
                kept.isEmpty() -> null
                kept.size == v.list.size -> v
                else -> ViewerState(kept, v.index.coerceIn(0, kept.lastIndex))
            }
        }

        openAlbumId?.let { id -> if (items.none { it.bucketId == id }) openAlbumId = null }
    }

    // ---- Viewer -----------------------------------------------------------------------------

    fun openViewer(list: List<MediaItem>, index: Int) {
        if (list.isEmpty()) return
        viewer = ViewerState(list, index.coerceIn(0, list.lastIndex))
    }

    fun closeViewer() {
        viewer = null
    }

    // ---- Albums -----------------------------------------------------------------------------

    fun openAlbum(id: Long) {
        openAlbumId = id
    }

    fun closeAlbum() {
        openAlbumId = null
    }

    // ---- Selection --------------------------------------------------------------------------

    fun toggleSelect(key: String) {
        selection = if (key in selection) selection - key else selection + key
    }

    fun clearSelection() {
        selection = emptySet()
    }

    // ---- Favorites --------------------------------------------------------------------------

    fun toggleFavorite(keys: Collection<String>) {
        if (keys.isEmpty()) return
        favorites = if (keys.all { it in favorites }) favorites - keys.toSet() else favorites + keys
        prefs.edit().putStringSet(KEY_FAVORITES, HashSet(favorites)).apply()
    }

    // ---- Trash ------------------------------------------------------------------------------

    fun onTrashed(keys: Collection<String>) {
        val gone = keys.toSet()
        items = items.filter { it.key !in gone }
        selection = emptySet()
        reconcile()
    }

    private companion object {
        const val KEY_FAVORITES = "favorites"
    }
}
