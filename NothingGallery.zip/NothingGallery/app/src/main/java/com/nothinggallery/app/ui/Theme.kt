package com.nothinggallery.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

val NothingRed = Color(0xFFD71921)

private val DarkScheme = darkColorScheme(
    primary = NothingRed,
    onPrimary = Color.White,
    background = Color(0xFF000000),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF0C0C0C),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF1A1A1A),
    onSurfaceVariant = Color(0xFF8E8E8E),
    outline = Color(0xFF2E2E2E),
    outlineVariant = Color(0xFF222222),
)

private val LightScheme = lightColorScheme(
    primary = NothingRed,
    onPrimary = Color.White,
    background = Color(0xFFF2F2F2),
    onBackground = Color(0xFF0A0A0A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0A0A0A),
    surfaceVariant = Color(0xFFE4E4E4),
    onSurfaceVariant = Color(0xFF6B6B6B),
    outline = Color(0xFFCFCFCF),
    outlineVariant = Color(0xFFDADADA),
)

@Composable
fun NothingTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content,
    )
}

/** Monospaced, slightly tracked text used for all small labels. */
@Composable
fun MonoText(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = 12.sp,
    color: Color = MaterialTheme.colorScheme.onBackground,
    weight: FontWeight = FontWeight.Normal,
    spacing: TextUnit = 1.sp,
    maxLines: Int = 1,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size,
        fontFamily = FontFamily.Monospace,
        fontWeight = weight,
        letterSpacing = spacing,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}
