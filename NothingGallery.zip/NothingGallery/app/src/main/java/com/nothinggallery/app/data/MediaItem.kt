package com.nothinggallery.app.data

import android.net.Uri

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mime: String,
    val isVideo: Boolean,
    val dateMillis: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val bucketId: Long,
    val bucket: String,
    val path: String,
) {
    /** Unique across images and videos (their MediaStore ids can collide). */
    val key: String get() = (if (isVideo) "v" else "i") + id
}

data class Album(
    val id: Long,
    val name: String,
    val cover: MediaItem,
    val count: Int,
)

fun buildAlbums(items: List<MediaItem>): List<Album> =
    items.groupBy { it.bucketId }
        .map { (id, list) ->
            // `items` is sorted newest-first, so the first element is the cover.
            Album(id = id, name = list.first().bucket.ifBlank { "Unknown" }, cover = list.first(), count = list.size)
        }
        .sortedByDescending { it.cover.dateMillis }
