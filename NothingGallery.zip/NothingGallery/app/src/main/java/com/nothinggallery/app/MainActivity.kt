package com.nothinggallery.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.nothinggallery.app.ui.GalleryApp
import com.nothinggallery.app.ui.GalleryViewModel
import com.nothinggallery.app.ui.NothingTheme

class MainActivity : ComponentActivity() {
    private val viewModel: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NothingTheme {
                GalleryApp(viewModel)
            }
        }
    }
}
