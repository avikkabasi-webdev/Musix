package com.nothinggallery.app.ui

import android.app.Activity
import android.net.Uri
import android.text.format.Formatter
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.nothinggallery.app.data.MediaItem

@Composable
fun ViewerScreen(
    state: ViewerState,
    favorites: Set<String>,
    onClose: () -> Unit,
    onFavorite: (MediaItem) -> Unit,
    onShare: (MediaItem) -> Unit,
    onTrash: (MediaItem) -> Unit,
    onPlay: (MediaItem) -> Unit,
) {
    // The viewer is always black, so force light status-bar icons while it is open.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = (view.context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val previous = controller?.isAppearanceLightStatusBars
        controller?.isAppearanceLightStatusBars = false
        onDispose {
            if (controller != null && previous != null) controller.isAppearanceLightStatusBars = previous
        }
    }

    NothingTheme(dark = true) {
        val pagerState = rememberPagerState(
            initialPage = state.index.coerceIn(0, state.list.lastIndex.coerceAtLeast(0))
        ) { state.list.size }
        var chrome by remember { mutableStateOf(true) }
        var showInfo by remember { mutableStateOf(false) }
        val current = state.list.getOrNull(pagerState.currentPage)

        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                key = { state.list.getOrNull(it)?.key ?: it },
            ) { page ->
                val item = state.list.getOrNull(page)
                if (item != null) {
                    if (item.isVideo) {
                        VideoPage(item, onToggleChrome = { chrome = !chrome }, onPlay = { onPlay(item) })
                    } else {
                        ZoomableImage(item.uri, onTap = { chrome = !chrome })
                    }
                }
            }

            if (current != null) {
                AnimatedVisibility(
                    visible = chrome,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.TopCenter),
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)
                                )
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = onClose) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back", tint = Color.White
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            MonoText(
                                dateTimeLabel(current.dateMillis), size = 12.sp,
                                weight = FontWeight.Bold, color = Color.White
                            )
                            MonoText(
                                "${pagerState.currentPage + 1} / ${state.list.size}",
                                size = 10.sp, color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                }

                AnimatedVisibility(
                    visible = chrome,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter),
                ) {
                    val isFav = current.key in favorites
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                                )
                            )
                            .navigationBarsPadding()
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { onShare(current) }) {
                            Icon(Icons.Filled.Share, contentDescription = "Share", tint = Color.White)
                        }
                        IconButton(onClick = { onFavorite(current) }) {
                            Icon(
                                if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFav) NothingRed else Color.White,
                            )
                        }
                        IconButton(onClick = { showInfo = true }) {
                            Icon(Icons.Filled.Info, contentDescription = "Info", tint = Color.White)
                        }
                        IconButton(onClick = { onTrash(current) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color.White)
                        }
                    }
                }

                if (showInfo) InfoDialog(current, onDismiss = { showInfo = false })
            }
        }
    }
}

@Composable
private fun VideoPage(item: MediaItem, onToggleChrome: () -> Unit, onPlay: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onToggleChrome,
            ),
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(
            model = item.uri,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.55f))
                .border(1.5.dp, Color.White, CircleShape)
                .clickable(onClick = onPlay),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Filled.PlayArrow, contentDescription = "Play",
                tint = Color.White, modifier = Modifier.size(38.dp)
            )
        }
        MonoText(
            formatDuration(item.durationMs), size = 12.sp, color = Color.White,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 110.dp)
        )
    }
}

/**
 * Pinch / pan / double-tap zoom. Single-finger drags are only consumed while zoomed in, so the
 * pager can still swipe between photos at 1x.
 */
@Composable
private fun ZoomableImage(uri: Uri, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val context = LocalContext.current
    val request = remember(uri) {
        ImageRequest.Builder(context).data(uri).size(2048).build()
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        scale = if (scale > 1f) 1f else 2.5f
                        offset = Offset.Zero
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        val multiTouch = event.changes.count { it.pressed } > 1
                        if (multiTouch || scale > 1f) {
                            val newScale = (scale * zoom).coerceIn(1f, 6f)
                            val maxX = size.width * (newScale - 1f) / 2f
                            val maxY = size.height * (newScale - 1f) / 2f
                            offset = Offset(
                                (offset.x + pan.x).coerceIn(-maxX, maxX),
                                (offset.y + pan.y).coerceIn(-maxY, maxY),
                            )
                            scale = newScale
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            },
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(
            model = request,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
private fun InfoDialog(item: MediaItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                MonoText("CLOSE", color = NothingRed, weight = FontWeight.Bold)
            }
        },
        title = { MonoText(item.name, size = 14.sp, weight = FontWeight.Bold, maxLines = 2) },
        text = {
            Column {
                InfoRow("DATE", dateTimeLabel(item.dateMillis), dim)
                if (item.width > 0 && item.height > 0)
                    InfoRow("SIZE", "${item.width} x ${item.height}", dim)
                InfoRow("FILE", Formatter.formatShortFileSize(context, item.size).uppercase(), dim)
                if (item.isVideo) InfoRow("LENGTH", formatDuration(item.durationMs), dim)
                InfoRow("TYPE", item.mime.uppercase(), dim)
                InfoRow("ALBUM", item.bucket.uppercase(), dim)
                if (item.path.isNotBlank()) InfoRow("PATH", item.path, dim)
            }
        },
    )
}

@Composable
private fun InfoRow(label: String, value: String, dim: Color) {
    Column(Modifier.padding(vertical = 5.dp)) {
        MonoText(label, size = 10.sp, color = dim)
        MonoText(value, size = 12.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 3)
    }
}
