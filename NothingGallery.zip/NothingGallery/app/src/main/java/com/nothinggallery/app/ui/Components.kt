package com.nothinggallery.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nothinggallery.app.data.Album
import com.nothinggallery.app.data.MediaItem

// ---------------------------------------------------------------------------------------------
// Headers
// ---------------------------------------------------------------------------------------------

@Composable
fun DotHeader(title: String, subtitle: String, horizontal: Dp = 20.dp) {
    Column(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = horizontal, end = horizontal, top = 24.dp, bottom = 20.dp)
    ) {
        DotText(title, dot = 5.dp)
        Spacer(Modifier.size(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(NothingRed))
            Spacer(Modifier.width(8.dp))
            MonoText(subtitle, size = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun AlbumHeader(name: String, count: Int, onBack: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 8.dp, end = 20.dp, top = 8.dp, bottom = 16.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Column(Modifier.padding(start = 12.dp)) {
            MonoText(
                name.uppercase(), size = 24.sp, weight = FontWeight.Bold,
                spacing = 0.sp, maxLines = 2,
            )
            Spacer(Modifier.size(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(NothingRed))
                Spacer(Modifier.width(8.dp))
                MonoText(
                    "$count ITEMS", size = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Grid
// ---------------------------------------------------------------------------------------------

private sealed class GridRow {
    data class Header(val label: String, val count: Int) : GridRow()
    data class Cell(val item: MediaItem, val index: Int) : GridRow()
}

private fun buildRows(items: List<MediaItem>, grouped: Boolean): List<GridRow> {
    if (!grouped) return items.mapIndexed { i, m -> GridRow.Cell(m, i) }
    val rows = ArrayList<GridRow>(items.size + 32)
    var lastLabel: String? = null
    var headerAt = -1
    var inGroup = 0
    items.forEachIndexed { i, m ->
        val label = dayLabel(m.dateMillis)
        if (label != lastLabel) {
            if (headerAt >= 0) rows[headerAt] = GridRow.Header(lastLabel!!, inGroup)
            headerAt = rows.size
            rows.add(GridRow.Header(label, 0))
            lastLabel = label
            inGroup = 0
        }
        inGroup++
        rows.add(GridRow.Cell(m, i))
    }
    if (headerAt >= 0) rows[headerAt] = GridRow.Header(lastLabel!!, inGroup)
    return rows
}

@Composable
fun MediaGrid(
    items: List<MediaItem>,
    selection: Set<String>,
    favorites: Set<String>,
    grouped: Boolean,
    bottomPadding: Dp,
    header: @Composable () -> Unit,
    empty: @Composable () -> Unit,
    onClick: (index: Int, item: MediaItem) -> Unit,
    onLongClick: (item: MediaItem) -> Unit,
) {
    val rows = remember(items, grouped) { buildRows(items, grouped) }
    val selecting = selection.isNotEmpty()

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 2.dp, end = 2.dp, bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        item(key = "header", span = { GridItemSpan(maxLineSpan) }) { header() }

        if (items.isEmpty()) {
            item(key = "empty", span = { GridItemSpan(maxLineSpan) }) { empty() }
        }

        items(
            items = rows,
            key = { row ->
                when (row) {
                    is GridRow.Header -> "h_" + row.label
                    is GridRow.Cell -> row.item.key
                }
            },
            span = { row ->
                when (row) {
                    is GridRow.Header -> GridItemSpan(maxLineSpan)
                    is GridRow.Cell -> GridItemSpan(1)
                }
            },
        ) { row ->
            when (row) {
                is GridRow.Header -> DayHeader(row.label, row.count)
                is GridRow.Cell -> Thumb(
                    item = row.item,
                    selected = row.item.key in selection,
                    selecting = selecting,
                    favorite = row.item.key in favorites,
                    onClick = { onClick(row.index, row.item) },
                    onLongClick = { onLongClick(row.item) },
                )
            }
        }
    }
}

@Composable
private fun DayHeader(label: String, count: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MonoText(label, size = 12.sp, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
        MonoText(
            count.toString().padStart(2, '0'), size = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Thumb(
    item: MediaItem,
    selected: Boolean,
    selecting: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = item.uri,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .padding(if (selected) 8.dp else 0.dp)
                .clip(RoundedCornerShape(if (selected) 6.dp else 0.dp)),
        )

        if (item.isVideo) {
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(start = 4.dp, end = 7.dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.PlayArrow, contentDescription = null,
                    tint = Color.White, modifier = Modifier.size(12.dp)
                )
                MonoText(
                    formatDuration(item.durationMs), size = 10.sp, color = Color.White,
                    spacing = 0.sp
                )
            }
        }

        if (favorite && !selecting) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(7.dp)
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(NothingRed)
            )
        }

        if (selecting) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (selected) NothingRed else Color.Black.copy(alpha = 0.35f))
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) {
                    Icon(
                        Icons.Filled.Check, contentDescription = null,
                        tint = Color.White, modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Albums
// ---------------------------------------------------------------------------------------------

@Composable
fun AlbumsGrid(
    albums: List<Album>,
    bottomPadding: Dp,
    header: @Composable () -> Unit,
    empty: @Composable () -> Unit,
    onOpen: (Album) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item(key = "header", span = { GridItemSpan(maxLineSpan) }) { header() }
        if (albums.isEmpty()) {
            item(key = "empty", span = { GridItemSpan(maxLineSpan) }) { empty() }
        }
        items(items = albums, key = { it.id }) { album ->
            Column(Modifier.clickable { onOpen(album) }) {
                AsyncImage(
                    model = album.cover.uri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                )
                Spacer(Modifier.size(10.dp))
                MonoText(
                    album.name.uppercase(), size = 12.sp, weight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                MonoText(
                    album.count.toString().padStart(2, '0'), size = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Empty state / bars
// ---------------------------------------------------------------------------------------------

@Composable
fun EmptyState(text: String, hint: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        DotText(text, dot = 3.dp)
        Spacer(Modifier.size(18.dp))
        MonoText(hint, size = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun NavPill(selected: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("PHOTOS", "ALBUMS", "FAVS")
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .navigationBarsPadding()
            .padding(bottom = 14.dp)
            .clip(CircleShape)
            .background(scheme.surface.copy(alpha = 0.94f))
            .border(1.dp, scheme.outline, CircleShape)
            .padding(5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        labels.forEachIndexed { i, label ->
            val sel = i == selected
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(if (sel) scheme.onBackground else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 18.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (sel) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(NothingRed))
                    Spacer(Modifier.width(8.dp))
                }
                MonoText(
                    label, size = 12.sp, weight = FontWeight.Bold,
                    color = if (sel) scheme.background else scheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun SelectionBar(
    count: Int,
    allFavorite: Boolean,
    onClose: () -> Unit,
    onShare: () -> Unit,
    onFavorite: () -> Unit,
    onTrash: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .navigationBarsPadding()
            .padding(bottom = 14.dp)
            .clip(CircleShape)
            .background(scheme.surface.copy(alpha = 0.96f))
            .border(1.dp, scheme.outline, CircleShape)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Cancel") }
        MonoText(
            "$count SELECTED", size = 12.sp, weight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp)
        )
        IconButton(onClick = onShare) { Icon(Icons.Filled.Share, contentDescription = "Share") }
        IconButton(onClick = onFavorite) {
            Icon(
                if (allFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Favorite",
                tint = if (allFavorite) NothingRed else scheme.onSurface,
            )
        }
        IconButton(onClick = onTrash) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
    }
}
