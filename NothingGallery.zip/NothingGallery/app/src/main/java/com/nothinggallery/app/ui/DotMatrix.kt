package com.nothinggallery.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * 5x7 dot-matrix glyphs. Each line: `<char> <7 rows of 5 columns>` where '#' is a lit dot.
 */
private val GLYPHS: Map<Char, List<String>> = """
A .###. #...# #...# ##### #...# #...# #...#
B ####. #...# #...# ####. #...# #...# ####.
C .###. #...# #.... #.... #.... #...# .###.
D ####. #...# #...# #...# #...# #...# ####.
E ##### #.... #.... ####. #.... #.... #####
F ##### #.... #.... ####. #.... #.... #....
G .###. #...# #.... #.### #...# #...# .###.
H #...# #...# #...# ##### #...# #...# #...#
I .###. ..#.. ..#.. ..#.. ..#.. ..#.. .###.
J ..### ...#. ...#. ...#. ...#. #..#. .##..
K #...# #..#. #.#.. ##... #.#.. #..#. #...#
L #.... #.... #.... #.... #.... #.... #####
M #...# ##.## #.#.# #.#.# #...# #...# #...#
N #...# ##..# #.#.# #..## #...# #...# #...#
O .###. #...# #...# #...# #...# #...# .###.
P ####. #...# #...# ####. #.... #.... #....
Q .###. #...# #...# #...# #.#.# #..#. .##.#
R ####. #...# #...# ####. #.#.. #..#. #...#
S .#### #.... #.... .###. ....# ....# ####.
T ##### ..#.. ..#.. ..#.. ..#.. ..#.. ..#..
U #...# #...# #...# #...# #...# #...# .###.
V #...# #...# #...# #...# #...# .#.#. ..#..
W #...# #...# #...# #.#.# #.#.# ##.## #...#
X #...# #...# .#.#. ..#.. .#.#. #...# #...#
Y #...# #...# .#.#. ..#.. ..#.. ..#.. ..#..
Z ##### ....# ...#. ..#.. .#... #.... #####
0 .###. #...# #..## #.#.# ##..# #...# .###.
1 ..#.. .##.. ..#.. ..#.. ..#.. ..#.. .###.
2 .###. #...# ....# ...#. ..#.. .#... #####
3 ####. ....# ....# .###. ....# ....# ####.
4 ...#. ..##. .#.#. #..#. ##### ...#. ...#.
5 ##### #.... ####. ....# ....# #...# .###.
6 .###. #.... #.... ####. #...# #...# .###.
7 ##### ....# ...#. ..#.. .#... .#... .#...
8 .###. #...# #...# .###. #...# #...# .###.
9 .###. #...# #...# .#### ....# ....# .###.
. ..... ..... ..... ..... ..... .##.. .##..
, ..... ..... ..... ..... .##.. .##.. .#...
- ..... ..... ..... ##### ..... ..... .....
: ..... .##.. .##.. ..... .##.. .##.. .....
! ..#.. ..#.. ..#.. ..#.. ..#.. ..... ..#..
/ ....# ....# ...#. ..#.. .#... #.... #....
""".trimIndent().lines().filter { it.isNotBlank() }.associate { line ->
    val parts = line.trim().split(" ")
    parts[0][0] to parts.drop(1)
}

private val BLANK = List(7) { "....." }

/**
 * Text drawn as a Nothing-style dot matrix. [dot] is the pitch between dots.
 * Unknown characters render as blank cells.
 */
@Composable
fun DotText(
    text: String,
    modifier: Modifier = Modifier,
    dot: Dp = 4.dp,
    color: Color = MaterialTheme.colorScheme.onBackground,
    ghost: Boolean = true,
) {
    val chars = text.uppercase()
    val density = LocalDensity.current
    val pitch = with(density) { dot.toPx() }
    val widthDp = if (chars.isEmpty()) 0.dp else dot * (chars.length * 6 - 1)
    val heightDp = dot * 7
    val ghostColor = color.copy(alpha = 0.10f)

    Canvas(modifier.size(widthDp, heightDp)) {
        val radius = pitch * 0.38f
        chars.forEachIndexed { ci, ch ->
            val rows = GLYPHS[ch] ?: BLANK
            for (r in 0 until 7) {
                val row = rows[r]
                for (c in 0 until 5) {
                    val on = row[c] == '#'
                    if (on || ghost) {
                        drawCircle(
                            color = if (on) color else ghostColor,
                            radius = radius,
                            center = Offset((ci * 6 + c + 0.5f) * pitch, (r + 0.5f) * pitch),
                        )
                    }
                }
            }
        }
    }
}
