package com.android6.gallery;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILES = 1001;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private String shimSource = "";

    private ValueCallback<Uri[]> filePathCallback;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private boolean backPending = false;
    private int lastBarColor = 0;

    private static class Transfer {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        String name;
        String mime;
    }

    private final Map<Integer, Transfer> transfers = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        shimSource = readAsset("android-shim.js");

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/assets/")) {
                    String path = u.getPath().substring("/assets/".length());
                    try {
                        InputStream in = getAssets().open(path);
                        String ext = MimeTypeMap.getFileExtensionFromUrl(path);
                        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                        if (path.endsWith(".js") || path.endsWith(".mjs")) mime = "text/javascript";
                        if (mime == null) mime = "text/html";
                        return new WebResourceResponse(mime, "utf-8", in);
                    } catch (IOException e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                null, new java.io.ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (HOST.equals(u.getHost()) || scheme.equals("blob") || scheme.equals("data")
                        || scheme.equals("about")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(shimSource, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILES);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                root.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
                lastBarColor = 0;
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            }
        });

        web.loadUrl(START_URL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILES) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            web.getWebChromeClient().onHideCustomView();
            return;
        }
        if (backPending) return;
        backPending = true;
        web.evaluateJavascript("window.__androidBack&&window.__androidBack()", null);
        handler.postDelayed(() -> {
            if (backPending) {
                backPending = false;
                moveTaskToBack(true);
            }
        }, 900);
    }

    private final Runnable barPoll = new Runnable() {
        @Override
        public void run() {
            if (web != null && customView == null) {
                web.evaluateJavascript(
                        "window.__androidBarColor?window.__androidBarColor():''", value -> {
                            if (value == null) return;
                            String c = value.replace("\"", "").trim();
                            if (c.isEmpty() || c.equals("null")) return;
                            try {
                                applyBarColor(Color.parseColor(c));
                            } catch (IllegalArgumentException ignored) {
                            }
                        });
            }
            handler.postDelayed(this, 600);
        }
    };

    @SuppressWarnings("deprecation")
    private void applyBarColor(int color) {
        if (color == lastBarColor) return;
        lastBarColor = color;
        getWindow().setStatusBarColor(color);
        getWindow().setNavigationBarColor(color);
        root.setBackgroundColor(color);
        boolean light = (0.299 * Color.red(color) + 0.587 * Color.green(color)
                + 0.114 * Color.blue(color)) / 255.0 > 0.5;
        int flags = View.SYSTEM_UI_FLAG_VISIBLE;
        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        handler.removeCallbacks(barPoll);
        handler.post(barPoll);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(barPoll);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    private class Bridge {
        @JavascriptInterface
        public int begin(String name, String mime, boolean forShare) {
            int id = nextId.getAndIncrement();
            Transfer t = new Transfer();
            String n = name == null ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
            t.name = n.isEmpty() ? "file" : n;
            t.mime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            transfers.put(id, t);
            return id;
        }

        @JavascriptInterface
        public void chunk(int id, String base64) {
            Transfer t = transfers.get(id);
            if (t == null) return;
            try {
                byte[] b = Base64.decode(base64, Base64.DEFAULT);
                t.data.write(b, 0, b.length);
            } catch (IllegalArgumentException e) {
                transfers.remove(id);
                toast("Couldn’t save the file");
            }
        }

        @JavascriptInterface
        public void end(int id) {
            Transfer t = transfers.remove(id);
            if (t == null) return;
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, t.name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, t.mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Gallery");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IOException("insert failed");
                try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new IOException("no stream");
                    t.data.writeTo(os);
                }
            } catch (IOException e) {
                toast("Couldn’t save the file");
            }
        }

        @JavascriptInterface
        public void backResult(boolean handled) {
            runOnUiThread(() -> {
                if (!backPending) return;
                backPending = false;
                if (!handled) moveTaskToBack(true);
            });
        }
    }
}
