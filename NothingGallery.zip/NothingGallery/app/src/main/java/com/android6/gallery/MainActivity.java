package com.android6.gallery;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILES = 1001;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private WebViewAssetLoader assetLoader;
    private String shimSource = "";

    private ValueCallback<Uri[]> filePathCallback;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private boolean backPending = false;
    private int lastBarColor = Color.BLACK;

    private static class Transfer {
        File file;
        OutputStream out;
        String name;
        String mime;
        boolean forShare;
    }

    private final Map<Integer, Transfer> transfers = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.setNavigationBarContrastEnforced(false);

        clearShareCache();
        shimSource = readAsset("android-shim.js");

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int l = ins.getSystemWindowInsetLeft();
            int t = ins.getSystemWindowInsetTop();
            int r = ins.getSystemWindowInsetRight();
            int b = ins.getSystemWindowInsetBottom();
            DisplayCutout dc = ins.getDisplayCutout();
            if (dc != null) {
                l = Math.max(l, dc.getSafeInsetLeft());
                t = Math.max(t, dc.getSafeInsetTop());
                r = Math.max(r, dc.getSafeInsetRight());
                b = Math.max(b, dc.getSafeInsetBottom());
            }
            v.setPadding(l, t, r, b);
            return ins;
        });
        setContentView(root);

        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (HOST.equals(u.getHost()) || scheme.equals("blob") || scheme.equals("data")
                        || scheme.equals("about")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(shimSource, null);
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                handler.post(MainActivity.this::recreate);
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILES);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                ((FrameLayout) getWindow().getDecorView()).addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                WindowInsetsControllerCompat c =
                        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                ((FrameLayout) getWindow().getDecorView()).removeView(customView);
                customView = null;
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                customViewCallback = null;
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                        .show(WindowInsetsCompat.Type.systemBars());
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    // ---------- file picker ----------

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILES) {
            if (filePathCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ---------- back button ----------

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            web.getWebChromeClient().onHideCustomView();
            return;
        }
        if (backPending) return;
        backPending = true;
        web.evaluateJavascript("window.__androidBack&&window.__androidBack()", null);
        // Safety net in case the page never answers.
        handler.postDelayed(() -> {
            if (backPending) {
                backPending = false;
                moveTaskToBack(true);
            }
        }, 900);
    }

    // ---------- status / navigation bar colours ----------

    private final Runnable barPoll = new Runnable() {
        @Override
        public void run() {
            if (web != null) {
                web.evaluateJavascript(
                        "window.__androidBarColor?window.__androidBarColor():''", value -> {
                            if (value == null) return;
                            String c = value.replace("\"", "").trim();
                            if (c.isEmpty() || c.equals("null")) return;
                            try {
                                applyBarColor(Color.parseColor(c));
                            } catch (IllegalArgumentException ignored) {
                            }
                        });
            }
            handler.postDelayed(this, 600);
        }
    };

    private void applyBarColor(int color) {
        if (color == lastBarColor) return;
        lastBarColor = color;
        root.setBackgroundColor(color);
        double lum = (0.299 * Color.red(color) + 0.587 * Color.green(color)
                + 0.114 * Color.blue(color)) / 255.0;
        WindowInsetsControllerCompat c =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(lum > 0.5);
        c.setAppearanceLightNavigationBars(lum > 0.5);
    }

    // ---------- lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        handler.removeCallbacks(barPoll);
        handler.post(barPoll);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(barPoll);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    // ---------- helpers ----------

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private File shareDir() {
        File d = new File(getCacheDir(), "share");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private void clearShareCache() {
        File[] files = shareDir().listFiles();
        if (files != null) for (File f : files) f.delete();
    }

    private static String safeName(String name) {
        String n = name == null ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return n.isEmpty() ? "file" : n;
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    private void saveToDownloads(File src, String name, String mime) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Gallery");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("insert failed");
        try (OutputStream os = getContentResolver().openOutputStream(uri);
             InputStream is = new java.io.FileInputStream(src)) {
            if (os == null) throw new IOException("no stream");
            byte[] buf = new byte[65536];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContentResolver().update(uri, done, null, null);
    }

    // ---------- JS bridge ----------

    private class Bridge {
        @JavascriptInterface
        public int begin(String name, String mime, boolean forShare) {
            int id = nextId.getAndIncrement();
            Transfer t = new Transfer();
            t.name = safeName(name);
            t.mime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            t.forShare = forShare;
            try {
                t.file = new File(shareDir(), id + "-" + t.name);
                t.out = new FileOutputStream(t.file);
                transfers.put(id, t);
                return id;
            } catch (IOException e) {
                return -1;
            }
        }

        @JavascriptInterface
        public void chunk(int id, String base64) {
            Transfer t = transfers.get(id);
            if (t == null) return;
            try {
                t.out.write(Base64.decode(base64, Base64.DEFAULT));
            } catch (IOException | IllegalArgumentException e) {
                transfers.remove(id);
                toast("Couldn’t save the file");
            }
        }

        @JavascriptInterface
        public void end(int id) {
            Transfer t = transfers.get(id);
            if (t == null) return;
            try {
                t.out.close();
            } catch (IOException ignored) {
            }
            if (t.forShare) return; // kept until shareFiles()
            transfers.remove(id);
            try {
                saveToDownloads(t.file, t.name, t.mime);
            } catch (IOException e) {
                toast("Couldn’t save the file");
            } finally {
                t.file.delete();
            }
        }

        @JavascriptInterface
        public void shareFiles(String idsCsv) {
            final ArrayList<Uri> uris = new ArrayList<>();
            String type = null;
            for (String part : idsCsv.split(",")) {
                if (part.isEmpty()) continue;
                Transfer t;
                try {
                    t = transfers.remove(Integer.parseInt(part.trim()));
                } catch (NumberFormatException e) {
                    continue;
                }
                if (t == null) continue;
                uris.add(FileProvider.getUriForFile(MainActivity.this,
                        getPackageName() + ".fileprovider", t.file));
                String top = t.mime.contains("/") ? t.mime.substring(0, t.mime.indexOf('/')) : "*";
                if (type == null) type = top + "/*";
                else if (!type.equals(top + "/*")) type = "*/*";
            }
            if (uris.isEmpty()) return;
            final String mime = type == null ? "*/*" : type;
            runOnUiThread(() -> {
                Intent i;
                if (uris.size() == 1) {
                    i = new Intent(Intent.ACTION_SEND);
                    i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                } else {
                    i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                }
                i.setType(mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivity(Intent.createChooser(i, null));
                } catch (ActivityNotFoundException ignored) {
                }
            });
        }

        @JavascriptInterface
        public void shareText(String title, String text, String url) {
            final StringBuilder sb = new StringBuilder();
            if (text != null && !text.isEmpty()) sb.append(text);
            if (url != null && !url.isEmpty()) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(url);
            }
            final String body = sb.toString();
            final String subject = title == null ? "" : title;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, body);
                if (!subject.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, subject);
                try {
                    startActivity(Intent.createChooser(i, null));
                } catch (ActivityNotFoundException ignored) {
                }
            });
        }

        @JavascriptInterface
        public void backResult(boolean handled) {
            runOnUiThread(() -> {
                if (!backPending) return;
                backPending = false;
                if (!handled) moveTaskToBack(true);
            });
        }
    }
}
