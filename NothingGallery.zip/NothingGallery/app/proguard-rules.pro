# Nothing Gallery - R8 rules (only used by release builds)
-keep class coil.** { *; }
-dontwarn coil.**
