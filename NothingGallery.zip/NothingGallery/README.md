# Nothing Gallery

A native Android gallery in a Nothing-OS-inspired look: black / white, red accent, dot-matrix type, monospaced labels.

- Photos grouped by day, Albums (device folders), Favorites
- Full-screen viewer: swipe between items, pinch / double-tap zoom, share, favorite, info, move to trash
- Multi-select (long-press): share, favorite, trash
- Videos: thumbnail + duration, opens in your video player
- Follows the system light / dark theme
- Pure Kotlin + Jetpack Compose, minSdk 30 (Android 11+), no network access, no extra services

## Build the APK with GitHub Actions

Repo root must contain exactly:

```
.github/workflows/build-apk.yml   <- your workflow
NothingGallery.zip                <- this project (the only .zip in the repo root)
```

Push to `main` (or run the workflow manually). The APK appears under the run's **Artifacts** as `LastWave-debug-apk`.

## Build locally

```
./gradlew assembleDebug
# -> app/build/outputs/apk/debug/app-debug.apk
```

Requires JDK 17 and the Android SDK (platform 35).
