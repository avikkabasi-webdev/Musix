# dots.go (Android)

Search once, compare prices across Indian shopping stores. The app reads the stores
itself on your phone: no server, no Firebase, no paid service.

## Build

- Locally: `./gradlew assembleDebug` (APK in `app/build/outputs/apk/debug/`).
- GitHub: push to `main`, open the Actions tab, run "Build APK", and download
  `DotsGo-release` (smaller) or `DotsGo-debug` from the run's Artifacts.
- Push a tag like `v1.0.1` to attach the APKs to a GitHub Release.

If the release APK ever misbehaves, install the debug one; it is the same app without shrinking.
