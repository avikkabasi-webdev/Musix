package com.lastwave.app.data.newreleases

import com.lastwave.app.data.feed.FeedRepository
import com.lastwave.app.data.generate.GenreVerdict
import com.lastwave.app.data.generate.ListeningProfile
import com.lastwave.app.data.generate.ListeningProfileRepository
import com.lastwave.app.data.model.AlbumPageData
import com.lastwave.app.util.ArtistHelper
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import com.lastwave.app.data.music.InnerTubeMusicApi
import com.lastwave.app.data.music.YouTubeMusicTrack
import com.lastwave.app.data.music.YouTubePlaylistSummary
import com.lastwave.app.playback.PlayableTrack
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.ArrayDeque
import javax.inject.Inject
import javax.inject.Singleton

internal fun getLocalizedSearchQueries(hl: String, year: Int): List<String> = when (hl.lowercase().substringBefore('-')) {
    "tr" -> listOf("yeni çıkanlar $year", "yeni şarkılar $year", "türkçe yeni müzik $year", "yeni albümler $year")
    "es" -> listOf("música nueva $year", "canciones nuevas $year", "nuevos lanzamientos $year", "éxitos $year")
    "fr" -> listOf("nouvelle musique $year", "nouveautés $year", "nouvelles chansons $year", "hits français $year")
    "de" -> listOf("neue musik $year", "neue lieder $year", "aktuelle hits $year", "neuerscheinungen $year")
    "ru" -> listOf("новинки музыки $year", "новые песни $year", "свежая музыка $year", "русские хиты $year")
    "pt" -> listOf("músicas novas $year", "lançamentos $year", "novas músicas $year", "hits brasil $year")
    "id" -> listOf("lagu baru $year", "musik terbaru $year", "rilisan terbaru $year")
    "hi" -> listOf("नए गाने $year", "new hindi songs $year", "latest bollywood $year")
    "ja" -> listOf("新曲 $year", "最新音楽 $year", "最新リリース $year", "J-POP 新曲 $year")
    "ko" -> listOf("신곡 $year", "최신 음악 $year", "최신 가요 $year", "K-POP 신곡 $year")
    "zh" -> listOf("最新歌曲 $year", "新歌推荐 $year", "华语新歌 $year")
    "ar" -> listOf("أغاني جديدة $year", "جديد الموسيقى $year", "أحدث الأغاني $year")
    else -> listOf("new music $year", "new songs $year", "new music friday", "latest releases $year")
}

private data class PersonalQuery(val text: String, val requireLikedArtist: Boolean)

/**
 * New Releases screen source. With listening history it only surfaces
 * releases from artists the user plays and in genres the user listens to
 * (never from artists/genres they keep skipping); without any history it
 * falls back to the regional new-releases lists.
 */
@Singleton
class NewReleasesRepository @Inject constructor(
    private val innerTube: InnerTubeMusicApi,
    private val feedRepository: FeedRepository,
    private val listeningProfileRepository: ListeningProfileRepository,
) {
    private val mutex = Mutex()
    private val albumQueue = ArrayDeque<YouTubePlaylistSummary>()
    private val seenAlbumIds = mutableSetOf<String>()
    private val trustedAlbumIds = mutableSetOf<String>()
    private val seenVideoIds = mutableSetOf<String>()
    private val seenTokens = mutableSetOf<String>()
    private var exploreToken: String? = null
    private var albumsToken: String? = null
    private var searchIndex = 0
    private var gridLoaded = false
    private var profile: ListeningProfile = ListeningProfile()
    private var personalQueries: List<PersonalQuery> = emptyList()

    private fun getLocalizedSearchQueries(): List<String> {
        val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val (hl, _) = innerTube.getEffectiveHlGl()
        return getLocalizedSearchQueries(hl, year)
    }

    private fun queryCount(): Int =
        if (profile.hasHistory) personalQueries.size else getLocalizedSearchQueries().size

    val hasMore: Boolean
        get() = !gridLoaded || albumQueue.isNotEmpty() || exploreToken != null || albumsToken != null || searchIndex < queryCount()

    private fun clear() {
        albumQueue.clear()
        seenAlbumIds.clear()
        trustedAlbumIds.clear()
        seenVideoIds.clear()
        seenTokens.clear()
        exploreToken = null
        albumsToken = null
        searchIndex = 0
        gridLoaded = false
        personalQueries = emptyList()
    }

    private fun buildPersonalQueries(): List<PersonalQuery> {
        val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val artists = profile.playedTracks
            .flatMap { ArtistHelper.splitArtists(it.artist) }
            .filter { it.isNotBlank() && profile.likesArtist(it) }
            .distinctBy { it.lowercase() }
            .take(5)
        val genres = profile.likedGenres.take(3)
        return artists.map { PersonalQuery("$it new songs $year", requireLikedArtist = true) } +
            genres.map { PersonalQuery("new $it songs $year", requireLikedArtist = false) }
    }

    suspend fun reset() = mutex.withLock { clear() }

    suspend fun fetchInitialBatch(): List<YouTubeMusicTrack> = mutex.withLock {
        clear()
        profile = runCatching { listeningProfileRepository.snapshot() }.getOrDefault(ListeningProfile())
        if (profile.hasHistory) personalQueries = buildPersonalQueries()

        // 1. Maintain consistency with the Home screen: start with the releases
        // from the Home "New Releases" shelf (already matched to the user's taste).
        val homeReleases = feedRepository.getCachedFeed()?.newReleases.orEmpty()
        if (homeReleases.isNotEmpty()) {
            enqueue(homeReleases, trusted = true)
        } else if (!profile.hasHistory) {
            // Brand-new user with nothing cached yet: regional new releases.
            val freshReleases = runCatching { innerTube.fetchNewReleases() }.getOrDefault(emptyList())
            if (freshReleases.isNotEmpty()) {
                enqueue(freshReleases)
            }
        }

        // 2. Pre-populate additional regional releases from InnerTube's albums
        // grid for pagination. With history these are only kept when their
        // artist/genre matches the user's taste (checked per album below).
        if (albumQueue.size < 15) {
            val grid = runCatching { innerTube.fetchNewReleasesAlbumsGrid() }.getOrNull()
            if (grid != null) {
                gridLoaded = true
                albumsToken = grid.second
                enqueue(grid.first)
            }
        }

        nextBatch()
    }

    suspend fun fetchNextBatch(): List<YouTubeMusicTrack> = mutex.withLock {
        nextBatch()
    }

    /** Whether an album belongs in this user's New Releases. */
    private fun accepts(album: YouTubePlaylistSummary, page: AlbumPageData): Boolean {
        val artist = page.artist.ifBlank { album.author.orEmpty() }
        if (profile.isAvoided(page.title, artist)) return false
        if (!profile.hasHistory) return true
        if (album.id in trustedAlbumIds) return true
        if (profile.likesArtist(artist)) return true
        return profile.genreVerdict(page.genres) == GenreVerdict.LIKED
    }

    private suspend fun nextBatch(): List<YouTubeMusicTrack> {
        val collected = mutableListOf<YouTubeMusicTrack>()
        val minBatchSize = 10

        while (hasMore) {
            if (albumQueue.isNotEmpty()) {
                // Load a few album pages at a time; taste filtering can reject many.
                val chunk = buildList {
                    repeat(6) { albumQueue.pollFirst()?.let { album -> add(album) } }
                }
                val pages = coroutineScope {
                    chunk.map { album ->
                        async {
                            try {
                                innerTube.fetchAlbumPage(album.id, album.title, album.author.orEmpty())
                            } catch (_: Exception) {
                                null
                            }
                        }
                    }.awaitAll()
                }
                chunk.zip(pages).forEach { (album, page) ->
                    if (page != null && accepts(album, page)) {
                        val tracks = page.tracks.mapNotNull { it.toYouTubeMusicTrack() }
                            .filterNot { profile.isAvoided(it.title, it.artist) }
                        collected.addAll(unique(tracks))
                    }
                }
                if (collected.size >= minBatchSize) {
                    return collected
                }
                continue
            }

            if (collected.isNotEmpty()) {
                return collected
            }

            if (!gridLoaded) {
                val grid = innerTube.fetchNewReleasesAlbumsGrid()
                gridLoaded = true
                albumsToken = grid.second
                enqueue(grid.first)
                continue
            }

            albumsToken?.let { token ->
                val batch = innerTube.fetchNewReleasesAlbumsGrid(token)
                seenTokens.add(token)
                albumsToken = batch.second?.takeUnless { it in seenTokens }
                enqueue(batch.first)
            } ?: exploreToken?.let { token ->
                val batch = innerTube.fetchNewReleasesPage(token)
                seenTokens.add(token)
                exploreToken = batch.continuationToken?.takeUnless { it in seenTokens }
                enqueue(batch.albums)
                val fresh = unique(batch.directTracks.filterNot { profile.isAvoided(it.title, it.artist) })
                    .let { tracks -> if (profile.hasHistory) tracks.filter { profile.likesArtist(it.artist) } else tracks }
                if (fresh.isNotEmpty()) return fresh
            } ?: run {
                if (profile.hasHistory) {
                    // Taste-driven searches: artists you play + genres you listen to.
                    val query = personalQueries.getOrNull(searchIndex) ?: return emptyList()
                    val tracks = innerTube.searchSongs(query.text, limit = 30, prefetchStreams = false)
                    searchIndex++
                    val fresh = unique(
                        tracks.filter { track ->
                            !profile.isAvoided(track.title, track.artist) &&
                                (!query.requireLikedArtist || profile.likesArtist(track.artist))
                        },
                    )
                    if (fresh.isNotEmpty()) return fresh
                } else {
                    val queries = getLocalizedSearchQueries()
                    val query = queries.getOrNull(searchIndex) ?: return emptyList()
                    val tracks = innerTube.searchSongs(query, limit = 30, prefetchStreams = false)
                    searchIndex++
                    val fresh = unique(tracks)
                    if (fresh.isNotEmpty()) return fresh
                }
            }
        }
        return collected
    }

    private fun enqueue(albums: List<YouTubePlaylistSummary>, trusted: Boolean = false) {
        albums.filter {
            it.id.isNotBlank() && seenAlbumIds.add(it.id)
        }.forEach {
            if (trusted) trustedAlbumIds.add(it.id)
            albumQueue.addLast(it)
        }
    }

    private fun unique(tracks: List<YouTubeMusicTrack>) =
        tracks.filter { it.videoId.isNotBlank() && seenVideoIds.add(it.videoId) }

    private fun PlayableTrack.toYouTubeMusicTrack(): YouTubeMusicTrack? {
        val id = videoId?.takeIf(String::isNotBlank) ?: return null
        return YouTubeMusicTrack(videoId = id, title = title, artist = artist,
            album = album, artworkUrl = artworkUrl, durationSeconds = null)
    }
}
