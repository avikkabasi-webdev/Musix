package com.lastwave.app.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lastwave.app.R
import com.lastwave.app.ui.common.adaptiveContentWidth
import com.lastwave.app.ui.theme.ExpressivePillShape

/**
 * First-launch welcome screen.
 *
 * Just the Misu logo, centered on the screen, and one pill button at the bottom:
 * "Continue with Misu" (with the logo beside the text). The button enters the app
 * in account-free mode; YouTube Music, Last.fm and backup restore stay available
 * from Settings.
 *
 * The extra parameters are kept so the navigation graph does not change.
 */
@Composable
fun LoginScreen(
    onLoginWithYouTube: () -> Unit,
    onContinueAsGuest: () -> Unit,
    onRestoreBackupAndSignIn: ((String) -> Unit)? = null,
    onDismissError: (() -> Unit)? = null,
    errorMessage: String? = null,
    isBusy: Boolean = false,
    onOpenDownloads: (() -> Unit)? = null,
) {
    Scaffold { _ ->
        Box(modifier = Modifier.fillMaxSize()) {
            // Logo: exact center of the screen (no inset padding on this layer).
            Image(
                painter = painterResource(R.drawable.misu_welcome_logo),
                contentDescription = "Misu logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.66f)
                    .widthIn(max = 320.dp)
                    .aspectRatio(184f / 94f),
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .adaptiveContentWidth(maxWidth = 480.dp)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (errorMessage != null) {
                    Text(
                        errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                    )
                    if (onDismissError != null) {
                        TextButton(onClick = onDismissError) { Text(stringResource(R.string.gen_dismiss)) }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                Button(
                    onClick = onContinueAsGuest,
                    enabled = !isBusy,
                    shape = ExpressivePillShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD4D4D4),
                        contentColor = Color(0xFF1C1C1C),
                    ),
                    modifier = Modifier.fillMaxWidth().height(60.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.misu_welcome_logo),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            colorFilter = ColorFilter.tint(Color(0xFF1C1C1C)),
                            modifier = Modifier.width(32.dp).aspectRatio(184f / 94f),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            stringResource(R.string.login_continue_misu),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }
        }
    }
}
