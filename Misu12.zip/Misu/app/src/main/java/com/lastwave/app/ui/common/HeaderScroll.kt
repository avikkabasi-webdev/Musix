package com.lastwave.app.ui.common

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.unit.Velocity

/**
 * YouTube-style "hide on scroll down, show on scroll up" for every
 * [ExpressiveHeader] in the app.
 *
 * One instance is created in LastWaveNavHost and the [connection] is attached
 * above the whole NavHost, so any vertical list / scroll container under it
 * drives the header — screens do not need to wire anything themselves.
 */
@Stable
class HeaderScrollState {
    /** 0 = fully shown, -[limit] = fully hidden. */
    var offset by mutableFloatStateOf(0f)

    /** How far (px) the header may slide away. Reported by the header itself. */
    var limit: Float = 0f

    fun reset() {
        offset = 0f
    }

    /**
     * True when the header floats OVER the list (the list is not laid out below it).
     * Set by the header itself. Overlay headers follow the content exactly like
     * YouTube: the list scrolls normally and the header moves by the same amount,
     * hiding on scroll down and returning on any scroll up.
     */
    var overlay: Boolean = false

    val connection: NestedScrollConnection = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            // Overlay headers never take scroll away from the list.
            if (overlay) return Offset.Zero
            val dy = available.y
            if (dy == 0f || limit <= 0f) return Offset.Zero
            val old = offset
            val new = (old + dy).coerceIn(-limit, 0f)
            offset = new
            // In-flow header: consume what the header used so the list below (which
            // grows / shrinks with the header) doesn't also move by the same amount.
            return Offset(0f, new - old)
        }

        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
            if (!overlay) return Offset.Zero
            // Move the header by exactly what the list really scrolled: 1:1 with the
            // content, and never when the list could not scroll (top, overscroll, short lists).
            val dy = consumed.y
            if (dy == 0f || limit <= 0f) return Offset.Zero
            offset = (offset + dy).coerceIn(-limit, 0f)
            return Offset.Zero
        }

        override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
            settle()
            return Velocity.Zero
        }
    }

    /** Snap to fully shown / fully hidden after the finger lifts. */
    suspend fun settle() {
        if (limit <= 0f) return
        val start = offset
        if (start == 0f || start == -limit) return
        val target = if (start > -limit / 2f) 0f else -limit
        animate(start, target, animationSpec = tween(durationMillis = 180)) { value, _ -> offset = value }
    }
}

val LocalHeaderScroll = staticCompositionLocalOf<HeaderScrollState?> { null }

@Composable
fun rememberHeaderScrollState(): HeaderScrollState = remember { HeaderScrollState() }
