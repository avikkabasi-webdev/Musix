package com.lastwave.app.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.View
import android.widget.RemoteViews
import com.lastwave.app.R
import java.io.File

/**
 * "Misu Full Art" widget: full-bleed artwork, Like and Download chips in the top
 * corners, then title, artist, progress and Previous / Play-Pause / Next.
 * Like and Download reuse the playback service's notification actions.
 *
 * Never throws: every decode and lookup is guarded and falls back to placeholders.
 */
internal object FullArtWidgetViews {

    private const val PROGRESS_MAX = 1000
    private const val ICON_WHITE = 0xFFFFFFFF.toInt()
    private const val ICON_LIKED = 0xFFF08FB0.toInt()
    private const val ICON_ON_ACCENT = 0xFF2A1F5C.toInt()

    @Suppress("UNUSED_PARAMETER")
    fun build(
        context: Context,
        appWidgetId: Int,
        eqFrame: Int? = null,
        progressOverride: Float? = null,
    ): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_full_art)
        val resolved = WidgetViews.resolve(context)
        val snapshot = resolved.snapshot
        val receiver = FullArtWidgetReceiver::class.java

        if (!resolved.usableSession) {
            views.setViewVisibility(R.id.widget_empty_group, View.VISIBLE)
            views.setViewVisibility(R.id.widget_content_group, View.GONE)
            views.setImageViewResource(R.id.widget_art, R.drawable.widget_art_placeholder)
            views.setImageViewResource(R.id.widget_empty_icon, R.drawable.widget_art_placeholder)
            if (resolved.hasAccess) {
                views.setTextViewText(R.id.widget_empty_title, context.getString(R.string.widget_full_art_name))
                views.setTextViewText(R.id.widget_empty_sub, "Start a song in any media app")
                views.setOnClickPendingIntent(R.id.widget_root, WidgetActions.openAppPending(context))
            } else {
                views.setTextViewText(R.id.widget_empty_title, "Allow music access")
                views.setTextViewText(R.id.widget_empty_sub, "Tap to detect every media app")
                views.setOnClickPendingIntent(R.id.widget_root, WidgetActions.openAccessPending(context))
            }
            return views
        }

        views.setViewVisibility(R.id.widget_empty_group, View.GONE)
        views.setViewVisibility(R.id.widget_content_group, View.VISIBLE)

        views.setTextViewText(R.id.widget_title, snapshot.title.ifBlank { "Unknown track" })
        views.setTextViewText(R.id.widget_subtitle, snapshot.artist.ifBlank { "Unknown artist" })

        val art = resolveArt(snapshot.artPath)
        if (art != null && !art.isRecycled) {
            views.setImageViewBitmap(R.id.widget_art, art)
        } else {
            views.setImageViewResource(R.id.widget_art, R.drawable.widget_art_placeholder)
        }

        runCatching {
            val fraction = (progressOverride ?: snapshot.progress).coerceIn(0f, 1f)
            views.setProgressBar(R.id.widget_progress, PROGRESS_MAX, (fraction * PROGRESS_MAX).toInt(), false)
        }

        views.setImageViewResource(
            R.id.widget_play_pause,
            if (snapshot.isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play,
        )
        views.setImageViewResource(
            R.id.widget_like,
            if (snapshot.isLiked) R.drawable.ic_widget_heart_filled else R.drawable.ic_widget_heart,
        )

        runCatching {
            views.setInt(R.id.widget_prev, "setColorFilter", ICON_WHITE)
            views.setInt(R.id.widget_next, "setColorFilter", ICON_WHITE)
            views.setInt(R.id.widget_download, "setColorFilter", ICON_WHITE)
            views.setInt(R.id.widget_play_pause, "setColorFilter", ICON_ON_ACCENT)
            views.setInt(R.id.widget_like, "setColorFilter", if (snapshot.isLiked) ICON_LIKED else ICON_WHITE)
        }

        views.setOnClickPendingIntent(R.id.widget_root, WidgetActions.openAppPending(context))
        views.setOnClickPendingIntent(R.id.widget_play_pause, WidgetActions.togglePending(context, receiver))
        views.setOnClickPendingIntent(R.id.widget_prev, WidgetActions.prevPending(context, receiver))
        views.setOnClickPendingIntent(R.id.widget_next, WidgetActions.nextPending(context, receiver))
        views.setOnClickPendingIntent(R.id.widget_like, WidgetActions.likePending(context, receiver))
        views.setOnClickPendingIntent(R.id.widget_download, WidgetActions.downloadPending(context, receiver))
        return views
    }

    /** Decodes the cached artwork, center-crops it to a square and rounds the corners to match the card. */
    private fun resolveArt(path: String?): Bitmap? = runCatching {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.exists()) return null
        val decoded = BitmapFactory.decodeFile(file.absolutePath) ?: return null
        val side = minOf(decoded.width, decoded.height)
        if (side <= 0) return decoded
        val out = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val radius = side * 0.12f
        canvas.drawRoundRect(RectF(0f, 0f, side.toFloat(), side.toFloat()), radius, radius, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        val left = (decoded.width - side) / 2f
        val top = (decoded.height - side) / 2f
        canvas.drawBitmap(decoded, -left, -top, paint)
        paint.xfermode = null
        runCatching { decoded.recycle() }
        out
    }.getOrNull()
}
