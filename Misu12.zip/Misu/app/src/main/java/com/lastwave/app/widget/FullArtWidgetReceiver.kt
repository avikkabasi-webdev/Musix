package com.lastwave.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * "Misu Full Art" widget provider. Play/pause, previous and next go through the
 * same [WidgetActions] transport as the other widgets. Like and Download are
 * forwarded to the playback service (the same actions its notification uses);
 * Like also flips the heart immediately so the tap feels instant.
 */
class FullArtWidgetReceiver : AppWidgetProvider() {

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (appWidgetId in ids) {
            runCatching {
                manager.updateAppWidget(appWidgetId, FullArtWidgetViews.build(context, appWidgetId))
            }
        }
        ioScope.launch {
            runCatching {
                val snapshot = WidgetSnapshot.read(context)
                if (snapshot.hasSession && snapshot.isPlaying) {
                    WidgetUpdater.startWaveAnimation(context.applicationContext)
                }
            }
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle?,
    ) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        runCatching {
            manager.updateAppWidget(appWidgetId, FullArtWidgetViews.build(context, appWidgetId))
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            WidgetActions.ACTION_TOGGLE,
            WidgetActions.ACTION_NEXT,
            WidgetActions.ACTION_PREV,
            WidgetActions.ACTION_LIKE,
            WidgetActions.ACTION_DOWNLOAD,
            -> {
                val action = intent.action ?: return
                val pending = goAsync()
                ioScope.launch {
                    try {
                        when (action) {
                            WidgetActions.ACTION_TOGGLE -> WidgetActions.performToggle(context)
                            WidgetActions.ACTION_NEXT -> WidgetActions.performSkip(context, next = true)
                            WidgetActions.ACTION_PREV -> WidgetActions.performSkip(context, next = false)
                            WidgetActions.ACTION_LIKE -> {
                                val wasLiked = WidgetSnapshot.read(context).isLiked
                                WidgetUpdater.setLiked(context, !wasLiked)
                                runCatching {
                                    WidgetActions.servicePending(context, WidgetActions.SERVICE_ACTION_LIKE).send()
                                }
                            }
                            WidgetActions.ACTION_DOWNLOAD -> runCatching {
                                WidgetActions.servicePending(context, WidgetActions.SERVICE_ACTION_DOWNLOAD).send()
                            }
                        }
                    } finally {
                        runCatching { pending.finish() }
                    }
                }
                return
            }
            else -> super.onReceive(context, intent)
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        ioScope.launch { runCatching { WidgetUpdater.sync(context) } }
    }
}
