package com.lastwave.app.ui.common

import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


/**
 * The one overflow ("more options") trigger used across every song list in
 * the app: Home, Discover, Playlist, Search, and Genre Detail all use this
 * same composable instead of each screen styling its own IconButton, so
 * the trigger looks and behaves identically everywhere.
 *
 * It is a plain icon with no tinted container behind it (the old filled
 * tonal box was removed). Size and the leading padding are unchanged, so row
 * layouts stay the same. The leading padding keeps a gap between a preceding
 * chip/badge (e.g. Home's "x2/x3" badge) and this button; it lives here once
 * rather than at each call site.
 */
@Composable
fun OverflowMenuButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .padding(start = 10.dp)
            .width(26.dp)
            .height(32.dp),
    ) {
        Icon(
            Icons.Filled.MoreVert,
            contentDescription = "More options",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
    }
}
