package com.lastwave.app

import android.app.Application
import android.app.ActivityManager
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.lastwave.app.data.repository.ThemeRepository
import com.lastwave.app.widget.WidgetUpdater
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class LastWaveApplication : Application(), ImageLoaderFactory {

    @Inject lateinit var themeRepository: dagger.Lazy<ThemeRepository>
    @Inject lateinit var applicationScope: CoroutineScope
    @Inject lateinit var okHttpClient: dagger.Lazy<okhttp3.OkHttpClient>
    @Inject lateinit var streamExtractor: dagger.Lazy<com.lastwave.app.data.music.YouTubeStreamExtractor>
    @Inject lateinit var innerTubeMusicApi: dagger.Lazy<com.lastwave.app.data.music.InnerTubeMusicApi>
    @Inject lateinit var ytMusicSyncManager: dagger.Lazy<com.lastwave.app.data.ytmusic.YtMusicSyncManager>
    @Inject lateinit var ytMusicHistorySyncManager: dagger.Lazy<com.lastwave.app.data.ytmusic.YtMusicHistorySyncManager>
    @Inject lateinit var likedSongsManager: dagger.Lazy<com.lastwave.app.data.playlist.LikedSongsManager>
    @Inject lateinit var trackDownloadManager: dagger.Lazy<com.lastwave.app.data.download.TrackDownloadManager>
    @Inject lateinit var discordPresenceManager: dagger.Lazy<com.lastwave.app.presence.DiscordPresenceManager>
    @Inject lateinit var appLocaleManager: dagger.Lazy<com.lastwave.app.util.AppLocaleManager>

    override fun attachBaseContext(base: Context) {
        // Pin the selected locale before any component (providers, services,
        // widgets) can load resources with the wrong configuration.
        super.attachBaseContext(com.lastwave.app.util.AppLocaleManager.wrap(base))
        // Content providers (including AndroidX startup/profile components)
        // are created before Application.onCreate(). Install diagnostics here
        // so failures in that earlier device-dependent phase are not lost.
        // This replaces CrashGuard: it records the same uncaught exceptions plus
        // ANRs, native crashes and low-memory kills, keeping the last 10 as
        // separate readable files instead of one truncating log.
        com.lastwave.app.diagnostics.Diagnostics.install(this)
        StartupTrail.begin(this)
        StartupTrail.mark("app.attach")
    }

    override fun onCreate() {
        super.onCreate()
        StartupTrail.mark("app.onCreate.start")
        // Sync per-app locale (Settings -> Language) before any UI is drawn.
        // AppCompat restores the last requested locale itself; the collector
        // inside keeps it in sync with DataStore afterwards.
        runCatching { appLocaleManager.get().start() }
        runCatching { com.lastwave.app.playback.PlaybackDiagnostics.install(this) }
        runCatching { com.lastwave.app.data.music.potoken.BotGuardTokenGenerator.initialize(this) }
        runCatching { com.lastwave.app.data.canvas.CanvasCache.init(this) }
        // On-demand lyric translation/romanization keeps its bounded result
        // cache under the app cache directory so Android may reclaim it.
        runCatching { com.lastwave.app.data.lyrics.LyricsTranslation.cacheDir = cacheDir }
        // First-song OPUS warmup: visitorData + NewPipe + BotGuard must be
        // ready before the first tap, not 2.5s after. Immediate and never
        // throws; the delayed block below keeps the rest lazy.
        applicationScope.launch(Dispatchers.IO) {
            // NewPipe is optional fallback infrastructure. A broken extractor
            // install must not escape an application-scope coroutine.
            runCatching { streamExtractor.get().preWarm() }
            // Warm the InnerTube web config (visitor data) so the first
            // playback's direct-URL fast path can attach it immediately.
            runCatching { innerTubeMusicApi.get().preWarmPlayback() }
        }
        applicationScope.launch(Dispatchers.IO) {
            delay(OPTIONAL_STARTUP_DELAY_MS)
            // A process kill can bypass TrackDownloadManager's finally block
            // and strand a full lossless track in cache. Remove only old temp
            // files so cleanup cannot race a newly started download.
            runCatching {
                val orphanCutoff = System.currentTimeMillis() - ORPHAN_TEMP_MAX_AGE_MS
                // Every temp prefix the download/tag/transcode pipeline can
                // leave behind: raw payloads, remuxes, tagged copies,
                // rename backups and transcoder intermediates. Stranded
                // multi-MB files otherwise accumulate with every download.
                val orphanPrefixes = setOf(
                    "dl_raw_", "dl_remux_", "tagged_",
                    "untagged_", "trans_pcm_", "trans_flac_",
                )
                cacheDir.listFiles { file ->
                    file.isFile &&
                        orphanPrefixes.any { prefix -> file.name.startsWith(prefix) } &&
                        file.lastModified() < orphanCutoff
                }?.forEach { file -> runCatching { file.delete() } }
            }
            runCatching { likedSongsManager.get().start() }
                .onFailure { com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "Liked Songs startup disabled", it) }
        }
        // Never create BotGuard's headless WebView during app launch. Some
        // Android 11 OEM devices have a missing/updating WebView provider,
        // which can terminate the process. Playback initializes it on demand.
        // YouTube Music playlist sync heartbeat (no-ops until an account is
        // connected AND sync is enabled in Settings).
        applicationScope.launch {
            delay(OPTIONAL_STARTUP_DELAY_MS)
            runCatching { ytMusicSyncManager.get().start() }
                .onFailure { com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "YT sync startup disabled", it) }
        }
        // YouTube Music playback-history sync (no-ops until an account is
        // connected AND history sync is enabled in Settings — on by default).
        // Observes playback state only; it can never affect audio delivery.
        applicationScope.launch {
            delay(OPTIONAL_STARTUP_DELAY_MS)
            runCatching { ytMusicHistorySyncManager.get().start() }
                .onFailure { com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "YT history sync startup disabled", it) }
        }
        // Reconcile public download directory & MediaStore with local database
        // asynchronously on startup so offline playback works immediately.
        applicationScope.launch(Dispatchers.IO) {
            delay(OPTIONAL_STARTUP_DELAY_MS)
            runCatching { trackDownloadManager.get().syncDownloadsFromStorage() }
                .onFailure { com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "Download sync startup failed", it) }
        }
        // Discord Rich Presence (no-ops unless the switch is on AND the Discord
        // app is installed and signed in). Observes playback state only; it can
        // never affect audio delivery, and every failure stays contained here so
        // a missing Discord install cannot reach startup.
        applicationScope.launch {
            delay(OPTIONAL_STARTUP_DELAY_MS)
            runCatching { discordPresenceManager.get().start() }
                .onFailure { com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "Discord presence startup disabled", it) }
        }
        // A widget is a separate RemoteViews surface, so it needs an explicit
        // refresh whenever LastWave's live theme changes. The widget's palette
        // only consumes primary/onPrimary (every other role is fixed), so
        // dedupe on those — otherwise ANY DataStore settings change (pins,
        // toggles, font) rebuilt every placed widget.
        applicationScope.launch(Dispatchers.IO) {
            delay(OPTIONAL_STARTUP_DELAY_MS)
            try {
                themeRepository.get().uiState
                    .map { it.colorScheme.primary to it.colorScheme.onPrimary }
                    .distinctUntilChanged()
                    .collect {
                        WidgetUpdater.refreshTheme(this@LastWaveApplication)
                    }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "Widget theme observer disabled", error)
            }
        }
        StartupTrail.mark("app.onCreate.end")
    }

    /**
     * App-wide Coil configuration (purely a performance concern — request
     * semantics are unchanged):
     *  - respectCacheHeaders(false): Last.fm / iTunes artwork URLs are
     *    immutable, but their CDNs send conservative cache headers; honoring
     *    them meant already-seen artwork could be re-fetched over the
     *    network on later scroll-bys. Ignoring the headers makes the disk
     *    cache authoritative, so each artwork downloads at most once.
     *  - Bounded, explicit memory/disk caches so scroll-bys of previously
     *    seen rows are pure in-memory hits.
     *  - Hardware acceleration enabled for fast GPU texture uploading.
     */
    override fun newImageLoader(): ImageLoader {
        val lowRamDevice = runCatching {
            (getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true
        }.getOrDefault(false)
        val imageClient = try {
            okHttpClient.get().newBuilder()
            .dispatcher(okhttp3.Dispatcher().apply {
                // Bound decode/network bursts: artwork hosts are shared by
                // many visible rows, and 128 simultaneous responses can turn
                // into a GC/decode storm on mobile CPUs.
                maxRequests = if (lowRamDevice) 16 else 48
                maxRequestsPerHost = if (lowRamDevice) 4 else 8
            })
            .connectionPool(okhttp3.ConnectionPool(if (lowRamDevice) 8 else 16, 5, java.util.concurrent.TimeUnit.MINUTES))
            .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        } catch (error: Exception) {
            com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "Shared artwork client unavailable; using isolated client", error)
            okhttp3.OkHttpClient.Builder().build()
        } catch (error: LinkageError) {
            com.lastwave.app.diagnostics.AppLog.e("LastWaveStartup", "Shared artwork client unsupported; using isolated client", error)
            okhttp3.OkHttpClient.Builder().build()
        }

        return ImageLoader.Builder(this)
            .okHttpClient(imageClient)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(if (lowRamDevice) 0.08 else 0.18)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    // Enough for hundreds of compressed covers without
                    // allowing artwork to dominate the app's storage usage.
                    .maxSizeBytes(if (lowRamDevice) LOW_RAM_IMAGE_DISK_CACHE_BYTES else IMAGE_DISK_CACHE_BYTES)
                    .build()
            }
            .respectCacheHeaders(false)
            .allowHardware(true)
            .crossfade(150)
            .build()

    }

    private companion object {
        const val IMAGE_DISK_CACHE_BYTES = 32L * 1024 * 1024
        const val LOW_RAM_IMAGE_DISK_CACHE_BYTES = 16L * 1024 * 1024
        const val ORPHAN_TEMP_MAX_AGE_MS = 6L * 60 * 60 * 1000
        const val OPTIONAL_STARTUP_DELAY_MS = 2_500L
    }
}
