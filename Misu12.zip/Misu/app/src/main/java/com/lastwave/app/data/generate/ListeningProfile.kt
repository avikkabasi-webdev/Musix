package com.lastwave.app.data.generate

import android.content.Context
import com.lastwave.app.data.genre.GenreResolver
import com.lastwave.app.data.local.db.RecommendationExclusionDao
import com.lastwave.app.data.local.db.SongPlayStatsDao
import com.lastwave.app.data.local.db.SongPlayStatsEntity
import com.lastwave.app.util.ArtistHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject
import javax.inject.Singleton

/** How a piece of music (by genre) relates to what the user actually listens to. */
enum class GenreVerdict { LIKED, AVOIDED, UNKNOWN }

/**
 * What the user *actually* listens to, built only from on-device playback
 * (accumulated listening time, completed plays, skips, "don't recommend").
 * Home "For you", New Releases and the auto-next queue all read this so none
 * of them fall back to generic charts or to music the user keeps skipping.
 */
data class ListeningProfile(
    /** True once there is enough real listening to personalise on. */
    val hasHistory: Boolean = false,
    /** Songs the user really listened to (stats-style keys: "title|artist"). */
    val playedKeys: Set<String> = emptySet(),
    /** Listened songs, best first. */
    val playedTracks: List<SongPlayStatsEntity> = emptyList(),
    /** Lower-cased artist name -> affinity 0..1 (only artists the user enjoys). */
    val artistWeights: Map<String, Double> = emptyMap(),
    /** Lower-cased artist names the user keeps skipping / excluded. */
    val avoidedArtists: Set<String> = emptySet(),
    /** Songs the user skipped repeatedly or said "don't recommend". */
    val avoidedKeys: Set<String> = emptySet(),
    /** Genres of the music the user plays most, most common first. */
    val likedGenres: List<String> = emptyList(),
    /** Genres of music the user keeps skipping that they do not also play. */
    val avoidedGenres: List<String> = emptyList(),
) {
    private val likedTokens: Set<String> = likedGenres.flatMapTo(mutableSetOf()) { GenreMatcher.tokens(it) }
    private val avoidedTokens: Set<String> = avoidedGenres.flatMapTo(mutableSetOf()) { GenreMatcher.tokens(it) }

    private fun artistNames(artist: String): List<String> =
        ArtistHelper.splitArtists(artist).map { it.trim().lowercase() }.filter { it.isNotBlank() }
            .ifEmpty { listOf(artist.trim().lowercase()) }

    fun statsKey(title: String, artist: String): String = "${title.trim()}|${artist.trim()}".lowercase()

    fun isPlayed(title: String, artist: String): Boolean = statsKey(title, artist) in playedKeys

    fun isAvoided(title: String, artist: String): Boolean {
        if (statsKey(title, artist) in avoidedKeys) return true
        val normalised = "${title.normalizeTrackText()}|${artist.normalizeTrackText()}".lowercase()
        if (normalised in avoidedKeys) return true
        val names = artistNames(artist)
        return names.isNotEmpty() && names.all { it in avoidedArtists }
    }

    fun artistWeight(artist: String): Double =
        artistNames(artist).maxOfOrNull { artistWeights[it] ?: 0.0 } ?: 0.0

    fun likesArtist(artist: String): Boolean = artistWeight(artist) > 0.0

    fun genreVerdict(genres: Collection<String>): GenreVerdict {
        if (genres.isEmpty()) return GenreVerdict.UNKNOWN
        val tokens = genres.flatMapTo(mutableSetOf()) { GenreMatcher.tokens(it) }
        if (tokens.isEmpty()) return GenreVerdict.UNKNOWN
        if (GenreMatcher.overlaps(tokens, likedTokens)) return GenreVerdict.LIKED
        if (GenreMatcher.overlaps(tokens, avoidedTokens)) return GenreVerdict.AVOIDED
        return GenreVerdict.UNKNOWN
    }
}

/** Loose genre-name matching ("Hip-Hop/Rap" ~ "hip hop", "R&B" ~ "rnb"). */
object GenreMatcher {
    private val SPLIT = Regex("[^a-z0-9]+")
    private val IGNORED = setOf(
        "music", "the", "and", "of", "seen", "live", "favorites", "favourites", "favorite",
        "favourite", "male", "female", "vocalists", "vocalist", "british", "american",
        "beautiful", "awesome", "love", "good", "best", "songs", "song", "new", "00s", "10s",
        "20s", "60s", "70s", "80s", "90s", "general", "other",
    )
    private val SHORT_OK = setOf("pop", "rap", "edm", "rnb", "emo", "ska", "dub", "hip", "hop")

    fun tokens(genre: String): Set<String> {
        val s = genre.lowercase()
            .replace("r&b", "rnb").replace("r'n'b", "rnb").replace("r and b", "rnb")
            .replace("k-pop", "kpop").replace("j-pop", "jpop")
        return s.split(SPLIT).filter { it.isNotBlank() && it !in IGNORED }.toSet()
    }

    fun overlaps(a: Set<String>, b: Set<String>): Boolean =
        a.any { x -> x in b && (x.length >= 4 || x in SHORT_OK) }
}

private const val PROFILE_TTL_MILLIS = 5L * 60 * 1000
private const val MIN_PLAYED_FOR_HISTORY = 3
private const val MIN_LISTEN_MS = 30_000L
private const val GENRE_PREFS = "listening_profile_genres"
private const val GENRE_PREFS_MAX = 600

/**
 * Builds [ListeningProfile] from the local play-stats table and the
 * "don't recommend" list. Genres are looked up lazily through
 * [GenreResolver] and remembered on disk so they cost nothing after the
 * first time.
 */
@Singleton
class ListeningProfileRepository @Inject constructor(
    @ApplicationContext context: Context,
    private val statsDao: SongPlayStatsDao,
    private val exclusionDao: RecommendationExclusionDao,
    private val genreResolver: GenreResolver,
) {
    private val mutex = Mutex()
    private val genreLookups = Semaphore(4)
    @Volatile private var cached: ListeningProfile? = null
    @Volatile private var cachedAtMillis = 0L
    private val prefs by lazy { context.applicationContext.getSharedPreferences(GENRE_PREFS, Context.MODE_PRIVATE) }

    /** Drops the cached snapshot (call after the user's stats change a lot). */
    fun invalidate() {
        cachedAtMillis = 0L
    }

    suspend fun snapshot(forceRefresh: Boolean = false): ListeningProfile {
        val now = System.currentTimeMillis()
        cached?.let { if (!forceRefresh && now - cachedAtMillis < PROFILE_TTL_MILLIS) return it }
        return mutex.withLock {
            val again = System.currentTimeMillis()
            cached?.let { if (!forceRefresh && again - cachedAtMillis < PROFILE_TTL_MILLIS) return@withLock it }
            val built = runCatching { build() }.getOrNull() ?: cached ?: ListeningProfile()
            cached = built
            cachedAtMillis = System.currentTimeMillis()
            built
        }
    }

    private fun score(s: SongPlayStatsEntity, now: Long): Double {
        val minutes = (s.totalPlayTimeMs / 60_000.0).coerceAtMost(15.0)
        val recency = if (now - s.lastPlayedAtMillis < 14L * 86_400_000L) 1.0 else 0.0
        return minutes + s.playCount * 1.5 - s.skipCount * 2.0 + recency
    }

    private suspend fun build(): ListeningProfile {
        val now = System.currentTimeMillis()
        val all = (statsDao.mostPlayedSince(0L, 300) + statsDao.recentlyPlayed(300))
            .distinctBy { it.trackKey }
        val exclusions = exclusionDao.getAll()

        fun skippedOnly(s: SongPlayStatsEntity) = s.skipCount >= 2 && s.playCount == 0
        fun listened(s: SongPlayStatsEntity) =
            (s.playCount > 0 || s.totalPlayTimeMs >= MIN_LISTEN_MS) && !skippedOnly(s)

        val played = all.filter(::listened).sortedByDescending { score(it, now) }
        val avoidedStats = all.filter(::skippedOnly)

        val avoidedKeys = buildSet {
            avoidedStats.forEach { add(it.trackKey) }
            exclusions.forEach { add(it.trackKey.lowercase()) }
        }

        // Artist level: enjoyed vs. repeatedly skipped / excluded.
        val weight = mutableMapOf<String, Double>()
        val skips = mutableMapOf<String, Int>()
        val completes = mutableMapOf<String, Int>()
        for (s in all) {
            val names = ArtistHelper.splitArtists(s.artist).map { it.trim().lowercase() }.filter { it.isNotBlank() }
            for (name in names) {
                skips[name] = (skips[name] ?: 0) + s.skipCount
                completes[name] = (completes[name] ?: 0) + s.playCount
                if (listened(s)) weight[name] = (weight[name] ?: 0.0) + score(s, now).coerceAtLeast(0.0)
            }
        }
        val excludedArtists = exclusions.map { it.artistName.trim().lowercase() }.filter { it.isNotBlank() }
            .groupingBy { it }.eachCount()
        val avoidedArtists = buildSet {
            skips.forEach { (artist, n) -> if (n >= 2 && (completes[artist] ?: 0) == 0) add(artist) }
            excludedArtists.forEach { (artist, n) -> if (n >= 2) add(artist) }
        }
        val maxWeight = weight.values.maxOrNull()?.takeIf { it > 0.0 } ?: 1.0
        val artistWeights = weight
            .filter { (artist, w) -> w > 0.0 && artist !in avoidedArtists }
            .mapValues { (_, w) -> (w / maxWeight).coerceIn(0.05, 1.0) }

        // Genre level.
        val likedSeeds = played.take(8)
        val avoidedSeeds = buildList {
            avoidedStats.take(6).forEach { add(it.title to it.artist) }
            exclusions.take(4).forEach { if (it.trackName.isNotBlank()) add(it.trackName to it.artistName) }
        }.distinct().take(8)
        val likedGenreLists = resolveGenres(likedSeeds.map { it.title to it.artist })
        val likedGenres = likedGenreLists.flatten()
            .map { it.trim() }.filter { it.isNotBlank() && GenreMatcher.tokens(it).isNotEmpty() }
            .groupingBy { it.lowercase() }.eachCount()
            .entries.sortedByDescending { it.value }.map { it.key }
        val likedTokens = likedGenres.flatMapTo(mutableSetOf()) { GenreMatcher.tokens(it) }
        val avoidedGenres = resolveGenres(avoidedSeeds).flatten()
            .map { it.trim().lowercase() }
            .filter { g ->
                val t = GenreMatcher.tokens(g)
                t.isNotEmpty() && !GenreMatcher.overlaps(t, likedTokens)
            }.distinct()

        return ListeningProfile(
            hasHistory = played.size >= MIN_PLAYED_FOR_HISTORY,
            playedKeys = played.mapTo(mutableSetOf()) { it.trackKey },
            playedTracks = played,
            artistWeights = artistWeights,
            avoidedArtists = avoidedArtists,
            avoidedKeys = avoidedKeys,
            likedGenres = likedGenres,
            avoidedGenres = avoidedGenres,
        )
    }

    private suspend fun resolveGenres(tracks: List<Pair<String, String>>): List<List<String>> {
        if (tracks.isEmpty()) return emptyList()
        // One shared time budget so a slow network never stalls the feed.
        val results = mutableListOf<List<String>>()
        withTimeoutOrNull(4_000L) {
            coroutineScope {
                tracks.map { (title, artist) -> async(Dispatchers.IO) { genresFor(title, artist) } }
                    .awaitAll()
            }
        }?.let { results.addAll(it) }
            ?: tracks.forEach { (title, artist) -> cachedGenres(title, artist)?.let { results.add(it) } }
        return results
    }

    /**
     * Genre verdict per item, looked up within [budgetMs]. Anything still
     * unresolved is UNKNOWN ("no opinion"), so a slow network never blocks
     * playback or empties a shelf.
     */
    suspend fun <T> genreVerdicts(
        profile: ListeningProfile,
        items: List<T>,
        title: (T) -> String,
        artist: (T) -> String,
        budgetMs: Long = 2_500L,
    ): List<GenreVerdict> {
        if (items.isEmpty() || (profile.likedGenres.isEmpty() && profile.avoidedGenres.isEmpty())) {
            return items.map { GenreVerdict.UNKNOWN }
        }
        val verdicts = java.util.concurrent.ConcurrentHashMap<Int, GenreVerdict>()
        coroutineScope {
            val jobs = items.mapIndexed { index, item ->
                launch(Dispatchers.IO) {
                    verdicts[index] = profile.genreVerdict(genresFor(title(item), artist(item)))
                }
            }
            withTimeoutOrNull(budgetMs) { jobs.joinAll() }
            jobs.forEach { it.cancel() }
        }
        return items.indices.map { verdicts[it] ?: GenreVerdict.UNKNOWN }
    }

    /**
     * Drops songs whose genre the user keeps skipping (unless they like the
     * artist). Unknown genres are kept.
     */
    suspend fun <T> dropAvoidedGenres(
        profile: ListeningProfile,
        items: List<T>,
        title: (T) -> String,
        artist: (T) -> String,
        budgetMs: Long = 2_500L,
    ): List<T> {
        if (profile.avoidedGenres.isEmpty() || items.isEmpty()) return items
        val verdicts = genreVerdicts(profile, items, title, artist, budgetMs)
        return items.filterIndexed { index, item ->
            !(verdicts[index] == GenreVerdict.AVOIDED && !profile.likesArtist(artist(item)))
        }
    }

    private fun cacheKey(title: String, artist: String) = "g:${title.trim()}|${artist.trim()}".lowercase()

    private fun cachedGenres(title: String, artist: String): List<String>? =
        runCatching { prefs.getString(cacheKey(title, artist), null) }.getOrNull()
            ?.split(',')?.map { it.trim() }?.filter { it.isNotBlank() }?.takeIf { it.isNotEmpty() }

    /**
     * Genres of one song (from the on-disk cache, else Last.fm tags / iTunes).
     * Returns an empty list when unknown — callers must treat that as "no
     * opinion", never as "disliked".
     */
    suspend fun genresFor(title: String, artist: String): List<String> {
        if (title.isBlank() || artist.isBlank()) return emptyList()
        cachedGenres(title, artist)?.let { return it }
        val resolved = genreLookups.withPermit {
            withTimeoutOrNull(3_500L) {
                runCatching { genreResolver.resolve(title, ArtistHelper.primaryArtist(artist).ifBlank { artist }) }
                    .getOrDefault("")
            }.orEmpty()
        }
        val list = resolved.split(',').map { it.trim() }.filter { it.isNotBlank() }
        if (list.isNotEmpty()) {
            runCatching {
                if (prefs.all.size > GENRE_PREFS_MAX) prefs.edit().clear().apply()
                prefs.edit().putString(cacheKey(title, artist), list.joinToString(",")).apply()
            }
        }
        return list
    }
}
