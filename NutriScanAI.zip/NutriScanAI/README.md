# NutriScan AI (native Android)

A fully native Android app written in Kotlin with Jetpack Compose. No WebView.

- Minimum Android: 7.0 (API 24) · Target: Android 14 (API 34)
- Live camera preview, food-photo scanning, barcode scanning (ML Kit) and gallery picking
- AI food analysis (Gemini / Groq), Open Food Facts barcode lookup, nutrition scoring
- Scan history, favorites, insights, weekly chart, profile with 30 avatars, settings, AI chat per scan
- Everything is stored on the device

## Build on GitHub

1. Put this zip (unchanged) in the **root** of your repo next to `.github/workflows/build-apk.yml`.
   It must be the only `.zip` in the repo.
2. Push to `main` or run the workflow from the Actions tab.
3. Download the APK from the run's **Artifacts**.

## Build locally

    ./gradlew assembleDebug

APK output: `app/build/outputs/apk/debug/`

## API keys

`app/src/main/java/com/nutriscan/ai/BuiltInKeys.kt` holds the built-in Groq/Gemini keys carried over from
the website. If your repo is public, empty them and add your own keys in the app under
Settings > AI API keys.
