package com.nutriscan.ai

import android.app.Application
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

sealed class Screen {
    object Home : Screen()
    object Scan : Screen()
    object Analyzing : Screen()
    class NoFood(val barcode: Boolean) : Screen()
    object Result : Screen()
    object Profile : Screen()
    object EditProfile : Screen()
    object History : Screen()
    object Settings : Screen()
    object Keys : Screen()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    var profile by mutableStateOf(store.loadProfile())
        private set
    var settings by mutableStateOf(store.loadSettings())
        private set
    var scans by mutableStateOf(store.loadScans())
        private set
    var geminiKeys by mutableStateOf(store.loadKeys("gemini"))
        private set
    var groqKeys by mutableStateOf(store.loadKeys("groq"))
        private set

    var stack by mutableStateOf<List<Screen>>(listOf(Screen.Home))
        private set
    var current by mutableStateOf<Scan?>(null)
        private set
    var analyzingImage by mutableStateOf<Bitmap?>(null)
        private set
    var loadingText by mutableStateOf<String?>(null)
        private set
    var alert by mutableStateOf<Pair<String, String>?>(null)
    var asking by mutableStateOf(false)
        private set
    var favoritesOnly by mutableStateOf(false)

    private var job: Job? = null

    init {
        // First launch: give the person a random avatar so the profile never looks empty.
        if (profile.avatar < 0) {
            profile = profile.copy(avatar = (0 until AVATAR_COUNT).random())
            store.saveProfile(profile)
        }
    }

    val top: Screen get() = stack.last()

    // ------------------------------------------------------------- navigation

    fun push(s: Screen) { stack = stack + s }
    fun replaceTop(s: Screen) { stack = stack.dropLast(1) + s }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun goHome() { job?.cancel(); loadingText = null; stack = listOf(Screen.Home) }
    fun goProfile() { job?.cancel(); loadingText = null; stack = listOf(Screen.Profile) }
    fun openScan() { push(Screen.Scan) }

    // ------------------------------------------------------------- settings / profile

    fun updateSettings(s: Settings) { settings = s; store.saveSettings(s) }
    fun updateProfile(p: Profile) { profile = p; store.saveProfile(p) }

    fun addKey(provider: String, key: String) {
        val k = key.trim()
        if (k.isEmpty()) return
        if (provider == "groq") { groqKeys = (groqKeys + k).distinct(); store.saveKeys("groq", groqKeys) }
        else { geminiKeys = (geminiKeys + k).distinct(); store.saveKeys("gemini", geminiKeys) }
    }

    fun removeKey(provider: String, key: String) {
        if (provider == "groq") { groqKeys = groqKeys - key; store.saveKeys("groq", groqKeys) }
        else { geminiKeys = geminiKeys - key; store.saveKeys("gemini", geminiKeys) }
    }

    // ------------------------------------------------------------- scans

    private fun persist(list: List<Scan>) { scans = list; store.saveScans(list) }

    fun openStored(scan: Scan) { current = scan; push(Screen.Result) }

    fun toggleFavorite() {
        val c = current ?: return
        val n = c.copy(favorite = !c.favorite)
        current = n
        persist(scans.map { if (it.id == n.id) n else it })
    }

    fun deleteCurrent() {
        val c = current ?: return
        store.deletePhoto(c.id)
        persist(scans.filter { it.id != c.id })
        current = null
        goHome()
    }

    fun clearHistory() {
        scans.forEach { store.deletePhoto(it.id) }
        persist(emptyList())
    }

    private fun finishScan(base: Scan, jpeg: ByteArray?, barcode: String) {
        val id = UUID.randomUUID().toString()
        val scan = base.copy(id = id, barcode = barcode, hasPhoto = jpeg != null)
        if (jpeg != null) store.savePhoto(id, jpeg)
        if (settings.saveHistory) persist(listOf(scan) + scans)
        current = scan
        analyzingImage = null
        loadingText = null
        stack = listOf(Screen.Home, Screen.Result)
    }

    fun analyzePhoto(bmp: Bitmap) {
        if (!Ai.hasAnyKey(store)) { push(Screen.Keys); return }
        val small = Img.scaleRotate(bmp, 0, 1024)
        analyzingImage = small
        replaceTopWith(Screen.Analyzing)
        job?.cancel()
        job = viewModelScope.launch {
            try {
                val jpeg = withContext(Dispatchers.Default) { Img.toJpeg(small, 80) }
                when (val r = Ai.analyzeFood(store, Img.toBase64(jpeg))) {
                    is Analysis.NoFood -> { analyzingImage = null; replaceTop(Screen.NoFood(false)) }
                    is Analysis.Ok -> finishScan(r.scan, jpeg, "")
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                analyzingImage = null
                alert = "Analysis failed" to (e.message ?: "Something went wrong.")
                goHome()
            }
        }
    }

    private fun replaceTopWith(s: Screen) {
        // Scan -> Analyzing replaces the camera screen, so Back from the result goes Home.
        stack = if (stack.last() is Screen.Scan) stack.dropLast(1) + s else stack + s
    }

    fun lookupBarcode(code: String) {
        job?.cancel()
        loadingText = "Looking up barcode $code…"
        job = viewModelScope.launch {
            try {
                val p = Ai.fetchOffProduct(code)
                if (p == null) {
                    loadingText = null
                    if (stack.last() is Screen.Scan) replaceTop(Screen.NoFood(true)) else push(Screen.NoFood(true))
                } else {
                    finishScan(Ai.buildFromProduct(p), null, code)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                loadingText = null
                alert = "Lookup failed" to (e.message ?: "Couldn't reach Open Food Facts.")
            }
        }
    }

    fun cancelAnalysis() { job?.cancel(); analyzingImage = null; goHome() }
    fun cancelLoading() { job?.cancel(); loadingText = null }
    fun showNoFood(barcode: Boolean) { if (stack.last() is Screen.Scan) replaceTop(Screen.NoFood(barcode)) else push(Screen.NoFood(barcode)) }

    // ------------------------------------------------------------- chat

    fun ask(question: String) {
        val c = current ?: return
        val q = question.trim()
        if (q.isEmpty() || asking) return
        if (!Ai.hasAnyKey(store)) { push(Screen.Keys); return }
        val withQ = c.copy(chat = c.chat + ChatMsg("user", q))
        current = withQ
        asking = true
        viewModelScope.launch {
            val answer = try {
                Ai.ask(store, withQ, q, settings.answerDetail == "detailed")
            } catch (e: Exception) {
                "Sorry, I could not get an answer (" + (e.message ?: "error") + ")."
            }
            val done = (current ?: withQ).let { cur ->
                if (cur.id == withQ.id) cur.copy(chat = cur.chat + ChatMsg("ai", answer)) else cur
            }
            if (current?.id == withQ.id) current = done
            persist(scans.map { if (it.id == done.id) done else it })
            asking = false
        }
    }

    // ------------------------------------------------------------- export

    fun exportJson(): String {
        val o = JSONObject()
        o.put("exportedAt", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).format(java.util.Date()))
        o.put("scans", JSONArray().also { arr -> scans.forEach { arr.put(it.toJson()) } })
        return o.toString(2)
    }
}

const val AVATAR_COUNT = 30
