package com.nutriscan.ai

/**
 * Same built-in keys the website used so AI scanning works out of the box.
 * They are always the last fallback after any keys added in Settings.
 *
 * IMPORTANT: anything committed to GitHub is readable. If your repo is public,
 * leave these empty ("") and add your own keys inside the app under
 * Settings > AI API keys instead (and revoke the old ones).
 */
object BuiltInKeys {
    const val GROQ = "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"
    const val GEMINI = "AQ.Ab8RN6Ix9UpGjoS8PPpf9xgcf5bXqVQTME4mh5hp_5FfTpEV9Q"
}
