package com.nutriscan.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Factor(val label: String, val detail: String, val rating: String)
data class ChatMsg(val role: String, val text: String)

data class Scan(
    val id: String,
    val name: String,
    val score: Int,
    val verdict: String,
    val summary: String,
    val factors: List<Factor>,
    val carbs: Double?,
    val fats: Double?,
    val good: List<String>,
    val bad: List<String>,
    val timestamp: Long,
    val imageUrl: String = "",
    val hasPhoto: Boolean = false,
    val barcode: String = "",
    val favorite: Boolean = false,
    val chat: List<ChatMsg> = emptyList()
)

data class Profile(
    val name: String = "",
    val email: String = "",
    val goals: List<String> = listOf("Eat healthier"),
    val avatar: Int = -1,
    val allergens: List<String> = emptyList(),
    val sex: String = "Male",
    val age: String = "",
    val heightUnit: String = "cm",
    val heightCm: Int = 0,
    val weightUnit: String = "kg",
    val weightKg: Double = 0.0,
    val targetKg: Double = 0.0,
    val activity: Int = 1,
    val diet: String = "No preference"
)

data class Settings(
    val autoBarcode: Boolean = true,
    val scanMode: String = "food",
    val theme: String = "system",
    val showKcal: Boolean = true,
    val weeklySummary: Boolean = true,
    val allergenAlerts: Boolean = true,
    val saveHistory: Boolean = true,
    val aiSuggest: Boolean = true,
    val answerDetail: String = "brief"
)

val ALLERGENS: Map<String, List<String>> = linkedMapOf(
    "peanuts" to listOf("peanut"),
    "tree nuts" to listOf("almond", "walnut", "cashew", "pistachio", "hazelnut", "pecan", "macadamia", "nutella"),
    "milk" to listOf("milk", "cheese", "butter", "cream", "yogurt", "yoghurt", "whey", "ice cream", "latte", "paneer"),
    "eggs" to listOf("egg", "mayonnaise", "omelet", "omelette"),
    "wheat" to listOf("wheat", "bread", "pasta", "noodle", "flour", "pizza", "burger", "sandwich", "cake", "cookie", "biscuit", "cracker", "pastry"),
    "soy" to listOf("soy", "tofu", "edamame", "tempeh"),
    "fish" to listOf("fish", "salmon", "tuna", "sushi", "anchovy", "cod"),
    "shellfish" to listOf("shrimp", "prawn", "crab", "lobster", "shellfish"),
    "sesame" to listOf("sesame", "tahini", "hummus")
)

val GOALS = listOf(
    "Eat healthier", "Lose weight", "Maintain weight", "Gain weight", "Build muscle", "Track sugar",
    "Lower sodium", "Heart health", "Lower cholesterol", "Boost energy", "Better digestion", "Manage diabetes",
    "Eat less processed", "Eat more protein", "Eat more fiber", "Cut caffeine"
)

val DIETS = listOf(
    "No preference" to "Eat anything",
    "Vegetarian" to "No meat or fish",
    "Vegan" to "Plant-based only",
    "Keto" to "Very low carb",
    "Low carb" to "Fewer starches",
    "High protein" to "Build and repair"
)

val ACTIVITY = listOf(
    "Sedentary" to "Little or no exercise",
    "Lightly active" to "Exercise 1-3 days a week",
    "Moderately active" to "Exercise 3-5 days a week",
    "Very active" to "Hard exercise 6-7 days a week"
)

fun detectAllergens(scan: Scan, profile: Profile): List<String> {
    val text = (listOf(scan.name, scan.summary) + scan.good + scan.bad).joinToString(" ").lowercase()
    return ALLERGENS.keys.filter { a ->
        (profile.allergens.isEmpty() || profile.allergens.contains(a)) && ALLERGENS[a].orEmpty().any { text.contains(it) }
    }
}

// ----------------------------------------------------------------- JSON helpers

fun Scan.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("name", name); put("score", score); put("verdict", verdict); put("summary", summary)
    put("factors", JSONArray().also { arr ->
        factors.forEach { f -> arr.put(JSONObject().put("label", f.label).put("detail", f.detail).put("rating", f.rating)) }
    })
    if (carbs != null) put("carbs", carbs)
    if (fats != null) put("fats", fats)
    put("good", JSONArray(good)); put("bad", JSONArray(bad))
    put("timestamp", timestamp); put("imageUrl", imageUrl); put("hasPhoto", hasPhoto)
    put("barcode", barcode); put("favorite", favorite)
    put("chat", JSONArray().also { arr -> chat.forEach { m -> arr.put(JSONObject().put("role", m.role).put("text", m.text)) } })
}

fun JSONArray?.strings(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).map { optString(it) }
}

fun scanFromJson(o: JSONObject): Scan {
    val fa = o.optJSONArray("factors")
    val factors = if (fa == null) emptyList() else (0 until fa.length()).map {
        val f = fa.getJSONObject(it)
        Factor(f.optString("label"), f.optString("detail"), f.optString("rating"))
    }
    val ca = o.optJSONArray("chat")
    val chat = if (ca == null) emptyList() else (0 until ca.length()).map {
        val m = ca.getJSONObject(it)
        ChatMsg(m.optString("role"), m.optString("text"))
    }
    return Scan(
        id = o.optString("id"), name = o.optString("name"), score = o.optInt("score"),
        verdict = o.optString("verdict"), summary = o.optString("summary"), factors = factors,
        carbs = if (o.has("carbs")) o.optDouble("carbs") else null,
        fats = if (o.has("fats")) o.optDouble("fats") else null,
        good = o.optJSONArray("good").strings(), bad = o.optJSONArray("bad").strings(),
        timestamp = o.optLong("timestamp"), imageUrl = o.optString("imageUrl"),
        hasPhoto = o.optBoolean("hasPhoto"), barcode = o.optString("barcode"),
        favorite = o.optBoolean("favorite"), chat = chat
    )
}

/** Everything is kept on the device: small JSON in SharedPreferences, scan photos as files. */
class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nutriscan", Context.MODE_PRIVATE)
    private val scanFile get() = File(ctx.filesDir, "scans.json")

    fun photoFile(id: String) = File(ctx.filesDir, "photo_$id.jpg")

    fun loadProfile(): Profile {
        val s = prefs.getString("profile", null) ?: return Profile()
        return try {
            val o = JSONObject(s)
            Profile(
                name = o.optString("name"), email = o.optString("email"),
                goals = o.optJSONArray("goals").strings(), avatar = o.optInt("avatar", -1),
                allergens = o.optJSONArray("allergens").strings(), sex = o.optString("sex", "Male"),
                age = o.optString("age"), heightUnit = o.optString("heightUnit", "cm"), heightCm = o.optInt("heightCm"),
                weightUnit = o.optString("weightUnit", "kg"), weightKg = o.optDouble("weightKg", 0.0),
                targetKg = o.optDouble("targetKg", 0.0), activity = o.optInt("activity", 1),
                diet = o.optString("diet", "No preference")
            )
        } catch (e: Exception) { Profile() }
    }

    fun saveProfile(p: Profile) {
        val o = JSONObject().apply {
            put("name", p.name); put("email", p.email); put("goals", JSONArray(p.goals)); put("avatar", p.avatar)
            put("allergens", JSONArray(p.allergens)); put("sex", p.sex); put("age", p.age)
            put("heightUnit", p.heightUnit); put("heightCm", p.heightCm); put("weightUnit", p.weightUnit)
            put("weightKg", p.weightKg); put("targetKg", p.targetKg); put("activity", p.activity); put("diet", p.diet)
        }
        prefs.edit().putString("profile", o.toString()).apply()
    }

    fun loadSettings(): Settings {
        val s = prefs.getString("settings", null) ?: return Settings()
        return try {
            val o = JSONObject(s)
            val d = Settings()
            Settings(
                autoBarcode = o.optBoolean("autoBarcode", d.autoBarcode), scanMode = o.optString("scanMode", d.scanMode),
                theme = o.optString("theme", d.theme), showKcal = o.optBoolean("showKcal", d.showKcal),
                weeklySummary = o.optBoolean("weeklySummary", d.weeklySummary),
                allergenAlerts = o.optBoolean("allergenAlerts", d.allergenAlerts),
                saveHistory = o.optBoolean("saveHistory", d.saveHistory), aiSuggest = o.optBoolean("aiSuggest", d.aiSuggest),
                answerDetail = o.optString("answerDetail", d.answerDetail)
            )
        } catch (e: Exception) { Settings() }
    }

    fun saveSettings(s: Settings) {
        val o = JSONObject().apply {
            put("autoBarcode", s.autoBarcode); put("scanMode", s.scanMode); put("theme", s.theme)
            put("showKcal", s.showKcal); put("weeklySummary", s.weeklySummary); put("allergenAlerts", s.allergenAlerts)
            put("saveHistory", s.saveHistory); put("aiSuggest", s.aiSuggest); put("answerDetail", s.answerDetail)
        }
        prefs.edit().putString("settings", o.toString()).apply()
    }

    fun loadKeys(provider: String): List<String> {
        val s = prefs.getString("keys_$provider", null) ?: return emptyList()
        return try { JSONArray(s).strings().filter { it.isNotBlank() } } catch (e: Exception) { emptyList() }
    }

    fun saveKeys(provider: String, keys: List<String>) {
        prefs.edit().putString("keys_$provider", JSONArray(keys.distinct()).toString()).apply()
    }

    fun loadScans(): List<Scan> {
        val f = scanFile
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { scanFromJson(arr.getJSONObject(it)) }.sortedByDescending { it.timestamp }
        } catch (e: Exception) { emptyList() }
    }

    fun saveScans(list: List<Scan>) {
        try {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            scanFile.writeText(arr.toString())
        } catch (e: Exception) { /* ignore */ }
    }

    fun savePhoto(id: String, jpeg: ByteArray) {
        try { photoFile(id).writeBytes(jpeg) } catch (e: Exception) { /* ignore */ }
    }

    fun deletePhoto(id: String) {
        try { photoFile(id).delete() } catch (e: Exception) { /* ignore */ }
    }
}
