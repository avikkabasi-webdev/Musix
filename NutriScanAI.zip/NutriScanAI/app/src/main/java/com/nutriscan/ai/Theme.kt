package com.nutriscan.ai

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Immutable
data class NsColors(
    val dark: Boolean,
    val bg: Color, val card: Color, val ink: Color, val sub: Color, val line: Color, val bubble: Color, val onInk: Color,
    val good: Color, val goodBg: Color, val mod: Color, val modBg: Color, val bad: Color, val badBg: Color,
    val extreme: Color, val extremeBg: Color, val healthy: Color, val healthyBg: Color
)

val LightNs = NsColors(
    dark = false,
    bg = Color(0xFFF7F7F8), card = Color(0xFFFFFFFF), ink = Color(0xFF0B0B0B), sub = Color(0xFF8A8A8F),
    line = Color(0xFFDCDCE0), bubble = Color(0xFFE9E9EC), onInk = Color(0xFFF7F7F8),
    good = Color(0xFF1F9D55), goodBg = Color(0xFFE5F7EC), mod = Color(0xFFDDA015), modBg = Color(0xFFFDF3DA),
    bad = Color(0xFFE8605F), badBg = Color(0xFFFCE6E6), extreme = Color(0xFFC13333), extremeBg = Color(0xFFFBDADA),
    healthy = Color(0xFF0891B2), healthyBg = Color(0xFFE0F5F9)
)

val DarkNs = NsColors(
    dark = true,
    bg = Color(0xFF0B0B0B), card = Color(0xFF141416), ink = Color(0xFFECECEE), sub = Color(0xFF8D8D93),
    line = Color(0xFF262626), bubble = Color(0xFF1A1A1A), onInk = Color(0xFF0B0B0B),
    good = Color(0xFF22C55E), goodBg = Color(0x2922C55E), mod = Color(0xFFF59E0B), modBg = Color(0xFF382409),
    bad = Color(0xFFEF4444), badBg = Color(0x29EF4444), extreme = Color(0xFFE26A6A), extremeBg = Color(0x33E26A6A),
    healthy = Color(0xFF35B6D2), healthyBg = Color(0x2935B6D2)
)

val LocalNs = staticCompositionLocalOf { LightNs }

val ns: NsColors
    @Composable get() = LocalNs.current

@Composable
fun NutriTheme(dark: Boolean, content: @Composable () -> Unit) {
    val c = if (dark) DarkNs else LightNs
    val scheme = if (dark) {
        darkColorScheme(primary = c.ink, onPrimary = c.onInk, background = c.bg, surface = c.card, onSurface = c.ink, onBackground = c.ink)
    } else {
        lightColorScheme(primary = c.ink, onPrimary = c.onInk, background = c.bg, surface = c.card, onSurface = c.ink, onBackground = c.ink)
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = c.bg.toArgb()
            window.navigationBarColor = c.bg.toArgb()
            val ctrl = WindowCompat.getInsetsController(window, view)
            ctrl.isAppearanceLightStatusBars = !dark
            ctrl.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalNs provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

fun ratingColor(c: NsColors, rating: String?): Color = when (rating) {
    "Good" -> c.good
    "Moderate" -> c.mod
    "Bad" -> c.bad
    "Extreme" -> c.extreme
    else -> c.sub
}

fun scoreColor(c: NsColors, score: Int): Color = if (score >= 70) c.good else if (score >= 40) c.mod else c.bad
fun scoreBg(c: NsColors, score: Int): Color = if (score >= 70) c.goodBg else if (score >= 40) c.modBg else c.badBg
