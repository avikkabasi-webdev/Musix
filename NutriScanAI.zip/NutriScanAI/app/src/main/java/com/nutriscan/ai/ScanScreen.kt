package com.nutriscan.ai

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun rememberCamera(): LifecycleCameraController {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val controller = remember {
        LifecycleCameraController(ctx).apply {
            setEnabledUseCases(CameraController.IMAGE_CAPTURE or CameraController.IMAGE_ANALYSIS)
        }
    }
    DisposableEffect(owner) {
        controller.bindToLifecycle(owner)
        onDispose { controller.unbind() }
    }
    return controller
}

@Composable
fun CameraSurface(controller: LifecycleCameraController, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            PreviewView(c).apply {
                this.controller = controller
                scaleType = PreviewView.ScaleType.FILL_CENTER
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
        }
    )
}

@Composable
fun ScanScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasCam by remember { mutableStateOf(cameraGranted(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
    LaunchedEffect(Unit) { if (!hasCam) permLauncher.launch(Manifest.permission.CAMERA) }

    var mode by remember { mutableStateOf(vm.settings.scanMode) }
    var torch by remember { mutableStateOf(false) }
    var lastCode by remember { mutableStateOf<String?>(null) }
    var fired by remember { mutableStateOf(false) }

    val controller = rememberCamera()
    val executor = remember { ContextCompat.getMainExecutor(ctx) }
    val scanner = remember {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A,
                    Barcode.FORMAT_UPC_E, Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_ITF
                )
                .build()
        )
    }
    DisposableEffect(Unit) { onDispose { scanner.close() } }

    LaunchedEffect(vm.loadingText) { if (vm.loadingText == null) fired = false }

    LaunchedEffect(mode, hasCam) {
        if (hasCam && mode == "barcode") {
            lastCode = null
            controller.setImageAnalysisAnalyzer(
                executor,
                MlKitAnalyzer(listOf(scanner), ImageAnalysis.COORDINATE_SYSTEM_VIEW_REFERENCED, executor) { result ->
                    val code = result?.getValue(scanner)?.firstOrNull()?.rawValue
                    if (code != null) {
                        lastCode = code
                        if (vm.settings.autoBarcode && !fired) {
                            fired = true
                            vm.lookupBarcode(code)
                        }
                    }
                }
            )
        } else {
            controller.clearImageAnalysisAnalyzer()
        }
    }

    LaunchedEffect(torch, hasCam) {
        if (hasCam) controller.enableTorch(torch)
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { Img.fromUri(ctx, uri) }
                if (bmp == null) {
                    Toast.makeText(ctx, "Couldn't open that image", Toast.LENGTH_SHORT).show()
                } else if (mode == "barcode") {
                    scanner.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { list ->
                            val code = list.firstOrNull()?.rawValue
                            if (code != null) vm.lookupBarcode(code) else vm.showNoFood(true)
                        }
                        .addOnFailureListener { vm.showNoFood(true) }
                } else {
                    vm.analyzePhoto(bmp)
                }
            }
        }
    }

    fun shutter() {
        if (mode == "barcode") {
            val c = lastCode
            if (c != null) vm.lookupBarcode(c)
            else Toast.makeText(ctx, "No barcode in view yet", Toast.LENGTH_SHORT).show()
            return
        }
        controller.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val degrees = image.imageInfo.rotationDegrees
                val raw = image.toBitmap()
                image.close()
                vm.analyzePhoto(Img.scaleRotate(raw, degrees, 1280))
            }

            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(ctx, "Couldn't take the photo", Toast.LENGTH_SHORT).show()
            }
        })
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (hasCam) {
            CameraSurface(controller, Modifier.fillMaxSize())
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                Text("Camera access is off", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Allow the camera to scan food and barcodes, or pick a photo from your gallery.",
                    color = Color(0xFFBBBBBB), fontSize = 14.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(18.dp))
                Chip("Allow camera", true) { permLauncher.launch(Manifest.permission.CAMERA) }
            }
        }

        ScanCorners(
            Modifier.align(Alignment.Center).fillMaxWidth(0.78f).height(if (mode == "barcode") 170.dp else 300.dp),
            Color.White
        )

        // top bar
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(Icons.Rounded.Close, "Close", { vm.pop() }, bg = Color(0x66000000), tint = Color.White)
            Spacer(Modifier.weight(1f))
            ModeToggle(mode) { mode = it }
            Spacer(Modifier.weight(1f))
            RoundIconButton(
                if (torch) Icons.Rounded.FlashOn else Icons.Rounded.FlashOff, "Flash", { torch = !torch },
                bg = Color(0x66000000), tint = Color.White
            )
        }

        // bottom controls
        Column(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (mode == "barcode") (if (vm.settings.autoBarcode) "Point at a barcode — it scans automatically" else "Frame a barcode, then tap the shutter")
                else "Frame your meal and tap the shutter",
                color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(bottom = 18.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 36.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    RoundIconButton(
                        Icons.Rounded.PhotoLibrary, "Gallery", { gallery.launch("image/*") },
                        size = 52.dp, bg = Color(0x66000000), tint = Color.White
                    )
                }
                Box(
                    modifier = Modifier.size(78.dp).clip(CircleShape).border(BorderStroke(4.dp, Color.White), CircleShape)
                        .padding(7.dp).clip(CircleShape).background(Color.White).tap { shutter() }
                )
                Box(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ModeToggle(mode: String, onPick: (String) -> Unit) {
    Row(
        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x66000000)).padding(4.dp)
    ) {
        listOf("food" to "Food", "barcode" to "Barcode").forEach { (k, label) ->
            val on = mode == k
            Box(
                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) Color.White else Color.Transparent)
                    .tap { onPick(k) }.padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(label, color = if (on) Color.Black else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
