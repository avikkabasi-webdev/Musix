package com.nutriscan.ai

import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun fmtNum(v: Double?): String {
    if (v == null) return "—"
    return if (v == Math.floor(v)) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ResultScreen(vm: AppViewModel) {
    val scan = vm.current
    if (scan == null) {
        LaunchedEffect(Unit) { vm.goHome() }
        return
    }
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    val nutrients = remember(scan.id, scan.factors, scan.carbs, scan.fats) { nutrientsOf(scan) }

    LaunchedEffect(scan.chat.size) {
        if (scan.chat.isNotEmpty()) scroll.animateScrollTo(Int.MAX_VALUE)
    }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(Icons.Rounded.Close, "Close", { vm.goHome() })
            Spacer(Modifier.weight(1f))
            Box {
                RoundIconButton(Icons.Rounded.MoreVert, "More", { menu = true })
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (scan.favorite) "Remove from favorites" else "Add to favorites") },
                        onClick = { menu = false; vm.toggleFavorite() }
                    )
                    DropdownMenuItem(
                        text = { Text("Share") },
                        onClick = {
                            menu = false
                            val text = "NutriScan AI: " + scan.name + " — " + scan.score + "/100 (" + scan.verdict + "). " + scan.summary
                            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                            ctx.startActivity(Intent.createChooser(send, "Share result"))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete scan", color = ns.bad) },
                        onClick = { menu = false; confirmDelete = true }
                    )
                }
            }
        }

        Column(modifier = Modifier.weight(1f).verticalScroll(scroll)) {
            ScanImage(
                scan, vm.store,
                Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(250.dp).clip(RoundedCornerShape(26.dp))
            )

            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(scan.name, color = ns.ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Pill(scan.verdict, scoreBg(ns, scan.score), scoreColor(ns, scan.score))
                            if (vm.settings.showKcal) {
                                val kc = nutrients.firstOrNull { it.key == "calories" }?.num
                                Spacer(Modifier.width(8.dp))
                                Pill((if (kc != null) kc.toInt().toString() else "—") + " kcal", ns.bubble, ns.ink)
                            }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    ScoreRing(scan.score, 76.dp, 7.dp, 22)
                }

                if (scan.summary.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(scan.summary, color = ns.sub, fontSize = 14.sp)
                }

                if (vm.settings.allergenAlerts) {
                    val hits = detectAllergens(scan, vm.profile)
                    if (hits.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        Box(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ns.modBg).padding(12.dp)
                        ) {
                            Text(
                                "Possible allergens: " + hits.joinToString(", ") + ". Based on the food’s name and description, so check the label.",
                                color = ns.mod, fontSize = 13.sp, fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("Nutrition per 100 g", color = ns.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                nutrients.filter { it.key != "calories" }.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                        row.forEach { n -> NutrientTile(n, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(8.dp))
                BulletBox("Why it’s good", scan.good, ns.goodBg, ns.good)
                Spacer(Modifier.height(10.dp))
                BulletBox("Why it’s not", scan.bad, ns.badBg, ns.bad)

                Spacer(Modifier.height(22.dp))
                Text("Ask AI about this food", color = ns.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                if (vm.settings.aiSuggest && scan.chat.isEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Is it okay every day?", "What’s a healthier swap?", "Good before a workout?").forEach { q ->
                            Chip(q, false) { vm.ask(q) }
                        }
                    }
                }
                scan.chat.forEach { m -> ChatBubble(m) }
                if (vm.asking) {
                    Text("Thinking…", color = ns.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        // footer: scan again + ask box
        Row(
            modifier = Modifier.fillMaxWidth().background(ns.bg).padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(48.dp).clip(CircleShape).background(ns.ink).tap { vm.openScan() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.CameraAlt, "Scan another", tint = ns.onInk, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(10.dp))
            Row(
                modifier = Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(50)).background(ns.bubble).padding(start = 16.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (input.isEmpty()) Text("Ask AI about this food…", color = ns.sub, fontSize = 15.sp)
                    BasicTextField(
                        value = input, onValueChange = { input = it }, singleLine = true,
                        textStyle = TextStyle(color = ns.ink, fontSize = 15.sp), cursorBrush = SolidColor(ns.ink),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { vm.ask(input); input = "" }),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Box(
                    modifier = Modifier.size(36.dp).clip(CircleShape).background(ns.ink).tap { vm.ask(input); input = "" },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Send, "Send", tint = ns.onInk, modifier = Modifier.size(17.dp)) }
            }
        }
    }

    if (confirmDelete) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { confirmDelete = false; vm.deleteCurrent() }) { Text("Delete", color = ns.bad) }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
            title = { Text("Delete this scan?") },
            text = { Text("It will be removed from your history.") }
        )
    }
}

@Composable
private fun NutrientTile(n: Nutrient, modifier: Modifier) {
    val col = ratingColor(ns, n.rating)
    val fill by animateFloatAsState(n.pct, tween(800), label = "bar")
    Column(
        modifier = modifier.clip(RoundedCornerShape(16.dp)).background(ns.card)
            .border(BorderStroke(1.dp, ns.line), RoundedCornerShape(16.dp)).padding(14.dp)
    ) {
        Text(n.label, color = ns.sub, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(fmtNum(n.num), color = ns.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(3.dp))
            Text(n.unit, color = ns.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
        Spacer(Modifier.height(8.dp))
        Box(modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(ns.bubble)) {
            Box(modifier = Modifier.fillMaxWidth(fill).fillMaxHeight().clip(CircleShape).background(col))
        }
        if (n.rating != null) {
            Spacer(Modifier.height(6.dp))
            Text(n.rating, color = col, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun BulletBox(title: String, items: List<String>, bg: Color, fg: Color) {
    Column(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(bg).padding(16.dp)) {
        Text(title, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        items.forEach { Text("•  " + it, color = ns.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
    }
}

@Composable
private fun ChatBubble(m: ChatMsg) {
    val mine = m.role == "user"
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Box(
            modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(if (mine) ns.ink else ns.bubble).padding(horizontal = 14.dp, vertical = 10.dp)
        ) { Text(m.text, color = if (mine) ns.onInk else ns.ink, fontSize = 14.sp) }
    }
}

@Composable
fun AnalyzingScreen(vm: AppViewModel) {
    val msgs = listOf("Identifying your food…", "Estimating nutrients…", "Scoring healthiness…", "Almost done…")
    val fills = listOf(0.06f, 0.34f, 0.68f, 0.68f)
    var i by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (i < msgs.size - 1) {
            kotlinx.coroutines.delay(2000)
            i += 1
        }
    }
    val fill by animateFloatAsState(fills[i], tween(900), label = "progress")
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        val img = vm.analyzingImage
        if (img != null) {
            Image(
                bitmap = img.asImageBitmap(), contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop, alpha = 0.38f
            )
        }
        Column(
            modifier = Modifier.align(Alignment.Center).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(msgs[i], color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp))
            Box(modifier = Modifier.fillMaxWidth(0.7f).height(6.dp).clip(CircleShape).background(Color(0x44FFFFFF))) {
                Box(modifier = Modifier.fillMaxWidth(fill).fillMaxHeight().clip(CircleShape).background(Color.White))
            }
            Spacer(Modifier.height(28.dp))
            Chip("Cancel", false) { vm.cancelAnalysis() }
        }
    }
}

@Composable
fun NoFoodScreen(vm: AppViewModel, barcode: Boolean) {
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(if (barcode) "Barcode not found" else "No food detected", color = ns.ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(
            if (barcode) "We couldn’t find that product. Try scanning again, or take a photo of the food instead."
            else "We couldn’t see any food in that photo. Try again with the food clearly in view.",
            color = ns.sub, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Chip("Try again", true) { vm.replaceTop(Screen.Scan) }
        Spacer(Modifier.height(10.dp))
        Chip("Back to home", false) { vm.goHome() }
    }
}
