package com.nutriscan.ai

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun NsField(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier, keyboard: KeyboardType = KeyboardType.Text) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(ns.card)
            .border(BorderStroke(1.dp, ns.line), RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 14.dp)
    ) {
        if (value.isEmpty()) Text(placeholder, color = ns.sub, fontSize = 16.sp)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = ns.ink, fontSize = 16.sp), cursorBrush = SolidColor(ns.ink),
            keyboardOptions = KeyboardOptions(keyboardType = keyboard), modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun NumField(initial: String, resetKey: Any, placeholder: String, modifier: Modifier, onValue: (Double?) -> Unit) {
    var t by remember(resetKey) { mutableStateOf(initial) }
    NsField(
        t, { raw ->
            t = raw.filter { it.isDigit() || it == '.' }
            onValue(t.toDoubleOrNull())
        }, placeholder, modifier, KeyboardType.Decimal
    )
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, color = ns.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
}

@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ns.bubble).padding(3.dp)) {
        options.forEach { (k, l) ->
            val on = k == selected
            Box(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).background(if (on) ns.card else Color.Transparent)
                    .tap { onPick(k) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(l, color = if (on) ns.ink else ns.sub, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun ChoiceRow(title: String, sub: String, on: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp)).background(ns.card)
            .border(BorderStroke(if (on) 2.dp else 1.dp, if (on) ns.ink else ns.line), RoundedCornerShape(14.dp))
            .tap(onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = ns.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = ns.sub, fontSize = 13.sp)
        }
        Box(
            modifier = Modifier.size(22.dp).clip(CircleShape).border(BorderStroke(2.dp, if (on) ns.ink else ns.line), CircleShape),
            contentAlignment = Alignment.Center
        ) { if (on) Box(modifier = Modifier.size(11.dp).clip(CircleShape).background(ns.ink)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditProfileScreen(vm: AppViewModel) {
    val saved = vm.profile
    var d by remember { mutableStateOf(saved) }
    var picker by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    val dirty = d != saved

    BackHandler(enabled = picker) { picker = false }

    fun save() {
        val email = d.email.trim()
        if (email.isNotEmpty() && !(email.contains("@") && email.substringAfter("@").contains("."))) { err = "That email doesn’t look right."; return }
        val age = d.age.trim()
        if (age.isNotEmpty()) {
            val a = age.toIntOrNull()
            if (a == null || a < 1 || a > 120) { err = "Enter an age between 1 and 120."; return }
        }
        err = ""
        vm.updateProfile(d.copy(name = d.name.trim(), email = email, age = age))
        vm.pop()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(Icons.Rounded.ArrowBack, "Back", { vm.pop() })
                Spacer(Modifier.width(12.dp))
                Text("Edit profile", color = ns.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                AnimatedVisibility(visible = dirty, enter = fadeIn(tween(180)), exit = fadeOut(tween(120))) {
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(ns.ink).tap { save() }.padding(horizontal = 20.dp, vertical = 10.dp)
                    ) { Text("Save", color = ns.onInk, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                }
            }

            Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                if (err.isNotEmpty()) Text(err, color = ns.bad, fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))

                Box(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), contentAlignment = Alignment.Center) {
                    Box(modifier = Modifier.tap { picker = true }) {
                        Avatar(d.avatar, 92.dp)
                        Box(
                            modifier = Modifier.align(Alignment.BottomEnd).size(30.dp).clip(CircleShape).background(ns.ink)
                                .border(BorderStroke(3.dp, ns.bg), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.Edit, "Change avatar", tint = ns.onInk, modifier = Modifier.size(14.dp)) }
                    }
                }

                FieldLabel("Name")
                NsField(d.name, { d = d.copy(name = it) }, "Your name")
                FieldLabel("Email")
                NsField(d.email, { d = d.copy(email = it) }, "you@example.com", keyboard = KeyboardType.Email)

                FieldLabel("Sex")
                Segmented(listOf("Male" to "Male", "Female" to "Female", "Other" to "Other"), d.sex, { d = d.copy(sex = it) })
                FieldLabel("Age")
                NsField(d.age, { v -> d = d.copy(age = v.filter { it.isDigit() }.take(3)) }, "Years", keyboard = KeyboardType.Number)

                FieldLabel("Height")
                Segmented(listOf("cm" to "cm", "ft" to "ft / in"), d.heightUnit, { d = d.copy(heightUnit = it) })
                Spacer(Modifier.height(8.dp))
                if (d.heightUnit == "cm") {
                    NumField(if (d.heightCm > 0) d.heightCm.toString() else "", "h-cm", "Height in cm", Modifier.fillMaxWidth()) { v ->
                        d = d.copy(heightCm = (v ?: 0.0).roundToInt())
                    }
                } else {
                    val totalIn = (d.heightCm / 2.54).roundToInt()
                    var ft by remember { mutableStateOf(if (d.heightCm > 0) (totalIn / 12).toString() else "") }
                    var inch by remember { mutableStateOf(if (d.heightCm > 0) (totalIn % 12).toString() else "") }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NsField(ft, { v ->
                            ft = v.filter { it.isDigit() }.take(1)
                            d = d.copy(heightCm = (((ft.toIntOrNull() ?: 0) * 12 + (inch.toIntOrNull() ?: 0)) * 2.54).roundToInt())
                        }, "ft", Modifier.weight(1f), KeyboardType.Number)
                        NsField(inch, { v ->
                            inch = v.filter { it.isDigit() }.take(2)
                            d = d.copy(heightCm = (((ft.toIntOrNull() ?: 0) * 12 + (inch.toIntOrNull() ?: 0)) * 2.54).roundToInt())
                        }, "in", Modifier.weight(1f), KeyboardType.Number)
                    }
                }

                FieldLabel("Weight")
                Segmented(listOf("kg" to "kg", "lb" to "lb"), d.weightUnit, { d = d.copy(weightUnit = it) })
                Spacer(Modifier.height(8.dp))
                val lb = d.weightUnit == "lb"
                fun show(kg: Double): String = if (kg <= 0) "" else {
                    val v = if (lb) kg * 2.20462 else kg
                    val r = Math.round(v * 10) / 10.0
                    if (r == Math.floor(r)) r.toInt().toString() else r.toString()
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumField(show(d.weightKg), "w-" + d.weightUnit, "Current (" + d.weightUnit + ")", Modifier.weight(1f)) { v ->
                        val x = v ?: 0.0
                        d = d.copy(weightKg = if (lb) x / 2.20462 else x)
                    }
                    NumField(show(d.targetKg), "t-" + d.weightUnit, "Target (" + d.weightUnit + ")", Modifier.weight(1f)) { v ->
                        val x = v ?: 0.0
                        d = d.copy(targetKg = if (lb) x / 2.20462 else x)
                    }
                }

                FieldLabel("Your goals")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    GOALS.forEach { g ->
                        Chip(g, d.goals.contains(g)) {
                            d = d.copy(goals = if (d.goals.contains(g)) d.goals - g else d.goals + g)
                        }
                    }
                }

                FieldLabel("Activity level")
                ACTIVITY.forEachIndexed { i, (t, s) -> ChoiceRow(t, s, d.activity == i) { d = d.copy(activity = i) } }

                FieldLabel("Eating style")
                DIETS.forEach { (t, s) -> ChoiceRow(t, s, d.diet == t) { d = d.copy(diet = t) } }

                FieldLabel("Allergens to flag")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ALLERGENS.keys.forEach { a ->
                        Chip(a.replaceFirstChar { it.uppercase() }, d.allergens.contains(a)) {
                            d = d.copy(allergens = if (d.allergens.contains(a)) d.allergens - a else d.allergens + a)
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }

        if (picker) {
            AvatarPicker(d.avatar, onPick = { d = d.copy(avatar = it) }, onClose = { picker = false })
        }
    }
}

@Composable
private fun AvatarPicker(selected: Int, onPick: (Int) -> Unit, onClose: () -> Unit) {
    var offset by remember { mutableStateOf(0f) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Box(modifier = Modifier.fillMaxSize().background(Color(0x73000000)).tap { onClose() }) {
        AnimatedVisibility(
            visible = shown, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(animationSpec = tween(320), initialOffsetY = { it })
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.84f).offset { IntOffset(0, offset.roundToInt()) }
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(ns.card).tap { }
            ) {
                // header: drag it down to dismiss
                Column(
                    modifier = Modifier.fillMaxWidth().pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { if (offset > 180f) onClose() else offset = 0f },
                            onDragCancel = { offset = 0f },
                            onVerticalDrag = { _, dy -> offset = (offset + dy).coerceAtLeast(0f) }
                        )
                    }.padding(top = 10.dp, bottom = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(modifier = Modifier.width(42.dp).height(5.dp).clip(RoundedCornerShape(5.dp)).background(ns.sub.copy(alpha = 0.45f)))
                    Spacer(Modifier.height(14.dp))
                    Text("Choose your avatar", color = ns.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
                    (0 until AVATAR_COUNT).chunked(4).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            row.forEach { i ->
                                Box(
                                    modifier = Modifier.weight(1f).aspectRatio(1f).clip(CircleShape)
                                        .then(if (i == selected) Modifier.border(BorderStroke(3.dp, ns.ink), CircleShape) else Modifier)
                                        .tap { onPick(i); onClose() },
                                    contentAlignment = Alignment.Center
                                ) { Avatar(i, 200.dp, Modifier.fillMaxSize().padding(if (i == selected) 4.dp else 0.dp)) }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}
