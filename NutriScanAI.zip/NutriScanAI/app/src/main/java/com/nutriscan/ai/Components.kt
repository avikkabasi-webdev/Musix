package com.nutriscan.ai

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val AVATAR_RES = intArrayOf(R.drawable.avatar_01, R.drawable.avatar_02, R.drawable.avatar_03, R.drawable.avatar_04, R.drawable.avatar_05, R.drawable.avatar_06, R.drawable.avatar_07, R.drawable.avatar_08, R.drawable.avatar_09, R.drawable.avatar_10, R.drawable.avatar_11, R.drawable.avatar_12, R.drawable.avatar_13, R.drawable.avatar_14, R.drawable.avatar_15, R.drawable.avatar_16, R.drawable.avatar_17, R.drawable.avatar_18, R.drawable.avatar_19, R.drawable.avatar_20, R.drawable.avatar_21, R.drawable.avatar_22, R.drawable.avatar_23, R.drawable.avatar_24, R.drawable.avatar_25, R.drawable.avatar_26, R.drawable.avatar_27, R.drawable.avatar_28, R.drawable.avatar_29, R.drawable.avatar_30)

@Composable
fun Avatar(index: Int, size: Dp, modifier: Modifier = Modifier) {
    val i = if (index < 0) 0 else if (index >= AVATAR_RES.size) AVATAR_RES.size - 1 else index
    Image(
        painter = painterResource(AVATAR_RES[i]),
        contentDescription = "Avatar",
        modifier = modifier.size(size).clip(CircleShape)
    )
}

fun Modifier.tap(onClick: () -> Unit): Modifier = this.clickable(
    interactionSource = MutableInteractionSource(), indication = null, onClick = onClick
)

@Composable
fun RoundIconButton(icon: ImageVector, desc: String, onClick: () -> Unit, size: Dp = 40.dp, bg: Color = ns.bubble, tint: Color = ns.ink) {
    Box(
        modifier = Modifier.size(size).clip(CircleShape).background(bg).tap(onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = desc, tint = tint, modifier = Modifier.size(size * 0.48f))
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, trailing: @Composable () -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            RoundIconButton(Icons.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.width(12.dp))
        }
        Text(title, color = ns.ink, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text, color = ns.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
fun Pill(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 11.dp, vertical = 5.dp)) {
        Text(text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier.clip(shape)
            .background(if (selected) ns.ink else ns.card)
            .border(BorderStroke(1.dp, if (selected) ns.ink else ns.line), shape)
            .tap(onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(label, color = if (selected) ns.onInk else ns.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ScoreRing(score: Int, size: Dp, stroke: Dp = 6.dp, fontSize: Int = 20) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(score) { anim.animateTo(score.coerceIn(0, 100) / 100f, tween(1000)) }
    val col = scoreColor(ns, score)
    val track = ns.bubble
    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val s = stroke.toPx()
            val inset = s / 2
            val sz = Size(this.size.width - s, this.size.height - s)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(s))
            drawArc(col, -90f, 360f * anim.value, false, Offset(inset, inset), sz, style = Stroke(s, cap = StrokeCap.Round))
        }
        Text(score.toString(), color = ns.ink, fontSize = fontSize.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RemoteImage(url: String, modifier: Modifier = Modifier, scale: ContentScale = ContentScale.Crop) {
    val bmp by produceState<android.graphics.Bitmap?>(initialValue = null, url) {
        value = if (url.isBlank()) null else withContext(Dispatchers.IO) { Img.loadUrl(url) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = scale)
    } else {
        Box(modifier = modifier.background(ns.bubble))
    }
}

@Composable
fun ScanImage(scan: Scan, store: Store, modifier: Modifier = Modifier, scale: ContentScale = ContentScale.Crop) {
    val photo by produceState<android.graphics.Bitmap?>(initialValue = null, scan.id, scan.hasPhoto) {
        value = if (scan.hasPhoto) withContext(Dispatchers.IO) { Img.decodeFile(store.photoFile(scan.id)) } else null
    }
    val p = photo
    if (p != null) {
        Image(bitmap = p.asImageBitmap(), contentDescription = scan.name, modifier = modifier, contentScale = scale)
    } else {
        RemoteImage(scan.imageUrl, modifier, scale)
    }
}

fun timeAgo(ts: Long): String {
    val s = (System.currentTimeMillis() - ts) / 1000
    if (s < 60) return "Just now"
    val m = s / 60
    if (m < 60) return m.toString() + "m ago"
    val h = m / 60
    if (h < 24) return h.toString() + "h ago"
    val d = h / 24
    if (d < 7) return d.toString() + "d ago"
    return java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault()).format(java.util.Date(ts))
}

@Composable
fun ScanRow(scan: Scan, store: Store, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp)).background(ns.card).border(BorderStroke(1.dp, ns.line), RoundedCornerShape(18.dp))
            .tap(onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ScanImage(scan, store, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(scan.name, color = ns.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(timeAgo(scan.timestamp) + if (scan.favorite) "  ♥" else "", color = ns.sub, fontSize = 13.sp)
        }
        Pill(scan.score.toString(), scoreBg(ns, scan.score), scoreColor(ns, scan.score))
    }
}

@Composable
fun BottomNav(selected: String, onHome: () -> Unit, onScan: () -> Unit, onProfile: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().background(ns.bg).navigationBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(68.dp).border(BorderStroke(0.5.dp, ns.line)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NavItem(Icons.Rounded.Home, "Home", selected == "home", onHome)
            Box(
                modifier = Modifier.size(56.dp).clip(CircleShape).background(ns.ink).tap(onScan),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.CameraAlt, "Scan", tint = ns.onInk, modifier = Modifier.size(26.dp)) }
            NavItem(Icons.Rounded.Person, "Profile", selected == "profile", onProfile)
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, on: Boolean, onClick: () -> Unit) {
    Column(modifier = Modifier.width(80.dp).tap(onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = if (on) ns.ink else ns.sub, modifier = Modifier.size(26.dp))
        Text(label, color = if (on) ns.ink else ns.sub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(20.dp)).background(ns.card)
            .border(BorderStroke(1.dp, ns.line), RoundedCornerShape(20.dp))
    ) { content() }
}
