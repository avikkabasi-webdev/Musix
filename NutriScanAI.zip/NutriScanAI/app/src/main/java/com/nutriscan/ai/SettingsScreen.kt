package com.nutriscan.ai

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

@Composable
private fun RowIcon(icon: ImageVector, danger: Boolean = false) {
    Box(
        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(if (danger) ns.badBg else ns.bubble),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (danger) ns.bad else ns.ink, modifier = Modifier.size(18.dp)) }
}

@Composable
private fun SettingCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(ns.card)
            .border(BorderStroke(1.dp, ns.line), RoundedCornerShape(20.dp)),
        content = content
    )
}

@Composable
private fun ToggleRow(icon: ImageVector, label: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().tap { onChange(!checked) }.padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = ns.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = ns.sub, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = ns.good, checkedThumbColor = Color.White, uncheckedTrackColor = ns.line, uncheckedThumbColor = Color.White, uncheckedBorderColor = ns.line)
        )
    }
}

@Composable
private fun ActionRow(icon: ImageVector, label: String, sub: String?, danger: Boolean = false, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().tap(onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon, danger)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = if (danger) ns.bad else ns.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = ns.sub, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.KeyboardArrowRight, null, tint = ns.sub, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun SegRow(icon: ImageVector, label: String, options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RowIcon(icon)
            Spacer(Modifier.width(12.dp))
            Text(label, color = ns.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(10.dp))
        Segmented(options, selected, onPick)
    }
}

@Composable
private fun Divider() {
    Box(modifier = Modifier.fillMaxWidth().padding(start = 60.dp).height(1.dp).background(ns.line))
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings
    var confirmClear by remember { mutableStateOf(false) }

    fun export() {
        try {
            val dir = File(ctx.cacheDir, "exports")
            dir.mkdirs()
            val f = File(dir, "nutriscan-data.json")
            f.writeText(vm.exportJson())
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(send, "Export my data"))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Couldn’t export your data. Try again.", Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar("Settings", { vm.pop() })
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SectionLabel("Scanning")
            SettingCard {
                ToggleRow(Icons.Rounded.QrCodeScanner, "Auto-scan barcodes", "Off: tap the shutter to look up", s.autoBarcode) { vm.updateSettings(s.copy(autoBarcode = it)) }
                Divider()
                SegRow(Icons.Rounded.CameraAlt, "Default scan mode", listOf("food" to "Food photo", "barcode" to "Barcode"), s.scanMode) { vm.updateSettings(s.copy(scanMode = it)) }
            }
            SectionLabel("Display")
            SettingCard {
                SegRow(Icons.Rounded.DarkMode, "Appearance", listOf("system" to "System", "light" to "Light", "dark" to "Dark"), s.theme) { vm.updateSettings(s.copy(theme = it)) }
                Divider()
                ToggleRow(Icons.Rounded.LocalFireDepartment, "Show calories on results", null, s.showKcal) { vm.updateSettings(s.copy(showKcal = it)) }
            }
            SectionLabel("Insights and alerts")
            SettingCard {
                ToggleRow(Icons.Rounded.CalendarMonth, "Weekly summary", "Show weekly chart on Profile", s.weeklySummary) { vm.updateSettings(s.copy(weeklySummary = it)) }
                Divider()
                ToggleRow(Icons.Rounded.Shield, "Allergen warnings", "Flag common allergens in results", s.allergenAlerts) { vm.updateSettings(s.copy(allergenAlerts = it)) }
            }
            SectionLabel("Data and privacy")
            SettingCard {
                ToggleRow(Icons.Rounded.History, "Save scan history", null, s.saveHistory) { vm.updateSettings(s.copy(saveHistory = it)) }
                Divider()
                ActionRow(Icons.Rounded.Download, "Export my data", null) { export() }
                Divider()
                ActionRow(Icons.Rounded.Delete, "Clear scan history", null, danger = true) { confirmClear = true }
            }
            SectionLabel("AI assistant")
            SettingCard {
                val n = Ai.keyPool(vm.store, "gemini").size + Ai.keyPool(vm.store, "groq").size
                ActionRow(Icons.Rounded.Key, "AI API keys", if (vm.geminiKeys.size + vm.groqKeys.size == 0) "Using the built-in key" else (vm.geminiKeys.size + vm.groqKeys.size).toString() + " of your keys added") { vm.push(Screen.Keys) }
                Divider()
                ToggleRow(Icons.Rounded.AutoAwesome, "AI follow-up suggestions", "Quick questions on results", s.aiSuggest) { vm.updateSettings(s.copy(aiSuggest = it)) }
                Divider()
                SegRow(Icons.Rounded.ChatBubble, "Answer detail", listOf("brief" to "Brief", "detailed" to "Detailed"), s.answerDetail) { vm.updateSettings(s.copy(answerDetail = it)) }
            }
            SectionLabel("About")
            SettingCard {
                ActionRow(Icons.Rounded.HelpOutline, "Help and feedback", null) { Toast.makeText(ctx, "Help and feedback is coming soon", Toast.LENGTH_SHORT).show() }
                Divider()
                ActionRow(Icons.Rounded.Info, "About NutriScan", "Version 2.0") { Toast.makeText(ctx, "NutriScan AI v2.0", Toast.LENGTH_SHORT).show() }
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            confirmButton = { TextButton(onClick = { confirmClear = false; vm.clearHistory() }) { Text("Clear", color = ns.bad) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
            title = { Text("Clear all saved scans?") },
            text = { Text("This can’t be undone.") }
        )
    }
}

private fun mask(k: String): String = if (k.length <= 10) k.take(2) + "••••••" else k.take(4) + "••••••••" + k.takeLast(4)

@Composable
private fun KeyCard(title: String, hint: String, provider: String, keys: List<String>, vm: AppViewModel) {
    var text by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(ns.card)
            .border(BorderStroke(1.dp, ns.line), RoundedCornerShape(20.dp)).padding(16.dp)
    ) {
        Text(title, color = ns.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(hint, color = ns.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
        keys.forEach { k ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(mask(k), color = ns.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("Remove", color = ns.bad, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.tap { vm.removeKey(provider, k) })
            }
        }
        Row(modifier = Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(ns.bubble).padding(horizontal = 12.dp, vertical = 12.dp)) {
                if (text.isEmpty()) Text("Paste a key", color = ns.sub, fontSize = 14.sp)
                BasicTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    textStyle = TextStyle(color = ns.ink, fontSize = 14.sp), cursorBrush = SolidColor(ns.ink), modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier.clip(RoundedCornerShape(50)).background(ns.ink)
                    .tap { text.split(Regex("[\\s,;]+")).filter { it.isNotBlank() }.forEach { vm.addKey(provider, it) }; text = "" }
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            ) { Text("Add", color = ns.onInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun KeysScreen(vm: AppViewModel) {
    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar("AI API keys", { vm.pop() })
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text(
                "Add your own free keys so scans keep working if the built-in one is busy. Keys are stored only on this phone.",
                color = ns.sub, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(8.dp))
            KeyCard("Google Gemini", "Free key from aistudio.google.com", "gemini", vm.geminiKeys, vm)
            KeyCard("Groq", "Free key from console.groq.com", "groq", vm.groqKeys, vm)
            Spacer(Modifier.height(28.dp))
        }
    }
}
