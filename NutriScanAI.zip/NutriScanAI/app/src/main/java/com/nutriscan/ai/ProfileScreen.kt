package com.nutriscan.ai

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

fun scoreBand(score: Int): String = if (score >= 90) "healthy" else if (score >= 60) "good" else if (score >= 40) "average" else "bad"

private fun weekBuckets(range: String, scans: List<Scan>): List<Pair<String, Int>> {
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
    val dow = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday = 0
    cal.add(Calendar.DAY_OF_YEAR, -dow)
    val thisMonday = cal.timeInMillis
    val day = 86_400_000L
    fun count(from: Long, to: Long) = scans.count { it.timestamp >= from && it.timestamp < to }
    return when (range) {
        "month" -> (0 until 4).map { i ->
            val start = thisMonday - (3 - i) * 7 * day
            (if (i == 3) "This wk" else if (i == 2) "Last wk" else (3 - i).toString() + "w ago") to count(start, start + 7 * day)
        }
        else -> {
            val start = if (range == "last") thisMonday - 7 * day else thisMonday
            listOf("M", "T", "W", "T", "F", "S", "S").mapIndexed { i, l -> l to count(start + i * day, start + (i + 1) * day) }
        }
    }
}

@Composable
private fun InsightRing(count: Int, total: Int, color: Color, label: String, pill: String, on: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (on) ns.bubble else Color.Transparent).tap(onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val track = ns.bubble
        Box(modifier = Modifier.size(62.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val sw = 6.dp.toPx()
                val sz = Size(this.size.width - sw, this.size.height - sw)
                drawArc(track, 0f, 360f, false, Offset(sw / 2, sw / 2), sz, style = Stroke(sw))
                if (total > 0 && count > 0) {
                    drawArc(color, -90f, 360f * count / total, false, Offset(sw / 2, sw / 2), sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
            }
            Text(count.toString(), color = ns.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = ns.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(pill, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ProfileScreen(vm: AppViewModel) {
    var filter by remember { mutableStateOf("all") }
    var range by remember { mutableStateOf("week") }
    var rangeMenu by remember { mutableStateOf(false) }
    val bands = remember(vm.scans) { vm.scans.groupingBy { scoreBand(it.score) }.eachCount() }
    val total = vm.scans.size
    val shown = vm.scans.filter { filter == "all" || scoreBand(it.score) == filter }
    val p = vm.profile

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            item {
                TopBar("Profile", null) { RoundIconButton(Icons.Rounded.Settings, "Settings", { vm.push(Screen.Settings) }) }
            }
            item {
                Card(modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p.avatar, 60.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (p.name.isBlank()) "Your name" else p.name, color = ns.ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            if (p.email.isNotBlank()) Text(p.email, color = ns.sub, fontSize = 13.sp)
                        }
                        Box(
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(ns.ink).tap { vm.push(Screen.EditProfile) }
                                .padding(horizontal = 18.dp, vertical = 9.dp)
                        ) { Text("Edit", color = ns.onInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
            item {
                SectionLabel("Insights")
                Card(modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            InsightRing(bands["bad"] ?: 0, total, ns.bad, "Bad", "Bad", filter == "bad") { filter = if (filter == "bad") "all" else "bad" }
                            InsightRing(bands["average"] ?: 0, total, ns.mod, "Average", "Average", filter == "average") { filter = if (filter == "average") "all" else "average" }
                            InsightRing(bands["good"] ?: 0, total, ns.good, "Good", "Good", filter == "good") { filter = if (filter == "good") "all" else "good" }
                            InsightRing(bands["healthy"] ?: 0, total, ns.healthy, "Healthy", "90-100", filter == "healthy") { filter = if (filter == "healthy") "all" else "healthy" }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (filter == "all") "Tap a ring to filter" else "Showing $filter only",
                            color = ns.sub, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
            if (vm.settings.weeklySummary) {
                item {
                    val buckets = weekBuckets(range, vm.scans)
                    val maxV = (buckets.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 22.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Weekly summary", color = ns.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Box {
                            val label = when (range) { "last" -> "Last Week"; "month" -> "Last 4 Weeks"; else -> "This Week" }
                            Text(label + " ▾", color = ns.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.tap { rangeMenu = true })
                            DropdownMenu(expanded = rangeMenu, onDismissRequest = { rangeMenu = false }) {
                                listOf("week" to "This Week", "last" to "Last Week", "month" to "Last 4 Weeks").forEach { (k, l) ->
                                    DropdownMenuItem(text = { Text(l) }, onClick = { range = k; rangeMenu = false })
                                }
                            }
                        }
                    }
                    Card(modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp).height(120.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom
                        ) {
                            buckets.forEach { (l, v) ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.fillMaxHeight()) {
                                    Text(if (v > 0) v.toString() else "", color = ns.sub, fontSize = 11.sp)
                                    Box(
                                        modifier = Modifier.width(22.dp).height((10 + 62 * v / maxV).dp)
                                            .clip(RoundedCornerShape(8.dp)).background(if (v > 0) ns.ink else ns.bubble)
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(l, color = ns.sub, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
            item { SectionLabel(if (filter == "all") "Your scans" else "Your scans · $filter") }
            if (shown.isEmpty()) {
                item { Text("No scans here yet.", color = ns.sub, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) }
            }
            items(shown.take(50), key = { it.id }) { s -> ScanRow(s, vm.store) { vm.openStored(s) } }
            item { Spacer(Modifier.height(12.dp)) }
        }
        BottomNav("profile", { vm.goHome() }, { vm.openScan() }, {})
    }
}

private fun dayLabel(ts: Long): String {
    val now = Calendar.getInstance()
    val c = Calendar.getInstance(); c.timeInMillis = ts
    fun sameDay(a: Calendar, b: Calendar) = a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (sameDay(now, c)) return "Today"
    now.add(Calendar.DAY_OF_YEAR, -1)
    if (sameDay(now, c)) return "Yesterday"
    return java.text.SimpleDateFormat("EEEE, MMM d", java.util.Locale.getDefault()).format(java.util.Date(ts))
}

@Composable
fun HistoryScreen(vm: AppViewModel) {
    var confirm by remember { mutableStateOf(false) }
    val list = vm.scans.filter { !vm.favoritesOnly || it.favorite }
    val groups = list.groupBy { dayLabel(it.timestamp) }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar("History", { vm.pop() }) {
            Chip("♥ Favorites", vm.favoritesOnly) { vm.favoritesOnly = !vm.favoritesOnly }
        }
        LazyColumn(modifier = Modifier.weight(1f)) {
            if (list.isEmpty()) {
                item { Text("Nothing here yet.", color = ns.sub, fontSize = 15.sp, modifier = Modifier.padding(24.dp)) }
            }
            groups.forEach { (label, scans) ->
                item(key = "h_$label") { SectionLabel(label) }
                items(scans, key = { it.id }) { s -> ScanRow(s, vm.store) { vm.openStored(s) } }
            }
            if (vm.scans.isNotEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("Clear history", color = ns.bad, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.tap { confirm = true })
                    }
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            confirmButton = { TextButton(onClick = { confirm = false; vm.clearHistory() }) { Text("Clear", color = ns.bad) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            title = { Text("Clear all saved scans?") },
            text = { Text("This can’t be undone.") }
        )
    }
}
