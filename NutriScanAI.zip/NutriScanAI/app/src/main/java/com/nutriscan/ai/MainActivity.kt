package com.nutriscan.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val dark = when (vm.settings.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    NutriTheme(dark) {
        val atRoot = vm.stack.size == 1 && vm.top is Screen.Home
        BackHandler(enabled = !atRoot || vm.loadingText != null) {
            val t = vm.top
            if (vm.loadingText != null) vm.cancelLoading()
            else if (t is Screen.Analyzing) vm.cancelAnalysis()
            else if (t is Screen.Profile) vm.goHome()
            else vm.pop()
        }
        Box(modifier = Modifier.fillMaxSize().background(ns.bg)) {
            val t = vm.top
            when (t) {
                is Screen.Home -> HomeScreen(vm)
                is Screen.Scan -> ScanScreen(vm)
                is Screen.Analyzing -> AnalyzingScreen(vm)
                is Screen.NoFood -> NoFoodScreen(vm, t.barcode)
                is Screen.Result -> ResultScreen(vm)
                is Screen.Profile -> ProfileScreen(vm)
                is Screen.EditProfile -> EditProfileScreen(vm)
                is Screen.History -> HistoryScreen(vm)
                is Screen.Settings -> SettingsScreen(vm)
                is Screen.Keys -> KeysScreen(vm)
            }
            val loading = vm.loadingText
            if (loading != null) {
                Box(
                    modifier = Modifier.fillMaxSize().background(Color(0xAA000000)).tap { },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(Modifier.height(14.dp))
                        Text(loading, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            val a = vm.alert
            if (a != null) {
                AlertDialog(
                    onDismissRequest = { vm.alert = null },
                    confirmButton = { TextButton(onClick = { vm.alert = null }) { Text("OK") } },
                    title = { Text(a.first) },
                    text = { Text(a.second) }
                )
            }
        }
    }
}
