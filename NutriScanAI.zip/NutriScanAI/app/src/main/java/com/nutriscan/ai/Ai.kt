package com.nutriscan.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

class AiError(val status: Int, message: String, val retryAfter: Double? = null) : Exception(message)

class AiRequest(
    val prompt: String,
    val system: String? = null,
    val imageB64: String? = null,
    val json: Boolean = false,
    val temperature: Double = 0.3,
    val maxTokens: Int = 1200
)

sealed class Analysis {
    object NoFood : Analysis()
    class Ok(val scan: Scan) : Analysis()
}

object Ai {
    private val GEMINI_MODELS = listOf("gemini-3.5-flash-lite", "gemini-2.5-flash-lite")
    private const val GROQ_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"

    fun keyPool(store: Store, provider: String): List<String> {
        val all = store.loadKeys(provider).toMutableList()
        if (provider == "groq" && BuiltInKeys.GROQ.isNotBlank()) all.add(BuiltInKeys.GROQ)
        if (provider == "gemini" && BuiltInKeys.GEMINI.isNotBlank()) all.add(BuiltInKeys.GEMINI)
        return all.distinct()
    }

    fun hasAnyKey(store: Store): Boolean = keyPool(store, "gemini").isNotEmpty() || keyPool(store, "groq").isNotEmpty()

    // ------------------------------------------------------------- HTTP

    private class HttpResult(val code: Int, val body: String, val retryAfter: Double?)

    private fun request(method: String, url: String, headers: Map<String, String>, body: String?, readTimeoutMs: Int): HttpResult {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = readTimeoutMs
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val ra = c.getHeaderField("retry-after")?.toDoubleOrNull()
            return HttpResult(code, text, ra)
        } finally {
            c.disconnect()
        }
    }

    private fun parseObject(s: String): JSONObject = try { JSONObject(s) } catch (e: Exception) { JSONObject() }

    private fun errMessage(data: JSONObject, code: Int): String {
        val m = data.optJSONObject("error")?.optString("message").orEmpty()
        return if (m.isNotBlank()) m else "HTTP $code"
    }

    // ------------------------------------------------------------- providers

    private fun callGemini(model: String, key: String, r: AiRequest): String {
        val parts = JSONArray().put(JSONObject().put("text", r.prompt))
        if (r.imageB64 != null) {
            parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", r.imageB64)))
        }
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
        val gen = JSONObject().put("temperature", r.temperature).put("maxOutputTokens", r.maxTokens)
        if (r.json) gen.put("responseMimeType", "application/json")
        val body = JSONObject().put("contents", contents).put("generationConfig", gen)
        if (r.system != null) {
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", r.system))))
        }
        val res = try {
            request(
                "POST", "https://generativelanguage.googleapis.com/v1beta/models/" + URLEncoder.encode(model, "UTF-8") + ":generateContent",
                mapOf("Content-Type" to "application/json", "x-goog-api-key" to key), body.toString(), 45000
            )
        } catch (e: IOException) {
            throw AiError(0, "Network error reaching Gemini")
        }
        val data = parseObject(res.body)
        if (res.code !in 200..299) throw AiError(res.code, errMessage(data, res.code), res.retryAfter)
        val partsOut = data.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (partsOut != null) {
            for (i in 0 until partsOut.length()) sb.append(partsOut.optJSONObject(i)?.optString("text").orEmpty())
        }
        val text = sb.toString().trim()
        if (text.isEmpty()) throw AiError(502, "Gemini returned an empty response")
        return text
    }

    private fun callGroq(key: String, r: AiRequest): String {
        val messages = JSONArray()
        if (r.system != null) messages.put(JSONObject().put("role", "system").put("content", r.system))
        val userContent: Any = if (r.imageB64 != null) {
            JSONArray()
                .put(JSONObject().put("type", "text").put("text", r.prompt))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64," + r.imageB64)))
        } else r.prompt
        messages.put(JSONObject().put("role", "user").put("content", userContent))
        val body = JSONObject().put("model", GROQ_MODEL).put("messages", messages)
            .put("temperature", r.temperature).put("max_completion_tokens", r.maxTokens)
        val res = try {
            request(
                "POST", "https://api.groq.com/openai/v1/chat/completions",
                mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"), body.toString(), 45000
            )
        } catch (e: IOException) {
            throw AiError(0, "Network error reaching Groq")
        }
        val data = parseObject(res.body)
        if (res.code !in 200..299) throw AiError(res.code, errMessage(data, res.code), res.retryAfter)
        val text = data.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty().trim()
        if (text.isEmpty()) throw AiError(502, "Groq returned an empty response")
        return text
    }

    /** Tries every key / provider in turn; a bad or rate-limited key falls through to the next one. */
    suspend fun generate(store: Store, r: AiRequest): String = withContext(Dispatchers.IO) {
        val attempts = keyPool(store, "gemini").map { "gemini" to it } + keyPool(store, "groq").map { "groq" to it }
        if (attempts.isEmpty()) throw Exception("No API key set. Open Settings and add a Gemini or Groq key.")
        var lastErr: AiError? = null
        for (pass in 0 until 2) {
            var allRateLimited = true
            var wait = 0.0
            for ((provider, key) in attempts) {
                try {
                    if (provider == "groq") return@withContext callGroq(key, r)
                    var modelErr: AiError? = null
                    for (model in GEMINI_MODELS) {
                        try {
                            return@withContext callGemini(model, key, r)
                        } catch (e: AiError) {
                            modelErr = e
                            if (e.status != 404) throw e
                        }
                    }
                    throw modelErr ?: AiError(404, "Model unavailable")
                } catch (e: AiError) {
                    lastErr = e
                    if (e.status != 429) allRateLimited = false else wait = maxOf(wait, e.retryAfter ?: 2.0)
                }
            }
            if (pass == 0 && allRateLimited && lastErr != null) delay((minOf(wait, 6.0) * 1000).toLong()) else break
        }
        val st = lastErr?.status
        var msg = lastErr?.message ?: "Unknown error"
        if (st == 401 || st == 403) msg = "Your API keys were rejected. Open Settings and re-check them."
        else if (st == 429) msg = "AI rate limit reached on all keys. Add another free Gemini or Groq key in Settings, or wait a minute and try again."
        else if (st == 404) msg = "The AI model this app uses is no longer available."
        throw Exception(msg)
    }

    private fun extractJson(text: String): JSONObject {
        var t = text.trim().removePrefix("```json").removePrefix("```JSON").removePrefix("```").removeSuffix("```").trim()
        val start = t.indexOf('{')
        val end = t.lastIndexOf('}')
        if (start == -1 || end == -1 || end <= start) throw Exception("No JSON object found in the response.")
        t = t.substring(start, end + 1)
        return JSONObject(t)
    }

    // ------------------------------------------------------------- food photo

    private val FOOD_PROMPT = """You are a nutrition analysis assistant embedded in a food-scanning app. Look closely at this photo. If it does NOT clearly show food or a drink (for example a wall, a person, a pet, a screen, or an unrelated object), respond with ONLY this JSON: {"food":false}. Otherwise identify the dish or item and respond with ONLY valid JSON — no markdown fences, no commentary, no text before or after — matching exactly this schema:
{"name":"short dish name","score":number from 0 to 100 representing overall healthiness,"verdict":"exactly one of 'Great Choice', 'Good Choice', 'Moderate Choice', 'Bad Choice', 'Very Bad Choice' (pick the one matching the score band: 80+ Great, 60-79 Good, 40-59 Moderate, 20-39 Bad, under 20 Very Bad)","summary":"one short 3-6 word phrase explaining the verdict, e.g. 'High Sugar Choice' or 'Okay Choice, Eat in Moderation'","factors":[{"label":"short nutrient name","detail":"ONLY a short quantity with unit per 100g/100ml, e.g. '24 g', '60 kcal', '310 mg' — never a descriptive sentence","rating":"Good, Moderate, Bad, or Extreme"}],"carbs":number grams of carbohydrates per 100g,"fats":number grams of total fat per 100g,"good":["short positive point", "..."],"bad":["short negative point", "..."]}
Include exactly 5 factors, always using this exact label set and order so foods can be compared side by side: "Sugar", "Calories", "Protein", "Fiber", "Sodium". Include 2 to 3 "good" points and 2 to 3 "bad" points. Keep every string short. Be realistic and specific to the dish shown, not generic."""

    private fun numOrNull(o: JSONObject, key: String): Double? {
        if (!o.has(key) || o.isNull(key)) return null
        return o.opt(key).toString().toDoubleOrNull()
    }

    suspend fun analyzeFood(store: Store, jpegB64: String): Analysis {
        val first = generate(store, AiRequest(prompt = FOOD_PROMPT, imageB64 = jpegB64, json = true, temperature = 0.3, maxTokens = 1400))
        val parsed: JSONObject = try {
            extractJson(first)
        } catch (e: Exception) {
            val again = generate(
                store,
                AiRequest(
                    prompt = FOOD_PROMPT + "\n\nIMPORTANT: reply with ONLY one complete, valid raw JSON object. No markdown fences, nothing else.",
                    imageB64 = jpegB64, json = true, temperature = 0.2, maxTokens = 1800
                )
            )
            extractJson(again)
        }
        if (parsed.has("food") && !parsed.optBoolean("food", true)) return Analysis.NoFood
        val fa = parsed.optJSONArray("factors")
        if (parsed.optString("name").isBlank() || fa == null) throw Exception("The AI reply was incomplete. Please try again.")
        val factors = (0 until fa.length()).map {
            val f = fa.getJSONObject(it)
            Factor(f.optString("label"), f.optString("detail"), f.optString("rating"))
        }
        val score = (numOrNull(parsed, "score") ?: 0.0).roundToInt().coerceIn(0, 100)
        val scan = Scan(
            id = "", name = parsed.optString("name"), score = score, verdict = parsed.optString("verdict"),
            summary = parsed.optString("summary"), factors = factors,
            carbs = numOrNull(parsed, "carbs"), fats = numOrNull(parsed, "fats"),
            good = parsed.optJSONArray("good").strings(), bad = parsed.optJSONArray("bad").strings(),
            timestamp = System.currentTimeMillis(), hasPhoto = true
        )
        return Analysis.Ok(scan)
    }

    // ------------------------------------------------------------- chat

    private fun limitWords(text: String, max: Int): String {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return if (words.size <= max) text.trim() else words.take(max).joinToString(" ") + "…"
    }

    suspend fun ask(store: Store, scan: Scan, question: String, detailed: Boolean): String {
        val facts = scan.factors.joinToString(", ") { it.label + ": " + it.detail + " (" + it.rating + ")" }
        val ctx = "Food: " + scan.name + ". Score: " + scan.score + "/100 (" + scan.verdict + "). Summary: " + scan.summary +
            ". Nutrition factors: " + facts + ". Carbs: " + (scan.carbs?.toString() ?: "n/a") + " g, Fats: " + (scan.fats?.toString() ?: "n/a") + " g."
        val words = if (detailed) 60 else 20
        val system = "You are a nutrition assistant inside a food-scanning app. Reply in under " + words + " words, always. Be direct and specific — no filler, no preamble."
        val raw = generate(
            store,
            AiRequest(prompt = ctx + "\n\nUser question: " + question, system = system, temperature = 0.4, maxTokens = if (detailed) 150 else 60)
        )
        return limitWords(raw, words)
    }

    // ------------------------------------------------------------- Open Food Facts

    suspend fun fetchOffProduct(code: String): JSONObject? = withContext(Dispatchers.IO) {
        for (base in listOf("https://world.openfoodfacts.org", "https://in.openfoodfacts.org")) {
            try {
                val res = request(
                    "GET", base + "/api/v2/product/" + URLEncoder.encode(code, "UTF-8") + ".json",
                    mapOf("User-Agent" to "NutriScanAI/2.0 (Android)"), null, 20000
                )
                val d = JSONObject(res.body)
                val p = d.optJSONObject("product")
                if (d.optInt("status") == 1 && p != null) return@withContext p
            } catch (e: Exception) { /* try the next mirror */ }
        }
        null
    }

    private fun num(n: JSONObject, key: String, def: Double): Double = numOrNull(n, key) ?: def
    private fun rate3(v: Double, goodMax: Double, modMax: Double) = if (v <= goodMax) "Good" else if (v <= modMax) "Moderate" else "Bad"
    private fun rate3Inv(v: Double, goodMin: Double, modMin: Double) = if (v >= goodMin) "Good" else if (v >= modMin) "Moderate" else "Bad"
    private fun rScore(r: String) = if (r == "Good") 1.0 else if (r == "Moderate") 0.5 else 0.0

    fun buildFromProduct(p: JSONObject): Scan {
        val n = p.optJSONObject("nutriments") ?: JSONObject()
        val sugar = num(n, "sugars_100g", 0.0)
        val satfat = num(n, "saturated-fat_100g", 0.0)
        val sod = num(n, "sodium_100g", 0.0)
        val saltG = num(n, "salt_100g", if (sod != 0.0) sod * 2.5 else 0.0)
        val sodiumMg = saltG * 400
        val fiber = num(n, "fiber_100g", 0.0)
        val protein = num(n, "proteins_100g", 0.0)
        val energy = num(n, "energy_100g", 0.0)
        val calories = num(n, "energy-kcal_100g", if (energy != 0.0) energy / 4.184 else 0.0)

        val sugarR = rate3(sugar, 5.0, 22.5)
        val sugarBadge = if (sugar > 30) "Extreme" else sugarR
        val satfatR = rate3(satfat, 1.5, 5.0)
        val satfatBadge = if (satfat > 10) "Extreme" else satfatR
        val sodiumR = rate3(sodiumMg, 120.0, 600.0)
        val sodiumBadge = if (sodiumMg > 900) "Extreme" else sodiumR
        val fiberR = rate3Inv(fiber, 3.0, 1.0)
        val proteinR = rate3Inv(protein, 5.0, 2.0)
        val caloriesR = rate3(calories, 100.0, 250.0)
        val carbs = num(n, "carbohydrates_100g", 0.0)
        val fats = num(n, "fat_100g", 0.0)

        val weighted = 0.25 * rScore(sugarR) + 0.25 * rScore(satfatR) + 0.25 * rScore(sodiumR) + 0.125 * rScore(fiberR) + 0.125 * rScore(proteinR)
        val score = (weighted * 100).roundToInt()

        val factors = listOf(
            Factor("Sugar", sugar.roundToInt().toString() + " g", sugarBadge),
            Factor("Calories", calories.roundToInt().toString() + " kcal", caloriesR),
            Factor("Protein", protein.roundToInt().toString() + " g", proteinR),
            Factor("Fiber", fiber.roundToInt().toString() + " g", fiberR),
            Factor("Sodium", sodiumMg.roundToInt().toString() + " mg", sodiumBadge)
        )

        val good = mutableListOf<String>()
        val bad = mutableListOf<String>()
        if (fiberR == "Good") good.add("Good source of dietary fiber")
        if (proteinR == "Good") good.add("Good source of protein")
        if (sugarR == "Good") good.add("Low in sugar")
        if (satfatR == "Good") good.add("Low in saturated fat")
        if (num(n, "trans-fat_100g", 0.0) == 0.0) good.add("No trans fat")
        if (sugarBadge == "Bad" || sugarBadge == "Extreme") bad.add("High in sugar")
        if (satfatBadge == "Bad" || satfatBadge == "Extreme") bad.add("High in saturated fat")
        if (sodiumBadge == "Bad" || sodiumBadge == "Extreme") bad.add("High in sodium")
        if (fiberR == "Bad") bad.add("Low in fiber")
        if (proteinR == "Bad") bad.add("Low in protein")
        if (good.isEmpty()) good.add("No standout positives found in this product nutrient profile")
        if (bad.isEmpty()) bad.add("No major concerns found in this product nutrient profile")

        val verdict: String
        val summary: String
        if (score >= 80) { verdict = "Great Choice"; summary = "A well-balanced product with a healthy nutrient profile." }
        else if (score >= 60) { verdict = "Good Choice"; summary = "A generally healthy option with minor trade-offs." }
        else if (score >= 40) { verdict = "Moderate Choice"; summary = "Fine in moderation, but has some nutrients to watch." }
        else if (score >= 20) { verdict = "Bad Choice"; summary = "High in one or more nutrients linked to health risks." }
        else { verdict = "Very Bad Choice"; summary = "Poor nutrient profile — best enjoyed rarely, if at all." }

        val name = p.optString("product_name").ifBlank { p.optString("generic_name") }.ifBlank { "Unknown product" }
        return Scan(
            id = "", name = name, score = score, verdict = verdict, summary = summary, factors = factors,
            carbs = carbs, fats = fats, good = good, bad = bad, timestamp = System.currentTimeMillis(),
            imageUrl = officialImage(p)
        )
    }

    private fun officialImage(p: JSONObject): String {
        val front = p.optString("image_front_url")
        if (front.isNotBlank()) return front
        val sel = p.optJSONObject("selected_images")?.optJSONObject("front")?.optJSONObject("display")
        if (sel != null) {
            val en = sel.optString("en")
            if (en.isNotBlank()) return en
            val keys = sel.keys()
            if (keys.hasNext()) {
                val v = sel.optString(keys.next())
                if (v.isNotBlank()) return v
            }
        }
        return p.optString("image_front_small_url").ifBlank { p.optString("image_url") }
    }
}

/** Nutrition values for the grid on the result screen. */
class Nutrient(val key: String, val label: String, val num: Double?, val unit: String, val rating: String?, val pct: Float)

fun nutrientsOf(s: Scan): List<Nutrient> {
    fun f(label: String) = s.factors.firstOrNull { it.label.equals(label, ignoreCase = true) }
    fun fnum(label: String): Double? = f(label)?.detail?.let { d -> Regex("-?\\d+(\\.\\d+)?").find(d)?.value?.toDoubleOrNull() }
    fun cl(v: Double?, max: Double): Float = if (v == null) 0f else (v / max).coerceIn(0.06, 1.0).toFloat()
    fun r3(v: Double, g: Double, m: Double) = if (v <= g) "Good" else if (v <= m) "Moderate" else "Bad"
    val sugar = fnum("sugar"); val protein = fnum("protein"); val fiber = fnum("fiber"); val sodium = fnum("sodium"); val cal = fnum("calories")
    return listOf(
        Nutrient("calories", "Calories", cal, "kcal", f("calories")?.rating, 0f),
        Nutrient("sugar", "Sugar", sugar, "g", f("sugar")?.rating, cl(sugar, 32.0)),
        Nutrient("protein", "Protein", protein, "g", f("protein")?.rating, cl(protein, 20.0)),
        Nutrient("fiber", "Fiber", fiber, "g", f("fiber")?.rating, cl(fiber, 12.0)),
        Nutrient("carbs", "Carbs", s.carbs, "g", s.carbs?.let { r3(it, 30.0, 55.0) }, cl(s.carbs, 80.0)),
        Nutrient("fats", "Fats", s.fats, "g", s.fats?.let { r3(it, 10.0, 20.0) }, cl(s.fats, 40.0)),
        Nutrient("sodium", "Sodium", sodium, "mg", f("sodium")?.rating, cl(sodium, 900.0))
    )
}
