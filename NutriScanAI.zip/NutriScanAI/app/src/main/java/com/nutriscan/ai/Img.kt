package com.nutriscan.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

object Img {
    private val cache = LruCache<String, Bitmap>(24)

    fun scaleRotate(src: Bitmap, degrees: Int, maxDim: Int): Bitmap {
        val m = Matrix()
        if (degrees != 0) m.postRotate(degrees.toFloat())
        val scale = min(1f, maxDim.toFloat() / max(src.width, src.height).toFloat())
        if (scale < 1f) m.postScale(scale, scale)
        if (degrees == 0 && scale >= 1f) return src
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    fun fromUri(ctx: Context, uri: Uri, maxDim: Int = 1280): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val orientation = ctx.contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
            scaleRotate(bmp, degrees, maxDim)
        } catch (e: Exception) {
            null
        }
    }

    fun toJpeg(bmp: Bitmap, quality: Int = 80): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return out.toByteArray()
    }

    fun toBase64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    fun decodeFile(f: File): Bitmap? {
        if (!f.exists()) return null
        val key = f.absolutePath + f.lastModified()
        cache.get(key)?.let { return it }
        return try {
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            if (bmp != null) cache.put(key, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    fun loadUrl(url: String): Bitmap? {
        cache.get(url)?.let { return it }
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", "NutriScanAI/2.0 (Android)")
            val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
            c.disconnect()
            if (bmp != null) cache.put(url, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }
}
