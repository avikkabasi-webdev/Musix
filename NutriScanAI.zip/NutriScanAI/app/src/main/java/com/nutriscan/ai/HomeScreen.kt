package com.nutriscan.ai

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

fun cameraGranted(ctx: android.content.Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

/** The four rounded corner marks drawn over the camera. */
@Composable
fun ScanCorners(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val len = 34.dp.toPx()
        val r = 14.dp.toPx()
        val sw = 4.dp.toPx()
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            val p = Path()
            p.moveTo(x, y + dy * len)
            p.lineTo(x, y + dy * r)
            p.quadraticBezierTo(x, y, x + dx * r, y)
            p.lineTo(x + dx * len, y)
            drawPath(p, color, style = Stroke(sw, cap = StrokeCap.Round))
        }
        corner(0f, 0f, 1f, 1f)
        corner(w, 0f, -1f, 1f)
        corner(0f, h, 1f, -1f)
        corner(w, h, -1f, -1f)
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var hasCam by remember { mutableStateOf(cameraGranted(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
    val list = vm.scans.filter { !vm.favoritesOnly || it.favorite }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1f)) {
                        Text("NutriScan ", color = ns.ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("AI", color = ns.sub, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    }
                    RoundIconButton(Icons.Rounded.Settings, "Settings", { vm.push(Screen.Settings) })
                }
            }
            item {
                Box(
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(300.dp)
                        .clip(RoundedCornerShape(28.dp)).background(Color(0xFF111111)),
                    contentAlignment = Alignment.Center
                ) {
                    if (hasCam) {
                        val controller = rememberCamera()
                        CameraSurface(controller, Modifier.fillMaxSize())
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.CameraAlt, "Camera", tint = Color.White, modifier = Modifier.width(40.dp).height(40.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("Tap to allow the camera", color = Color.White, fontSize = 15.sp)
                        }
                    }
                    ScanCorners(Modifier.fillMaxSize().padding(22.dp))
                    Box(
                        modifier = Modifier.fillMaxSize()
                            .tap { if (hasCam) vm.openScan() else launcher.launch(Manifest.permission.CAMERA) }
                    )
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Scans", color = ns.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    if (vm.scans.any { it.favorite }) {
                        Chip("♥ Favorites", vm.favoritesOnly) { vm.favoritesOnly = !vm.favoritesOnly }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("See all ›", color = ns.sub, fontSize = 14.sp, modifier = Modifier.tap { vm.push(Screen.History) })
                }
            }
            if (list.isEmpty()) {
                item {
                    Text(
                        if (vm.favoritesOnly) "No favorites yet." else "Nothing scanned yet. Point the camera at a meal or a barcode.",
                        color = ns.sub, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
                    )
                }
            }
            items(list.take(30), key = { it.id }) { s -> ScanRow(s, vm.store) { vm.openStored(s) } }
            item { Spacer(Modifier.height(12.dp)) }
        }
        BottomNav("home", {}, { vm.openScan() }, { vm.goProfile() })
    }
}
