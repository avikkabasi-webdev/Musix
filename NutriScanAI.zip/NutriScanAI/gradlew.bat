@echo off
rem Windows users: open this folder in Android Studio (it downloads Gradle 8.7 itself),
rem or install Gradle 8.7 and run:  gradle assembleDebug
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (gradle %*) else (echo Install Gradle 8.7 or open the project in Android Studio. & exit /b 1)
