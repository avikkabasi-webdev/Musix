package com.dotsgo.app.data.scrape

import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLEncoder

class Store(val key: String, val fetch: (String) -> List<Item>)

/** One reader per shopping site. Each returns real products or throws [StoreException]. */
object Stores {

    val all: List<Store> = listOf(
        Store("amazon") { q -> amazon(q) },
        Store("flipkart") { q -> flipkart(q) },
        Store("snapdeal") { q -> snapdeal(q) },
        Store("myntra") { q -> myntra(q) },
        Store("ajio") { q -> ajio(q) },
        Store("nykaa") { q ->
            pageStore(q, "https://www.nykaa.com", "https://www.nykaa.com/search/result/?q=%s&root=search", Regex("/p/\\d+"))
        },
        Store("meesho") { q ->
            pageStore(q, "https://www.meesho.com", "https://www.meesho.com/search?q=%s", Regex("/p/[a-z0-9]+"))
        },
        Store("jiomart") { q ->
            pageStore(q, "https://www.jiomart.com", "https://www.jiomart.com/search/%s", Regex("/p/"), pathStyle = true)
        },
    )

    private val CAPTCHA_RX = Regex("api-services-support@amazon|Enter the characters you see|validateCaptcha")

    private fun enc(q: String): String = URLEncoder.encode(q, "UTF-8")

    private fun amazon(q: String): List<Item> {
        val base = "https://www.amazon.in"
        val html = Http.get("$base/s?k=" + enc(q))
        if (CAPTCHA_RX.containsMatchIn(html)) throw StoreException("showed a bot-check (captcha)")
        val doc = Jsoup.parse(html, base)
        val out = ArrayList<Item>()
        for (el in doc.select("div[data-component-type=\"s-search-result\"]")) {
            val asin = el.attr("data-asin")
            if (asin.length != 10) continue
            val title = Parsing.clean(el.selectFirst("h2")?.text())
            val price = Parsing.toPrice(el.selectFirst("span.a-price-whole")?.text())
            if (title.isEmpty() || price == null) continue
            val image = el.selectFirst("img.s-image")?.absUrl("src")
            out.add(
                Item(
                    title = title,
                    price = price,
                    url = "$base/dp/$asin",
                    image = if (image != null && image.startsWith("http")) image else null,
                    rating = Parsing.toRating(el.selectFirst("span.a-icon-alt")?.text()),
                    reviews = Parsing.toCount(el.selectFirst("span.a-size-base.s-underline-text")?.text()),
                ),
            )
        }
        return out
    }

    private fun flipkart(q: String): List<Item> {
        val base = "https://www.flipkart.com"
        val html = Http.get("$base/search?q=" + enc(q))
        val items = Parsing.anchorItems(html, base, Regex("/p/itm"))
        if (items.isNotEmpty()) return items
        val out = ArrayList<Item>()
        for (b in Parsing.jsonBlobs(html)) out.addAll(Parsing.walkProducts(b, base))
        return out
    }

    private fun snapdeal(q: String): List<Item> {
        val base = "https://www.snapdeal.com"
        val html = Http.get("$base/search?keyword=" + enc(q) + "&sort=rlvncy")
        return Parsing.anchorItems(html, base, Regex("/product/"))
    }

    private fun myntra(q: String): List<Item> {
        val base = "https://www.myntra.com/"
        val slug = q.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        val html = Http.get("$base$slug?rawQuery=" + enc(q))
        val out = ArrayList<Item>()
        for (b in Parsing.jsonBlobs(html)) out.addAll(Parsing.walkProducts(b, base))
        if (out.isNotEmpty()) return out
        return Parsing.anchorItems(html, base, Regex("/buy"))
    }

    private fun ajio(q: String): List<Item> {
        val base = "https://www.ajio.com"
        val api = "$base/api/search?fields=SITE&currentPage=0&pageSize=45&format=json" +
            "&query=" + enc(q) + "&sortBy=relevance&gridColumns=3&platform=site"
        val text = Http.get(api, accept = "application/json", referer = "$base/")
        val data = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw StoreException("did not return product data")
        }
        return Parsing.walkProducts(data, base)
    }

    /** Sites that mostly build their page with JavaScript: try embedded JSON first, then plain links. */
    private fun pageStore(
        q: String,
        base: String,
        urlTemplate: String,
        linkRx: Regex,
        pathStyle: Boolean = false,
    ): List<Item> {
        val term = if (pathStyle) enc(q).replace("+", "%20") else enc(q)
        val html = Http.get(urlTemplate.replace("%s", term))
        val out = ArrayList<Item>()
        for (b in Parsing.jsonBlobs(html)) out.addAll(Parsing.walkProducts(b, base))
        if (out.isNotEmpty()) return out
        return Parsing.anchorItems(html, base, linkRx)
    }
}
