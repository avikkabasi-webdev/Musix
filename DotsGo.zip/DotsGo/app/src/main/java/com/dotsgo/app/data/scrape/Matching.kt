package com.dotsgo.app.data.scrape

/** Keeps only relevant products and merges the same product found in different stores. */
object Matching {

    private val STOP = setOf("the", "a", "an", "for", "with", "and", "of", "in", "by", "to", "from", "buy", "online", "new")
    private val VARIANT = setOf("plus", "pro", "max", "ultra", "mini", "lite", "se", "fe", "air", "neo")
    private val WORD_RX = Regex("[a-z0-9]+")

    fun tokens(text: String): Set<String> =
        WORD_RX.findAll(text.lowercase())
            .map { it.value }
            .filter { it !in STOP && it.length > 1 }
            .toSet()

    private fun stem(w: String): String = if (w.length > 3 && w.endsWith("s")) w.dropLast(1) else w

    fun relevant(title: String, queryTokens: Set<String>): Boolean {
        if (queryTokens.isEmpty()) return true
        val titleStems = tokens(title).map { stem(it) }.toSet()
        val hits = queryTokens.count { stem(it) in titleStems }
        return hits >= maxOf(1, (queryTokens.size + 1) / 2)
    }

    private fun numeric(set: Set<String>): Set<String> = set.filter { w -> w.any { it.isDigit() } }.toSet()

    fun sameProduct(a: Set<String>, b: Set<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        val union = a.union(b).size
        if (union == 0) return false
        val j = a.intersect(b).size.toDouble() / union.toDouble()
        if (j < 0.5) return false
        if (a.intersect(VARIANT) != b.intersect(VARIANT)) return false
        return numeric(a) == numeric(b) || j >= 0.8
    }

    class Group(val tokens: Set<String>, val title: String, var image: String?) {
        val stores = LinkedHashMap<String, Item>()
        fun cheapest(): Int = stores.values.minOf { it.price }
    }

    fun group(byStore: Map<String, List<Item>>): List<Group> {
        val groups = ArrayList<Group>()
        val longest = byStore.values.maxOfOrNull { it.size } ?: 0
        for (i in 0 until longest) {
            for ((store, items) in byStore) {
                if (i >= items.size) continue
                val item = items[i]
                val tk = tokens(item.title)
                var matched = false
                for (g in groups) {
                    if (sameProduct(g.tokens, tk)) {
                        val cur = g.stores[store]
                        if (cur == null || item.price < cur.price) g.stores[store] = item
                        if (g.image == null && item.image != null) g.image = item.image
                        matched = true
                        break
                    }
                }
                if (!matched) {
                    val g = Group(tk, item.title, item.image)
                    g.stores[store] = item
                    groups.add(g)
                }
            }
        }
        return groups
            .sortedWith(compareBy<Group>({ -it.stores.size }, { it.cheapest() }))
            .take(25)
    }
}
