package com.dotsgo.app.data.scrape

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Runs all store readers at the same time and returns one JSON answer for the page. */
object SearchRepository {

    private const val CACHE_TTL_MS = 3L * 60L * 60L * 1000L
    private const val PER_STORE_LIMIT = 12

    private class Cached(val json: String, val at: Long)

    private val cache = ConcurrentHashMap<String, Cached>()

    fun search(query: String): String {
        val key = query.lowercase().trim().replace(Regex("\\s+"), " ")
        val hit = cache[key]
        if (hit != null && System.currentTimeMillis() - hit.at < CACHE_TTL_MS) {
            return JSONObject(hit.json).put("fromCache", true).toString()
        }

        val queryTokens = Matching.tokens(query)
        val stores = Stores.all
        val status = JSONObject()
        val byStore = LinkedHashMap<String, List<Item>>()

        val pool = Executors.newFixedThreadPool(stores.size)
        try {
            val tasks = stores.map { store -> Callable<List<Item>> { store.fetch(query) } }
            val futures = pool.invokeAll(tasks, 28, TimeUnit.SECONDS)
            for (i in stores.indices) {
                val name = stores[i].key
                val f = futures[i]
                var error: String? = null
                var good: List<Item> = emptyList()
                if (f.isCancelled) {
                    error = "took too long"
                } else {
                    try {
                        val raw = f.get()
                        good = raw.filter { Matching.relevant(it.title, queryTokens) }.take(PER_STORE_LIMIT)
                        if (good.isEmpty()) error = "no matching products found on the page"
                    } catch (e: ExecutionException) {
                        val cause = e.cause
                        error = if (cause is StoreException) (cause.message ?: "failed") else "could not read the page"
                    } catch (e: Exception) {
                        error = "could not read the page"
                    }
                }
                if (good.isNotEmpty()) byStore[name] = good
                status.put(
                    name,
                    JSONObject().put("ok", good.isNotEmpty()).put("count", good.size).put("error", error),
                )
            }
        } finally {
            pool.shutdownNow()
        }

        val results = JSONArray()
        for (g in Matching.group(byStore)) {
            val sorted = g.stores.entries.sortedBy { it.value.price }
            val storesJson = JSONArray()
            for (e in sorted) {
                val s = e.value
                storesJson.put(
                    JSONObject()
                        .put("store", e.key)
                        .put("price", s.price)
                        .put("rating", s.rating)
                        .put("reviews", s.reviews)
                        .put("url", s.url),
                )
            }
            results.put(
                JSONObject()
                    .put("id", Integer.toHexString(g.title.hashCode()))
                    .put("title", g.title)
                    .put("image", g.image)
                    .put("cheapestPrice", sorted[0].value.price)
                    .put("cheapestStore", sorted[0].key)
                    .put("stores", storesJson),
            )
        }

        val out = JSONObject()
            .put("results", results)
            .put("status", status)
            .put("timestamp", System.currentTimeMillis())
            .put("fromCache", false)
        val json = out.toString()
        if (results.length() > 0) cache[key] = Cached(json, System.currentTimeMillis())
        return json
    }
}
