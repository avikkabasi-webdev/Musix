package com.lastwave.app.data.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.lastwave.app.MainActivity
import com.lastwave.app.R
import com.lastwave.app.data.local.db.DownloadedTrackDao
import com.lastwave.app.data.local.db.DownloadedTrackEntity
import com.lastwave.app.data.lyrics.LyricsRepository
import com.lastwave.app.data.lyrics.LyricsResult
import com.lastwave.app.data.music.InnerTubeMusicApi
import com.lastwave.app.data.music.TextMatch
import com.lastwave.app.data.music.YouTubeMusicTrack
import com.lastwave.app.data.lossless.LosslessAudioStream
import com.lastwave.app.data.lossless.LosslessMusicApi
import android.media.AudioManager
import android.media.MediaCodecList
import com.lastwave.app.data.plugin.ModuleManager
import com.lastwave.app.data.plugin.ModuleOfflineLicense
import com.lastwave.app.data.plugin.ModulePlaybackResolver
import com.lastwave.app.data.plugin.OfflineKeys
import com.lastwave.app.data.plugin.OfflineSidecar
import com.lastwave.app.data.plugin.SegmentedDashBridge
import com.lastwave.app.data.plugin.SegmentedStreamDescriptor
import com.lastwave.app.data.local.DownloadFolderStructure
import com.lastwave.app.data.local.MiscSettings
import com.lastwave.app.data.local.SettingsPreferences
import com.lastwave.app.data.local.sanitizeDownloadFolderName
import com.lastwave.app.data.artwork.ArtworkNormalizer
import com.lastwave.app.data.artwork.ArtworkRepository
import com.lastwave.app.playback.formatDetailedQualityBadge
import com.lastwave.app.util.ArtistHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.EOFException
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.InterruptedIOException
import java.io.IOException
import java.io.RandomAccessFile
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class DownloadProgress(
    val key: String,
    val title: String,
    val artist: String,
    val progressPercent: Int = 0,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = -1L,
    val formatBadge: String = "AUDIO",
    val isWaitingForConnection: Boolean = false,
    val isFinished: Boolean = false,
    val error: String? = null,
)

private data class DownloadTransfer(
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val contentType: String,
)

private data class DownloadRange(val start: Long, val endInclusive: Long) {
    val length: Long get() = endInclusive - start + 1L
}

private data class ParsedContentRange(
    val start: Long,
    val endInclusive: Long,
    val total: Long,
)

private class DownloadHttpException(val statusCode: Int) :
    IOException("HTTP $statusCode downloading track")

private class DownloadProtocolException(message: String) : IOException(message)

private class DownloadInterruptedException(message: String, cause: Throwable? = null) :
    IOException(message, cause)

@Singleton
class TrackDownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val innerTube: InnerTubeMusicApi,
    private val artworkRepository: ArtworkRepository,
    private val lyricsRepository: LyricsRepository,
    private val audioTagWriter: AudioTagWriter,
    okHttpClient: OkHttpClient,
    private val downloadedTrackDao: DownloadedTrackDao,
    private val settingsPreferences: SettingsPreferences,
    private val applicationScope: CoroutineScope,
    private val moduleResolver: ModulePlaybackResolver,
    private val segBridge: SegmentedDashBridge,
    private val offlineLicense: ModuleOfflineLicense,
    private val moduleManager: ModuleManager,
    private val flacTranscoder: ModuleFlacTranscoder,
    private val losslessMusicApi: LosslessMusicApi,
) {
    companion object {
        const val CHANNEL_ID = "lastwave_downloads"
        const val ACTION_CANCEL_DOWNLOAD = "com.lastwave.app.ACTION_CANCEL_DOWNLOAD"
        const val ACTION_RECONNECT_DOWNLOAD = "com.lastwave.app.ACTION_RECONNECT_DOWNLOAD"
        const val ACTION_VIEW_DOWNLOADS = "com.lastwave.app.ACTION_VIEW_DOWNLOADS"
        const val EXTRA_DOWNLOAD_KEY = "download_key"
        const val EXTRA_DOWNLOAD_TITLE = "download_title"
        const val EXTRA_DOWNLOAD_ARTIST = "download_artist"
        const val EXTRA_NAVIGATE_TO = "navigate_to"
        private const val PUBLIC_DIR_NAME = "LastWave"
        /** Legacy default kept for reading files downloaded before a custom folder was chosen. */
        private const val LEGACY_PUBLIC_DIR_NAME = "LastWave"
        // 128 KB keeps per-connection buffers out of the large-object heap:
        // 512 KB chunks fragmented ART heaps on low-RAM devices and a burst
        // of parallel ranges could OOM the process after a few downloads.
        private const val DOWNLOAD_BUFFER_SIZE = 128 * 1024 // 128 KB
        private const val PARALLEL_YOUTUBE_PARTS = 4
        // Up to 5 tracks download at once; per-download buffers stay small
        // (128 KB x 4 ranges) so this remains safe on low-RAM devices.
        private const val MAX_CONCURRENT_DOWNLOADS = 5
        /** Reconnectable transfer failures tolerated before the attempt is abandoned. */
        private const val MAX_TRANSFER_RETRIES = 6
        /** Bound on each YouTube stream-resolve step so one candidate can't wedge a slot. */
        private const val YT_STREAM_RESOLVE_TIMEOUT_MS = 20_000L
        private const val MIN_PARALLEL_DOWNLOAD_BYTES = 2L * 1024 * 1024
        private const val MIN_VALID_AUDIO_BYTES = 1_024L
        private const val RECONNECT_POLL_INTERVAL_MS = 500L
        private const val RECONNECT_RETRY_BASE_DELAY_MS = 1_000L
        private const val RECONNECT_RETRY_MAX_DELAY_MS = 30_000L
        private const val DOWNLOAD_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
        private val CONTENT_RANGE_PATTERN = Regex("""bytes\s+(\d+)-(\d+)/(\d+)""", RegexOption.IGNORE_CASE)

        fun makeDownloadKey(title: String, artist: String): String =
            "${artist.trim().lowercase()}_${title.trim().lowercase()}"
    }

    // Dedicated HTTP client with extended timeouts and bounded pooling.
    // Caps are deliberately low: each parallel range holds a socket plus a
    // read buffer, and unbounded pooling kept idle connections (and their
    // buffers) alive for minutes across successive downloads.
    private val downloadClient = okHttpClient.newBuilder()
        .dispatcher(Dispatcher().apply {
            // 5 concurrent downloads x 4 ranges, usually on one googlevideo
            // host: a per-host cap of 8 queued ranges behind each other.
            maxRequests = 40
            maxRequestsPerHost = 24
        })
        .connectionPool(ConnectionPool(20, 5, TimeUnit.MINUTES))
        .connectTimeout(20, TimeUnit.SECONDS)
        // A stalled socket is detected in 30s and resumed by the retry loop
        // instead of hanging the download for 2 minutes per stall.
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.MINUTES)
        .build()

    // This class is constructed eagerly inside the Hilt graph. A system
    // service lookup that throws or returns null on a modified ROM would
    // otherwise fail every injection and take down app launch, so the
    // manager is resolved lazily and tolerated as absent.
    private val notificationManager: NotificationManager? by lazy {
        runCatching {
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        }.getOrNull()
    }
    private val activeKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val activeJobs = ConcurrentHashMap<String, Job>()
    /** Shared with [downloadTrack] so a wipe can freeze admission before it snapshots jobs. */
    private val admissionLock = Any()
    @Volatile
    private var downloadsWiping = false
    private val activeUris = ConcurrentHashMap<String, Uri>()
    private val activeFiles = ConcurrentHashMap<String, File>()
    private val reconnectGenerations = ConcurrentHashMap<String, AtomicLong>()
    private val downloadSlots = Semaphore(MAX_CONCURRENT_DOWNLOADS)

    private val _downloads = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadProgress>> = _downloads.asStateFlow()

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = notificationManager ?: return
        runCatching {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Download progress and status notifications"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }.onFailure { error ->
            android.util.Log.w("TrackDownloadManager", "Notification channel unavailable", error)
        }
    }

    fun makeDownloadKey(title: String, artist: String): String =
        "${artist.trim().lowercase()}_${title.trim().lowercase()}"

    /** Active download subfolder under Music/ (sanitized single segment). */
    private suspend fun currentDownloadDirName(): String {
        val folder = try {
            settingsPreferences.settings.first().downloadFolder
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            return PUBLIC_DIR_NAME
        }
        return runCatching { sanitizeDownloadFolderName(folder) }.getOrDefault(PUBLIC_DIR_NAME)
    }

    /** All dirs to search for existing files: active folder first, then the
     *  legacy default so tracks downloaded before a folder change still resolve. */
    private fun downloadSearchDirs(preferred: String): List<File> {
        val dirs = mutableListOf<File>()
        dirs.add(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), preferred))
        if (preferred != LEGACY_PUBLIC_DIR_NAME) {
            dirs.add(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), LEGACY_PUBLIC_DIR_NAME))
        }
        return dirs
    }

    /** Strips featured/collaborating artists for folder names:
     *  "A feat. B", "A, B", "A & B", "A x B" -> "A". */
    private fun primaryArtistName(artist: String): String {
        var name = artist.trim()
        name = name.split(Regex("(?i)\\s+(feat\\.?|ft\\.?|featuring|with)\\s+.*$"))
            .firstOrNull()?.trim().orEmpty().ifBlank { name }
        name = name.split(',', ';', '&', '/', '、', '×')
            .firstOrNull()?.trim().orEmpty().ifBlank { name }
        name = name.split(Regex("(?i)\\s+x\\s+"))
            .firstOrNull()?.trim().orEmpty().ifBlank { name }
        return name.ifBlank { artist.trim() }
    }

    /**
     * Relative subfolder under Music/<dir>/ for a track, "" = flat.
     * Singles = missing/blank/"Singles" album (no release-type metadata exists
     * to distinguish EPs, so Artist/Album and Artist/Album+Singles coincide).
     */
    private fun downloadSubpath(
        artist: String,
        albumArtist: String? = null,
        album: String? = null,
        year: String? = null,
        structure: DownloadFolderStructure = DownloadFolderStructure.FLAT,
        useAlbumArtist: Boolean = true,
        primaryOnly: Boolean = true,
    ): String {
        if (structure == DownloadFolderStructure.FLAT) return ""
        var folderArtist = (if (useAlbumArtist) albumArtist?.takeIf { it.isNotBlank() } else null)
            ?: artist
        if (primaryOnly) folderArtist = primaryArtistName(folderArtist)
        folderArtist = sanitizeFilename(folderArtist.trim()).trim().ifBlank { "Unknown Artist" }
        val rawAlbum = album?.trim().orEmpty()
        val isSingle = rawAlbum.isBlank() || rawAlbum.equals("Singles", ignoreCase = true)
        val albumSeg = sanitizeFilename(rawAlbum).trim().ifBlank { "Singles" }
        val yearSeg = year?.filter { it.isDigit() }?.take(4)?.takeIf { it.length == 4 }
        val yearAlbumSeg = if (yearSeg != null && !isSingle) "[$yearSeg] $albumSeg" else albumSeg
        val segments = when (structure) {
            DownloadFolderStructure.FLAT -> emptyList()
            DownloadFolderStructure.ARTIST_ALBUM,
            DownloadFolderStructure.ARTIST_ALBUM_SINGLES ->
                if (isSingle) listOf(folderArtist, "Singles") else listOf(folderArtist, albumSeg)
            DownloadFolderStructure.ARTIST_YEAR_ALBUM ->
                if (isSingle) listOf(folderArtist, "Singles") else listOf(folderArtist, yearAlbumSeg)
            DownloadFolderStructure.ALBUM_ONLY ->
                listOf(if (isSingle) "Singles" else albumSeg)
            DownloadFolderStructure.YEAR_ALBUM ->
                listOf(if (isSingle) "Singles" else yearAlbumSeg)
            DownloadFolderStructure.ARTIST_ALBUM_SINGLES_FLAT ->
                if (isSingle) listOf(folderArtist) else listOf(folderArtist, albumSeg)
        }
        return segments.filter { it.isNotBlank() }.joinToString("/")
    }

    fun isDownloading(title: String, artist: String): Boolean {
        val key = makeDownloadKey(title, artist)
        val progress = _downloads.value[key]
        if (activeKeys.contains(key) || (progress != null && !progress.isFinished && progress.error == null)) return true
        // Stale callers may still pass a counter string ("15 ml listens") that can
        // never match the sanitized in-flight key; fall back to title match so the
        // UI doesn't offer a duplicate download.
        if (ArtistHelper.isPlayCountOrStat(artist)) {
            return _downloads.value.values.any {
                !it.isFinished && it.error == null && it.title.equals(title.trim(), ignoreCase = true)
            }
        }
        return false
    }

    suspend fun isTrackDownloaded(title: String, artist: String): Boolean = withContext(Dispatchers.IO) {
        val key = makeDownloadKey(title, artist)
        val existing = runCatching {
            downloadedTrackDao.findByTrackKey(key)
                ?: downloadedTrackDao.findByTitleAndArtist(title.trim(), artist.trim())
        }.getOrNull() ?: runCatching {
            // Stat-artist lookup could never match repaired rows; fall back to
            // title-only so stale callers still see the track as downloaded.
            if (ArtistHelper.isPlayCountOrStat(artist)) {
                downloadedTrackDao.getAllList().firstOrNull {
                    it.title.equals(title.trim(), ignoreCase = true)
                }
            } else null
        }.getOrNull()

        if (existing != null) {
            if (isRecordedFileHealthy(existing)) return@withContext true
        }

        // Check if file already exists in the download directories (active folder + legacy default, incl. subfolders).
        // The walk is guarded: on scoped-storage devices the public Music dir
        // can throw (or a concurrent download can churn it), and that must
        // degrade to "not found" rather than crashing the caller.
        val dirName = currentDownloadDirName()
        val candidateExtensions = listOf("flac", "m4a", "opus", "mp3", "webm")
        val sanitizedBase = sanitizeFilename("${artist.trim()} - ${title.trim()}")
        val candidateNames = candidateExtensions.map { "$sanitizedBase.$it" }.toSet()
        val foundOnDisk = runCatching {
            downloadSearchDirs(dirName).any { publicDir ->
                publicDir.exists() && publicDir.isDirectory &&
                    publicDir.walkTopDown().maxDepth(6).any { f ->
                        f.isFile && f.name in candidateNames && f.length() > 0
                    }
            }
        }.getOrDefault(false)
        if (foundOnDisk) {
            return@withContext true
        }

        false
    }

    /**
     * True only when the recorded audio file still exists, is not empty and
     * starts with a real audio container header. A deleted or corrupted file
     * returns false so the song can be downloaded again.
     */
    private fun isRecordedFileHealthy(track: DownloadedTrackEntity): Boolean = runCatching {
        val header = ByteArray(12)
        var read = 0
        if (!track.mediaStoreUri.isNullOrBlank()) {
            val stream = context.contentResolver.openInputStream(Uri.parse(track.mediaStoreUri))
                ?: return@runCatching false
            stream.use { input ->
                while (read < header.size) {
                    val n = input.read(header, read, header.size - read)
                    if (n <= 0) break
                    read += n
                }
            }
        } else {
            val f = File(track.filePath)
            if (!f.exists() || f.length() < header.size) return@runCatching false
            RandomAccessFile(f, "r").use { input ->
                while (read < header.size) {
                    val n = input.read(header, read, header.size - read)
                    if (n <= 0) break
                    read += n
                }
            }
        }
        if (read < header.size) return@runCatching false
        // Unknown formats (badge AUDIO) only need to exist and be non-empty.
        track.formatBadge.equals("AUDIO", ignoreCase = true) || audioHeaderLooksValid(header)
    }.getOrDefault(false)

    private fun audioHeaderLooksValid(header: ByteArray): Boolean {
        fun at(offset: Int, text: String) =
            text.indices.all { header[offset + it] == text[it].code.toByte() }
        val b0 = header[0].toInt() and 0xFF
        val b1 = header[1].toInt() and 0xFF
        return at(0, "fLaC") ||
            at(4, "ftyp") ||
            at(0, "OggS") ||
            at(0, "ID3") ||
            at(0, "RIFF") ||
            (b0 == 0x1A && b1 == 0x45 && (header[2].toInt() and 0xFF) == 0xDF && (header[3].toInt() and 0xFF) == 0xA3) ||
            (b0 == 0xFF && (b1 and 0xE0) == 0xE0)
    }

    /**
     * Called when the user taps a downloaded song. If its file was deleted or
     * is corrupted, the stale row and leftover file are removed and a fresh
     * download starts. Returns true when a (re)download is running instead of
     * the song being playable.
     */
    suspend fun redownloadIfBroken(track: DownloadedTrackEntity): Boolean = withContext(Dispatchers.IO) {
        if (isRecordedFileHealthy(track)) return@withContext false
        if (isDownloading(track.title, track.artist)) return@withContext true
        runCatching { deleteDownloadedTrack(track) }
        downloadTrack(
            title = track.title,
            artist = track.artist,
            album = track.album.ifBlank { null },
            artworkUrl = track.artworkUrl?.takeUnless { it.startsWith("file:") },
            durationMs = track.durationMs.takeIf { it > 0L },
        )
        true
    }

    fun cancelDownload(key: String) {
        activeKeys.remove(key)
        reconnectGenerations.remove(key)?.incrementAndGet()
        val job = activeJobs.remove(key)
        job?.cancel()

        // Clean up partial media entry/file
        activeUris.remove(key)?.let { uri ->
            runCatching { context.contentResolver.delete(uri, null, null) }
        }
        activeFiles.remove(key)?.let { file ->
            runCatching { if (file.exists()) file.delete() }
        }

        notificationManager?.cancel(key.hashCode())
        _downloads.update { it - key }
    }

    fun cancelDownload(title: String, artist: String) {
        cancelDownload(makeDownloadKey(title, artist))
    }

    fun cancelAllDownloads() {
        val allKeys = (activeKeys + _downloads.value.keys).toSet()
        allKeys.forEach { key ->
            cancelDownload(key)
        }
    }

    fun reconnectDownload(key: String): Boolean {
        if (key !in activeKeys) return false
        reconnectGenerations[key]?.incrementAndGet() ?: return false
        return true
    }

    fun downloadTrack(
        title: String,
        artist: String,
        album: String? = null,
        artworkUrl: String? = null,
        year: String? = null,
        videoId: String? = null,
        durationMs: Long? = null,
    ) {
        val key = makeDownloadKey(title, artist)
        // Admission and job registration share [admissionLock] with the wipe so a
        // worker cannot start, or publish its handle, after the wipe has snapshotted.
        synchronized(admissionLock) {
            if (downloadsWiping) return
            if (!activeKeys.add(key)) return
            reconnectGenerations[key] = AtomicLong()
            val job = applicationScope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) {
                runDownloadJob(key, title, artist, album, artworkUrl, year, videoId, durationMs)
            }
            activeJobs[key] = job
            job.start()
        }
    }

    private suspend fun CoroutineScope.runDownloadJob(
        key: String,
        title: String,
        artist: String,
        album: String?,
        artworkUrl: String?,
        year: String?,
        videoId: String?,
        durationMs: Long?,
    ) {
            // Bound the number of simultaneous downloads: each one holds
            // sockets, buffers and (during tagging) a decoded cover bitmap,
            // and unbounded overlap OOMed low-RAM devices after a few songs.
            // acquire() is cancellable; a cancel while queued must still
            // release the key so the slot never strands.
            try {
                downloadSlots.acquire()
            } catch (cancelled: CancellationException) {
                forgetDownloadKey(key)
                return
            }
            if (downloadsWiping) {
                abandonAcquiredDownload(key)
                return
            }
            // Already downloaded? Skip re-downloading entirely rather than
            // re-fetching the file and inserting a duplicate DB row or (1).flac file.
            val existing = try {
                downloadedTrackDao.findByTrackKey(key)
                    ?: downloadedTrackDao.findByTitleAndArtist(title.trim(), artist.trim())
            } catch (cancelled: CancellationException) {
                abandonAcquiredDownload(key)
                return
            } catch (_: Exception) {
                null
            }
            if (downloadsWiping) {
                abandonAcquiredDownload(key)
                return
            }
            if (existing != null) {
                if (isRecordedFileHealthy(existing)) {
                    downloadSlots.release()
                    forgetDownloadKey(key)
                    return
                }
                // Row is stale (file deleted outside the app, or damaged) — fall through
                // and re-download; the unique trackKey index means the insert
                // below will REPLACE this row instead of duplicating it.
            } else {
                val dirName = try {
                    currentDownloadDirName()
                } catch (cancelled: CancellationException) {
                    abandonAcquiredDownload(key)
                    return
                }
                val sanitizedBase = sanitizeFilename("${artist.trim()} - ${title.trim()}")
                val candidateNames = setOf("flac", "m4a", "opus", "mp3", "webm").map { "$sanitizedBase.$it" }.toSet()
                // Guarded: this ran outside any try/catch, so a filesystem
                // hiccup here used to escape the coroutine and kill the app.
                val found = runCatching {
                    downloadSearchDirs(dirName).any { publicDir ->
                        publicDir.exists() && publicDir.isDirectory &&
                            publicDir.walkTopDown().maxDepth(6).any { f ->
                                f.isFile && f.name in candidateNames && f.length() > 0
                            }
                    }
                }.getOrDefault(false)
                if (found) {
                    downloadSlots.release()
                    forgetDownloadKey(key)
                    return
                }
            }
            val notifId = key.hashCode()
            updateProgress(DownloadProgress(key = key, title = title, artist = artist, progressPercent = 0))
            // Notifications are best-effort: a PendingIntent/Notification
            // failure must never escape the coroutine and kill the app.
            runCatching {
                showDownloadNotification(notifId, key, title, artist, 0, false, "Preparing high-res stream...")
            }
            // Live stage text: tier failures used to be invisible until the
            // terminal skip. Stage updates are progress-only except on major
            // transitions, so notifications don't spam per tier.
            fun updateStage(stage: String, notify: Boolean = false) {
                updateProgress(
                    DownloadProgress(
                        key = key, title = title, artist = artist,
                        progressPercent = 0, formatBadge = stage,
                    ),
                )
                if (notify) {
                    runCatching {
                        showDownloadNotification(notifId, key, title, artist, 0, false, stage)
                    }
                }
            }

            var destinationUri: Uri? = null
            var destinationFile: File? = null
            var tempDownloadFile: File? = null

            try {
                ensureDownloadStillAllowed()
                // Never let counter strings ("15 ml listens", "Track 16", "10K views")
                // leak into filenames, tags or the DB. Callers on fixed code paths
                // already pass clean values (AlbumDetailScreen safeArtist + hardened
                // InnerTube parsing), this is the safety net for stale callers and
                // for the already-queued stat-artist downloads.
                val rawTitle = title.trim()
                val rawArtistIsStat = ArtistHelper.isPlayCountOrStat(artist)
                var safeArtist = artist.trim().takeUnless { ArtistHelper.isPlayCountOrStat(it) }?.ifBlank { null }
                var safeAlbumInput = album?.trim()?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }?.takeIf { it.isNotBlank() }
                // If the artist was a counter but the album title is known (album
                // download case), recover the real artist via search before any
                // network/stream work so tagging, filenames and DB stay correct.
                if (safeArtist.isNullOrBlank() && rawTitle.isNotBlank()) {
                    val recoveryQueryArtist = safeAlbumInput.orEmpty()
                    val recovered = runCatching {
                        if (recoveryQueryArtist.isNotBlank()) {
                            innerTube.findBestMatch(rawTitle, recoveryQueryArtist, prefetchStreams = false)
                        } else {
                            innerTube.findBestMatch(rawTitle, "", prefetchStreams = false)
                        }
                    }.getOrNull()
                    val recoveredArtist = recovered?.artist?.trim()
                        ?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                        ?.takeIf { it.isNotBlank() }
                    if (recoveredArtist != null) {
                        safeArtist = recoveredArtist
                        if (safeAlbumInput.isNullOrBlank()) {
                            safeAlbumInput = recovered.album?.trim()
                                ?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                                ?.takeIf { it.isNotBlank() }
                        }
                    }
                }
                val effTitle = rawTitle.ifBlank { title.trim() }
                // Fall back to "Unknown Artist" only for display/filename; the DB
                // repair pass below will re-resolve it when network allows.
                val effArtist = safeArtist?.takeIf { it.isNotBlank() } ?: "Unknown Artist"
                val effArtistForLookup = safeArtist?.takeIf { it.isNotBlank() } ?: ""
                val artistWasStat = rawArtistIsStat || safeArtist.isNullOrBlank()

                // Resolve missing metadata & cover art proactively
                var resolvedArtworkUrl = artworkUrl?.takeIf { ArtworkNormalizer.isRealImage(it) }
                var resolvedAlbum = safeAlbumInput?.takeIf { it.isNotBlank() }
                var preloadedBestMatch: YouTubeMusicTrack? = null

                if (!videoId.isNullOrBlank()) {
                    preloadedBestMatch = runCatching {
                        innerTube.fetchSongDetails(videoId)
                    }.getOrNull()
                }

                if (preloadedBestMatch == null && (resolvedArtworkUrl == null || resolvedAlbum == null)) {
                    preloadedBestMatch = runCatching {
                        innerTube.findBestMatch(effTitle, effArtistForLookup, prefetchStreams = false)
                    }.getOrNull()
                }

                if (preloadedBestMatch != null) {
                    val isPlausible = !videoId.isNullOrBlank() ||
                        TextMatch.isSafeTitleMatch(preloadedBestMatch.title, effTitle, effArtistForLookup)
                    if (!isPlausible) {
                        preloadedBestMatch = null
                    }
                }

                if (preloadedBestMatch != null) {
                    val cleanMatchArtist = preloadedBestMatch.artist
                        .takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                    if (artistWasStat && cleanMatchArtist != null && cleanMatchArtist.isNotBlank()) {
                        safeArtist = cleanMatchArtist.trim()
                    }
                    if (resolvedArtworkUrl == null) {
                        resolvedArtworkUrl = preloadedBestMatch.artworkUrl?.takeIf { ArtworkNormalizer.isRealImage(it) }
                    }
                    if (resolvedAlbum == null) {
                        resolvedAlbum = preloadedBestMatch.album?.trim()
                            ?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                            ?.takeIf { it.isNotBlank() }
                    }
                }
                if (resolvedAlbum != null) {
                    resolvedAlbum = resolvedAlbum?.trim()
                        ?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                        ?.takeIf { it.isNotBlank() }
                }
                // Final sanitized values for tagging, filenames, folders and DB.
                // safeArtist may have been recovered above; effArtist was snapshotted
                // before, so recompute here.
                val finalTitle = effTitle
                val finalArtist = safeArtist?.trim()?.takeIf { it.isNotBlank() } ?: effArtist
                // DB key must never embed a counter string, otherwise one album
                // fans out into N artists/albums ("15 ml listens", "Track 3"...).
                val finalKey = makeDownloadKey(finalTitle, finalArtist)

                val artworkFallback = if (resolvedArtworkUrl == null) {
                    async(Dispatchers.IO) {
                        artworkRepository.resolve(finalTitle, finalArtist)
                        val cacheKey = ArtworkNormalizer.cacheKey(finalTitle, finalArtist)
                        artworkRepository.resolved.value[cacheKey]
                            ?.takeIf { ArtworkNormalizer.isRealImage(it) }
                            ?: kotlinx.coroutines.withTimeoutOrNull(3_500L) {
                                artworkRepository.resolved.first { it.containsKey(cacheKey) }[cacheKey]
                            }?.takeIf { ArtworkNormalizer.isRealImage(it) }
                    }
                } else {
                    null
                }

                // 1. Resolve source — respect user's download quality preference (Lossless tiers or YouTube Music)
                val misc = runCatching { settingsPreferences.settings.first() }.getOrDefault(MiscSettings())
                ensureDownloadStillAllowed()
                // Custom SAF folder (e.g. SD card): resolve once per download.
                // A stale grant (revoked permission / removed card) fails fast
                // with an actionable message instead of silently filling
                // internal storage the user explicitly moved away from.
                val customTreeUri = SafTreeFiles.parseTreeUri(misc.downloadTreeUri)
                if (customTreeUri != null && !SafTreeFiles.hasPersistedAccess(context, misc.downloadTreeUri)) {
                    val staleMsg = "Download folder unavailable — reselect it in Downloads → Download location"
                    updateProgress(
                        DownloadProgress(key = key, title = title, artist = artist, error = staleMsg),
                    )
                    runCatching { showErrorNotification(notifId, key, title, artist, staleMsg) }
                    return
                }
                var resolvedUrl: String? = null
                // Exact YouTube videoId that produced this download (when the
                // YouTube path was used) — feeds the thumbnail fallback and
                // honest logging at tagging time.
                var resolvedYtVideoId: String? = videoId?.takeIf { it.isNotBlank() }
                var mimeType = "audio/flac"
                var extension = "flac"
                // No depth claim until a stream actually resolves one: this
                // seed is what a progress notification shows, and "24-BIT" here
                // advertised a bit depth nothing had measured yet.
                var formatBadge = "FLAC"
                var isLossless = false
                var durationMs = 0L
                var downloadHeaders = emptyMap<String, String>()
                var expectedContentLength: Long? = null
                var useParallelDownload = false

                // Honor the download-quality setting (Dolby Atmos / stereo tiers / YouTube).
                // Do not force Dolby Atmos unless the user explicitly selected it as download quality.
                val requestedDownloadQuality = misc.downloadQuality
                val isYouTubeRequested = requestedDownloadQuality == LosslessMusicApi.QUALITY_YOUTUBE

                // 1. Provider module (.lwp engine): progressive clear FLAC/MP3 or segmented DASH (Dolby Atmos / Tidal Hi-Res)
                var moduleDescriptor: SegmentedStreamDescriptor? = null
                var moduleLicenseDeferred: Deferred<OfflineKeys?>? = null
                var isDashModuleDownload = false
                var dashInitUrl: String? = null
                var dashMediaTemplate: String? = null
                var dashSegmentCount = 0
                var dashStartNumber = 1
                /** Real codec from the DASH manifest (`flac` / `mp4a.40.2` / `ec-3`). */
                var dashManifestCodec = ""
                /** Manifest really carries FLAC (so the .m4a wrapper should be unwrapped). */
                var dashIsFlacInMp4 = false
                var bytesReadTotal = 0L
                var totalBytesRecorded = -1L
                var downloadSucceeded = false
                // Playback demotes Atmos to stereo on incapable devices; do
                // the same here so an Atmos request still yields playable
                // stereo FLAC instead of an unplayable spatial file.
                val atmosCapable by lazy { isAtmosCapableDevice() }
                if (!isYouTubeRequested && losslessMusicApi.isCoolingDown) {
                    android.util.Log.i(
                        "TrackDownloadManager",
                        "Lossless backend cooling down; '$finalTitle' goes straight to YouTube",
                    )
                    updateStage("YouTube • lossless cooling down", notify = true)
                }

                if (!isYouTubeRequested && !losslessMusicApi.isCoolingDown) {
                    updateStage("Finding lossless stream…")
                    // Single source of truth: same tier order as streaming
                    // (LosslessMusicApi.getQualityAttemptOrder). Rules:
                    // - YouTube requested: strict, never reaches here.
                    // - Atmos (28): atmos -> hi-res -> CD -> 320, then YouTube. Only path with 28.
                    // - Hi-Res (27/7): step DOWN only, never up to Atmos. YouTube last.
                    // - Lower tiers: preferred first, then higher above, then lower. Never Atmos.
                    // Data Saver (96k) is skipped unless explicitly chosen (YouTube beats it).
                    val qualitiesToAttempt =
                        LosslessMusicApi.getQualityAttemptOrder(requestedDownloadQuality)
                    for (downloadQuality in qualitiesToAttempt) {
                    // Spatial-tier veto (mirrors playback): never download an
                    // Atmos manifest on a device that cannot render it. The
                    // stereo tiers later in this same list are the fallback.
                    if (downloadQuality == LosslessMusicApi.QUALITY_DOLBY_ATMOS && !atmosCapable) {
                        android.util.Log.i(
                            "TrackDownloadManager",
                            "Atmos veto for $finalTitle by $finalArtist: device cannot render spatial; trying stereo tiers",
                        )
                        continue
                    }
                    try {
                        val expectedDurationSec = durationMs?.takeIf { it > 0 }?.let { (it / 1000L).toInt() }
                            ?: preloadedBestMatch?.durationSeconds?.takeIf { it > 0 }
                        // One retry: a transient blip must not kill the tier.
                        var losslessStream: LosslessAudioStream? = null
                        for (resolveAttempt in 0..1) {
                            losslessStream = runCatching {
                                losslessMusicApi.resolveStream(
                                    title = finalTitle,
                                    artist = finalArtist,
                                    expectedDurationSeconds = expectedDurationSec,
                                    expectedAlbum = resolvedAlbum,
                                    preferredQuality = downloadQuality,
                                    isDownload = true,
                                )
                            }.getOrNull()
                            if (losslessStream != null) break
                            if (resolveAttempt == 0) delay(400)
                        }
                        if (losslessStream != null && losslessStream.url.isBlank()) losslessStream = null
                        // Duration guard: never store a different
                        // recording/edition under this song's name.
                        if (losslessStream != null && expectedDurationSec != null && expectedDurationSec > 0) {
                            val streamSec = losslessStream.durationSeconds
                            if (streamSec > 0 && kotlin.math.abs(streamSec - expectedDurationSec) > 45) {
                                android.util.Log.w(
                                    "TrackDownloadManager",
                                    "Lossless duration mismatch for $finalTitle by $finalArtist: want ${expectedDurationSec}s got ${streamSec}s; trying next tier",
                                )
                                losslessStream = null
                            }
                        }
                        if (losslessStream == null) {
                            android.util.Log.i(
                                "TrackDownloadManager",
                                "Lossless tier $downloadQuality missed for $finalTitle by $finalArtist; trying next tier",
                            )
                        }

                        if (losslessStream != null && losslessStream.url.isNotBlank()) {
                            if (isDashUrl(losslessStream.url, losslessStream.mimeType)) {
                                val parsedDash = parseTidalDashManifest(losslessStream.url)
                                if (parsedDash != null) {
                                    val manifestCodec = parsedDash.codec.ifBlank { "flac" }
                                    // A stereo rendition served for an Atmos
                                    // request is fine (flac codec); a genuine
                                    // spatial manifest on an incapable device
                                    // is unplayable — cascade to stereo tiers.
                                    if (!atmosCapable &&
                                        (manifestCodec.startsWith("ec-3") ||
                                            manifestCodec.startsWith("eac3") ||
                                            manifestCodec.startsWith("ac-3"))
                                    ) {
                                        android.util.Log.w(
                                            "TrackDownloadManager",
                                            "Spatial manifest veto for $finalTitle by $finalArtist on incapable device; cascading to stereo tiers",
                                        )
                                        continue
                                    }
                                    val isAtmosStream = losslessStream.formatId == LosslessMusicApi.QUALITY_DOLBY_ATMOS ||
                                        manifestCodec.startsWith("ec-3") ||
                                        manifestCodec.startsWith("eac3") ||
                                        manifestCodec.startsWith("ac-3")
                                    val isFlacStream = manifestCodec.contains("flac")
                                    isDashModuleDownload = true
                                    dashInitUrl = parsedDash.initUrl
                                    dashMediaTemplate = parsedDash.mediaTemplate
                                    dashSegmentCount = parsedDash.segmentCount
                                    dashStartNumber = parsedDash.startNumber
                                    dashManifestCodec = manifestCodec
                                    dashIsFlacInMp4 = isFlacStream
                                    resolvedUrl = parsedDash.initUrl
                                    extension = "m4a"
                                    mimeType = "audio/mp4"
                                    val rateKHz = if (losslessStream.samplingRate > 1000.0) losslessStream.samplingRate / 1000.0 else losslessStream.samplingRate
                                    val depth = losslessStream.bitDepth.takeIf { it > 0 }
                                    formatBadge = when {
                                        isAtmosStream -> "DOLBY ATMOS"
                                        losslessStream.formatId == LosslessMusicApi.QUALITY_MP3_320 -> "320 kbps"
                                        losslessStream.formatId == LosslessMusicApi.QUALITY_DATA_SAVER -> "96 kbps"
                                        isFlacStream -> formatDetailedQualityBadge(depth, rateKHz)
                                        manifestCodec.startsWith("mp4a.40.5") -> "96 kbps"
                                        manifestCodec.startsWith("mp4a") -> "320 kbps"
                                        else -> "AAC"
                                    }
                                    isLossless = isAtmosStream || isFlacStream
                                    durationMs = (losslessStream.durationSeconds * 1000L).takeIf { it > 0 } ?: 0L
                                }
                            } else {
                                val isAtmosStream = losslessStream.formatId == LosslessMusicApi.QUALITY_DOLBY_ATMOS ||
                                    losslessStream.audioCodecOverride == "DOLBY ATMOS"
                                resolvedUrl = losslessStream.url
                                mimeType = losslessStream.mimeType.ifBlank { if (isAtmosStream) "audio/mp4" else "audio/flac" }
                                extension = when {
                                    mimeType.contains("mp3", ignoreCase = true) -> "mp3"
                                    isAtmosStream || mimeType.contains("mp4", ignoreCase = true) || mimeType.contains("m4a", ignoreCase = true) -> "m4a"
                                    mimeType.contains("aac", ignoreCase = true) -> "m4a"
                                    mimeType.contains("opus", ignoreCase = true) || mimeType.contains("ogg", ignoreCase = true) -> "opus"
                                    else -> "flac"
                                }
                                isLossless = !extension.equals("mp3", ignoreCase = true) &&
                                    !extension.equals("m4a", ignoreCase = true) &&
                                    !extension.equals("opus", ignoreCase = true) &&
                                    losslessStream.formatId != LosslessMusicApi.QUALITY_MP3_320 &&
                                    losslessStream.formatId != LosslessMusicApi.QUALITY_DATA_SAVER &&
                                    !mimeType.contains("aac", ignoreCase = true)
                                val rateKHz = if (losslessStream.samplingRate > 1000.0) losslessStream.samplingRate / 1000.0 else losslessStream.samplingRate
                                val depth = losslessStream.bitDepth.takeIf { it > 0 }
                                formatBadge = when {
                                    isAtmosStream -> "DOLBY ATMOS"
                                    losslessStream.formatId == LosslessMusicApi.QUALITY_MP3_320 -> "320 kbps"
                                    losslessStream.formatId == LosslessMusicApi.QUALITY_DATA_SAVER -> "96 kbps"
                                    isLossless -> formatDetailedQualityBadge(depth, rateKHz)
                                    else -> if (extension.equals("mp3", ignoreCase = true)) "MP3" else "AAC"
                                }
                                durationMs = (losslessStream.durationSeconds * 1000L).takeIf { it > 0 } ?: 0L
                            }
                        }

                        val desc = if (resolvedUrl != null) null else runCatching {
                            moduleResolver.resolve(finalTitle, finalArtist, downloadQuality)
                        }.getOrNull()
                        if (desc != null && desc.stream.baseUrl.isNotBlank()) {
                            val s = desc.stream
                            val isAtmos = s.codec.equals("atmos", ignoreCase = true)
                            if ((s.type == "progressive" || s.segments.isEmpty()) && !isDashUrl(s.baseUrl, s.mimeType) && s.type != "dash_xml") {
                                resolvedUrl = s.baseUrl
                                downloadHeaders = desc.headers
                                mimeType = s.mimeType.ifBlank { "audio/flac" }
                                extension = when {
                                    s.codec.equals("mp3", ignoreCase = true) -> "mp3"
                                    s.codec.equals("aac", ignoreCase = true) -> "m4a"
                                    else -> "flac"
                                }
                                isLossless = !s.codec.equals("opus", ignoreCase = true) &&
                                    !s.codec.equals("mp3", ignoreCase = true) &&
                                    !s.codec.equals("aac", ignoreCase = true) &&
                                    !s.codec.contains("mp4a", ignoreCase = true)
                                val rateKHz = if (s.sampleRate > 1000) s.sampleRate / 1000.0 else s.sampleRate.toDouble()
                                val depth = s.bitDepth?.takeIf { it > 0 }
                                formatBadge = if (isLossless) {
                                    formatDetailedQualityBadge(depth, rateKHz)
                                } else s.codec.uppercase()
                                durationMs = desc.durationSec * 1000L
                            } else if (s.type == "dash_xml" || isDashUrl(s.baseUrl, s.mimeType)) {
                                val parsedDash = parseTidalDashManifest(s.baseUrl)
                                if (parsedDash != null) {
                                    // Trust the manifest's own codec, not the descriptor's
                                    // assumption. Tidal answers HI_RES/LOSSLESS with
                                    // FLAC-in-MP4 but LOW/HIGH with plain AAC (mp4a),
                                    // and the old code labelled every DASH download as
                                    // FLAC and named it .m4a either way — so a lossless
                                    // request could be stored as AAC while claiming FLAC.
                                    val manifestCodec = parsedDash.codec.ifBlank { s.codec.lowercase() }
                                    if (!atmosCapable &&
                                        (manifestCodec.startsWith("ec-3") ||
                                            manifestCodec.startsWith("eac3") ||
                                            manifestCodec.startsWith("ac-3"))
                                    ) {
                                        android.util.Log.w(
                                            "TrackDownloadManager",
                                            "Spatial module manifest veto for $finalTitle by $finalArtist on incapable device; cascading to stereo tiers",
                                        )
                                        continue
                                    }
                                    val isAtmosStream = isAtmos ||
                                        manifestCodec.startsWith("ec-3") ||
                                        manifestCodec.startsWith("eac3") ||
                                        manifestCodec.startsWith("ac-3")
                                    val isFlacStream = manifestCodec.contains("flac")
                                    isDashModuleDownload = true
                                    dashInitUrl = parsedDash.initUrl
                                    dashMediaTemplate = parsedDash.mediaTemplate
                                    dashSegmentCount = parsedDash.segmentCount
                                    dashStartNumber = parsedDash.startNumber
                                    dashManifestCodec = manifestCodec
                                    // Unwrap whenever the container really holds FLAC,
                                    // including Atmos-flagged releases: this backend serves
                                    // their stereo 24/96 FLAC rendition (never E-AC-3 JOC),
                                    // and an .m4a holding FLAC reads as AAC to players.
                                    dashIsFlacInMp4 = isFlacStream
                                    resolvedUrl = parsedDash.initUrl
                                    downloadHeaders = desc.headers
                                    extension = "m4a"
                                    mimeType = "audio/mp4"
                                    val rateKHz = if (s.sampleRate > 1000) s.sampleRate / 1000.0 else s.sampleRate.toDouble()
                                    val depth = s.bitDepth?.takeIf { it > 0 }
                                    formatBadge = when {
                                        isAtmosStream -> "DOLBY ATMOS"
                                        isFlacStream -> formatDetailedQualityBadge(depth, rateKHz)
                                        manifestCodec.startsWith("mp4a.40.5") -> "96 kbps"
                                        manifestCodec.startsWith("mp4a") -> "320 kbps"
                                        else -> "AAC"
                                    }
                                    isLossless = isAtmosStream || isFlacStream
                                    durationMs = desc.durationSec * 1000L
                                }
                            } else if (desc.drm != null && s.segments.isNotEmpty()) {
                                moduleDescriptor = desc
                                resolvedUrl = s.baseUrl
                                downloadHeaders = desc.headers
                                expectedContentLength = s.segments
                                    .mapNotNull { it.range.substringAfterLast("-").toLongOrNull() }
                                    .maxOrNull()?.plus(1)
                                useParallelDownload = true
                                extension = "m4a"
                                mimeType = "audio/mp4"
                                formatBadge = segBridge.audioBadge(desc)
                                isLossless = !s.codec.equals("opus", ignoreCase = true) &&
                                    !s.codec.equals("mp3", ignoreCase = true) &&
                                    !s.codec.equals("aac", ignoreCase = true) &&
                                    !s.codec.contains("mp4a", ignoreCase = true)
                                durationMs = desc.durationSec * 1000L
                                // Offline license in parallel with the bytes.
                                moduleLicenseDeferred = applicationScope.async(Dispatchers.IO) {
                                    runCatching { offlineLicense.acquire(desc) }.getOrNull()
                                }
                            }
                        }

                        if (resolvedUrl != null) {
                            val rawFile = File.createTempFile("dl_raw_", ".$extension", context.cacheDir)
                                tempDownloadFile = rawFile

                                if (isDashModuleDownload && dashInitUrl != null && dashMediaTemplate != null && dashSegmentCount > 0) {
                                    val dashResult = downloadDashSegmentsToTempFile(
                                        downloadKey = key,
                                        notificationId = notifId,
                                        title = title,
                                        artist = artist,
                                        formatBadge = formatBadge,
                                        initUrl = dashInitUrl!!,
                                        mediaTemplate = dashMediaTemplate!!,
                                        segmentCount = dashSegmentCount,
                                        startNumber = dashStartNumber,
                                        headers = downloadHeaders,
                                        target = rawFile,
                                    )
                                    bytesReadTotal = dashResult.bytesWritten
                                    totalBytesRecorded = bytesReadTotal
                                    // A truncated segment list used to be kept
                                    // as a successful (short) file. Fail loudly
                                    // instead so the next tier or YouTube gets
                                    // a chance — unless enough audio arrived
                                    // that the manifest simply over-declared.
                                    if (dashResult.stoppedEarly) {
                                        val minBytes = if (durationMs > 0) {
                                            (durationMs / 1000L) * 16_000L
                                        } else {
                                            256_000L
                                        }
                                        if (bytesReadTotal < minBytes) {
                                            throw IOException(
                                                "Incomplete DASH download for $title by $artist: " +
                                                    "${dashResult.completedSegments}/${dashResult.expectedSegments} segments",
                                            )
                                        }
                                        android.util.Log.w(
                                            "TrackDownloadManager",
                                            "DASH over-declared segments for $title by $artist " +
                                                "(${dashResult.completedSegments}/${dashResult.expectedSegments}); keeping ${bytesReadTotal} bytes",
                                        )
                                    }
                                } else {
                                    var lastProgress = 0
                                    var lastNotifTime = 0L
                                    var lastUnknownProgressBytes = 0L
                                    val progressLock = Any()
                                    val transfer = downloadToTempFile(
                                        downloadKey = key,
                                        url = checkNotNull(resolvedUrl),
                                        target = rawFile,
                                        requestHeaders = downloadHeaders,
                                        expectedContentLength = expectedContentLength,
                                        useParallelRanges = useParallelDownload,
                                        onConnectionStateChanged = { isWaiting ->
                                            _downloads.value[key]?.let { current ->
                                                val updated = current.copy(isWaitingForConnection = isWaiting)
                                                updateProgress(updated)
                                                runCatching {
                                                    showDownloadNotification(
                                                        notificationId = notifId,
                                                        downloadKey = key,
                                                        title = title,
                                                        artist = artist,
                                                        progress = updated.progressPercent,
                                                        isIndeterminate = updated.totalBytes <= 0L,
                                                        badgeText = updated.formatBadge,
                                                        isWaitingForConnection = isWaiting,
                                                    )
                                                }
                                            }
                                        },
                                    ) { downloadedBytes, totalBytes ->
                                        synchronized(progressLock) {
                                            val now = android.os.SystemClock.uptimeMillis()
                                            if (totalBytes > 0) {
                                                val progress = ((downloadedBytes * 100) / totalBytes).toInt().coerceIn(0, 100)
                                                if (progress > lastProgress) {
                                                    lastProgress = progress
                                                    updateProgress(
                                                        DownloadProgress(
                                                            key = key, title = title, artist = artist,
                                                            progressPercent = progress,
                                                            bytesDownloaded = downloadedBytes,
                                                            totalBytes = totalBytes,
                                                            formatBadge = formatBadge,
                                                        ),
                                                    )
                                                    if (progress == 100 || now - lastNotifTime >= 250L) {
                                                        lastNotifTime = now
                                                        runCatching {
                                                            showDownloadNotification(notifId, key, title, artist, progress, false, formatBadge)
                                                        }
                                                    }
                                                }
                                            } else if (downloadedBytes - lastUnknownProgressBytes >= 1024 * 1024) {
                                                lastUnknownProgressBytes = downloadedBytes
                                                val mbDown = String.format("%.1f MB", downloadedBytes / (1024.0 * 1024.0))
                                                updateProgress(
                                                    DownloadProgress(
                                                        key = key, title = title, artist = artist,
                                                        progressPercent = 0,
                                                        bytesDownloaded = downloadedBytes,
                                                        totalBytes = -1L,
                                                        formatBadge = "$formatBadge • $mbDown",
                                                    ),
                                                )
                                                if (now - lastNotifTime >= 500L) {
                                                    lastNotifTime = now
                                                    runCatching {
                                                        showDownloadNotification(notifId, key, title, artist, 0, true, formatBadge)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    val contentType = transfer.contentType.lowercase()
                                    if (contentType.contains("webm")) {
                                        extension = "webm"
                                        mimeType = "audio/webm"
                                        formatBadge = "WEBM OPUS"
                                    } else if (contentType.contains("ogg") || contentType.contains("opus")) {
                                        extension = "opus"
                                        mimeType = "audio/ogg"
                                        formatBadge = "OPUS"
                                    } else if (contentType.contains("mpeg") || contentType.contains("mp3")) {
                                        extension = "mp3"
                                        mimeType = "audio/mpeg"
                                        formatBadge = "MP3"
                                    } else if (contentType.contains("mp4") || contentType.contains("m4a") || contentType.contains("aac")) {
                                        extension = "m4a"
                                        mimeType = "audio/mp4"
                                        formatBadge = "M4A AAC"
                                    }
                                    bytesReadTotal = transfer.bytesDownloaded
                                    totalBytesRecorded = transfer.totalBytes
                                }

                                if (!isDashModuleDownload) {
                                    val detected = detectValidContainer(rawFile)
                                    if (detected != null) {
                                        extension = detected
                                        mimeType = when (detected) {
                                            "m4a" -> "audio/mp4"
                                            "webm" -> "audio/webm"
                                            "opus" -> "audio/ogg"
                                            "mp3" -> "audio/mpeg"
                                            "flac" -> "audio/flac"
                                            else -> mimeType
                                        }
                                    } else if (useParallelDownload && !hasExpectedContainer(rawFile, extension)) {
                                        throw IOException("Downloaded payload is not a valid ${extension.uppercase()} audio file")
                                    }
                                }
                                downloadSucceeded = true
                            }
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (moduleError: Throwable) {
                        android.util.Log.w("TrackDownloadManager", "Download (quality=$downloadQuality) failed for $title by $artist; trying next tier or YouTube", moduleError)
                        moduleLicenseDeferred?.cancel()
                        moduleLicenseDeferred = null
                        moduleDescriptor = null
                        isDashModuleDownload = false
                        resolvedUrl = null
                        tempDownloadFile?.let { runCatching { if (it.exists()) it.delete() } }
                        tempDownloadFile = null
                        downloadSucceeded = false
                        // Reset state for potential retry at lower quality
                        mimeType = "audio/flac"
                        extension = "flac"
                        // Depth is unknown again until the retry resolves one.
                        formatBadge = "FLAC"
                        isLossless = false
                        durationMs = 0L
                        downloadHeaders = emptyMap()
                        expectedContentLength = null
                        useParallelDownload = false
                        dashInitUrl = null
                        dashMediaTemplate = null
                        dashSegmentCount = 0
                        dashStartNumber = 1
                        dashManifestCodec = ""
                        dashIsFlacInMp4 = false
                        bytesReadTotal = 0L
                        totalBytesRecorded = -1L
                        continue
                    }
                    if (downloadSucceeded) break
                    } // end quality retry loop
                }

                // 2. Fallback to YouTube Music if module was not requested or module download failed
                if (!downloadSucceeded) {
                    try {
                        updateStage("Finding YouTube stream…", notify = true)
                        val lookupArtist = safeArtist?.trim()?.takeIf { it.isNotBlank() } ?: ""
                        // Same path as playback (SimpMusic/Metrolist/ArchiveTune style):
                        // explicit videoId first, then cached/broad search candidates.
                        // Never single-shot strict match — search more, try each.
                        // Budgeted so one wedged track cannot hold a
                        // download slot and stall the batch queue.
                        val ytFallbackStartMs = android.os.SystemClock.elapsedRealtime()
                        val ytResolveBudgetMs = 60_000L
                        val candidateTracks = linkedMapOf<String, YouTubeMusicTrack>()
                        val isPlausibleTrack: (YouTubeMusicTrack) -> Boolean = { track ->
                            track.videoId.isNotBlank() && (track.videoId == videoId || TextMatch.isSafeTitleMatch(track.title, finalTitle, lookupArtist))
                        }
                        videoId?.takeIf { it.isNotBlank() }?.let { candidateTracks[it] =
                            preloadedBestMatch?.takeIf { match -> match.videoId == it }
                                ?: YouTubeMusicTrack(videoId = it, title = finalTitle, artist = finalArtist)
                        }
                        preloadedBestMatch?.takeIf(isPlausibleTrack)?.let { match ->
                            candidateTracks.putIfAbsent(match.videoId, match)
                        }
                        // Broad search is capped inside (10 merged candidates);
                        // the 60s resolve budget below bounds the slow path.
                        runCatching {
                            innerTube.findDownloadCandidates(finalTitle, lookupArtist)
                        }.getOrDefault(emptyList()).filter(isPlausibleTrack).forEach { track ->
                            candidateTracks.putIfAbsent(track.videoId, track)
                        }
                        // Last resort: legacy single strict match (kept for metadata only).
                        if (candidateTracks.isEmpty()) {
                            runCatching {
                                innerTube.findBestMatch(finalTitle, lookupArtist, prefetchStreams = false)
                            }.getOrNull()?.takeIf(isPlausibleTrack)?.let { track ->
                                candidateTracks.putIfAbsent(track.videoId, track)
                            }
                        }
                        if (candidateTracks.isEmpty()) throw IOException("No YouTube match found for $finalTitle by $finalArtist")
                        var pickedStream: com.lastwave.app.data.music.YouTubeAudioStream? = null
                        var actualVideoId: String? = null
                        var chosenTrack: YouTubeMusicTrack? = null
                        var lastResolveError: Throwable? = null
                        for ((candidateId, candidateTrack) in candidateTracks) {
                            if (android.os.SystemClock.elapsedRealtime() - ytFallbackStartMs > ytResolveBudgetMs) {
                                android.util.Log.w(
                                    "TrackDownloadManager",
                                    "YouTube resolve budget exhausted for $finalTitle by $finalArtist; skipping remaining candidates",
                                )
                                break
                            }
                            // 1. Same waterfall playback uses (cache + multi-client direct URLs).
                            val playbackStream = try {
                                kotlinx.coroutines.withTimeoutOrNull(YT_STREAM_RESOLVE_TIMEOUT_MS) {
                                    innerTube.peekCachedStream(candidateId)
                                        ?: innerTube.resolveAudioStream(candidateId)
                                }
                            } catch (cancelled: CancellationException) {
                                throw cancelled
                            } catch (error: Exception) {
                                lastResolveError = error
                                null
                            }
                            // 2. Opus preference: if playback picked AAC (or failed),
                            // ask NewPipe for the WebM/Opus rendition, which is
                            // remuxed below into a fully tagged .opus file.
                            val opusStream = playbackStream?.takeIf { it.isOpusStream() } ?: try {
                                kotlinx.coroutines.withTimeoutOrNull(YT_STREAM_RESOLVE_TIMEOUT_MS) {
                                    innerTube.resolveDownloadStream(candidateId)
                                }
                            } catch (cancelled: CancellationException) {
                                throw cancelled
                            } catch (error: Exception) {
                                lastResolveError = error
                                null
                            }
                            pickedStream = opusStream?.takeIf { it.isOpusStream() } ?: playbackStream ?: opusStream
                            if (pickedStream != null) {
                                actualVideoId = candidateId
                                resolvedYtVideoId = candidateId
                                chosenTrack = candidateTrack
                                break
                            }
                        }
                        val resolvedStream = pickedStream
                            ?: throw (lastResolveError ?: IOException("No playable YouTube stream for $finalTitle by $finalArtist"))
                        if (resolvedArtworkUrl == null) {
                            resolvedArtworkUrl = (chosenTrack?.artworkUrl ?: preloadedBestMatch?.artworkUrl)
                                ?.takeIf { ArtworkNormalizer.isRealImage(it) }
                        }
                        if (resolvedAlbum == null) resolvedAlbum = (chosenTrack?.album ?: preloadedBestMatch?.album)?.trim()
                            ?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                            ?.takeIf { it.isNotBlank() }
                        val ytStream = resolvedStream
                        resolvedUrl = ytStream.url
                        downloadHeaders = ytStream.requestHeaders
                        expectedContentLength = ytStream.contentLength
                            ?: runCatching { Uri.parse(ytStream.url).getQueryParameter("clen")?.toLongOrNull() }.getOrNull()
                        useParallelDownload = true
                        val rawMime = ytStream.mimeType.orEmpty().lowercase()
                        if (rawMime.contains("mp4") || rawMime.contains("m4a") || rawMime.contains("aac")) {
                            extension = "m4a"
                            mimeType = "audio/mp4"
                            formatBadge = "M4A AAC"
                        } else if (rawMime.contains("webm")) {
                            extension = "webm"
                            mimeType = "audio/webm"
                            formatBadge = "WEBM OPUS"
                        } else if (rawMime.contains("ogg") || rawMime.contains("opus")) {
                            extension = "opus"
                            mimeType = "audio/ogg"
                            formatBadge = "OPUS"
                        } else if (rawMime.contains("mpeg") || rawMime.contains("mp3")) {
                            extension = "mp3"
                            mimeType = "audio/mpeg"
                            formatBadge = "MP3"
                        } else {
                            extension = "m4a"
                            mimeType = "audio/mp4"
                            formatBadge = "AUDIO"
                        }
                        isLossless = false

                        val rawFile = File.createTempFile("dl_raw_", ".$extension", context.cacheDir)
                        tempDownloadFile = rawFile

                        var lastProgress = 0
                        var lastNotifTime = 0L
                        var lastUnknownProgressBytes = 0L
                        val progressLock = Any()
                        val transfer = downloadToTempFile(
                            downloadKey = key,
                            url = checkNotNull(resolvedUrl),
                            target = rawFile,
                            requestHeaders = downloadHeaders,
                            expectedContentLength = expectedContentLength,
                            useParallelRanges = useParallelDownload,
                            onConnectionStateChanged = { isWaiting ->
                                _downloads.value[key]?.let { current ->
                                    val updated = current.copy(isWaitingForConnection = isWaiting)
                                    updateProgress(updated)
                                    runCatching {
                                        showDownloadNotification(
                                            notificationId = notifId,
                                            downloadKey = key,
                                            title = title,
                                            artist = artist,
                                            progress = updated.progressPercent,
                                            isIndeterminate = updated.totalBytes <= 0L,
                                            badgeText = updated.formatBadge,
                                            isWaitingForConnection = isWaiting,
                                        )
                                    }
                                }
                            },
                        ) { downloadedBytes, totalBytes ->
                            synchronized(progressLock) {
                                val now = android.os.SystemClock.uptimeMillis()
                                if (totalBytes > 0) {
                                    val progress = ((downloadedBytes * 100) / totalBytes).toInt().coerceIn(0, 100)
                                    if (progress > lastProgress) {
                                        lastProgress = progress
                                        updateProgress(
                                            DownloadProgress(
                                                key = key, title = title, artist = artist,
                                                progressPercent = progress,
                                                bytesDownloaded = downloadedBytes,
                                                totalBytes = totalBytes,
                                                formatBadge = formatBadge,
                                            ),
                                        )
                                        if (progress == 100 || now - lastNotifTime >= 250L) {
                                            lastNotifTime = now
                                            runCatching {
                                                showDownloadNotification(notifId, key, title, artist, progress, false, formatBadge)
                                            }
                                        }
                                    }
                                } else if (downloadedBytes - lastUnknownProgressBytes >= 1024 * 1024) {
                                    lastUnknownProgressBytes = downloadedBytes
                                    val mbDown = String.format("%.1f MB", downloadedBytes / (1024.0 * 1024.0))
                                    updateProgress(
                                        DownloadProgress(
                                            key = key, title = title, artist = artist,
                                            progressPercent = 0,
                                            bytesDownloaded = downloadedBytes,
                                            totalBytes = -1L,
                                            formatBadge = "$formatBadge • $mbDown",
                                        ),
                                    )
                                    if (now - lastNotifTime >= 500L) {
                                        lastNotifTime = now
                                        runCatching {
                                            showDownloadNotification(notifId, key, title, artist, 0, true, formatBadge)
                                        }
                                    }
                                }
                            }
                        }
                        val contentType = transfer.contentType.lowercase()
                        if (contentType.contains("webm")) {
                            extension = "webm"
                            mimeType = "audio/webm"
                            formatBadge = "WEBM OPUS"
                        } else if (contentType.contains("ogg") || contentType.contains("opus")) {
                            extension = "opus"
                            mimeType = "audio/ogg"
                            formatBadge = "OPUS"
                        } else if (contentType.contains("mpeg") || contentType.contains("mp3")) {
                            extension = "mp3"
                            mimeType = "audio/mpeg"
                            formatBadge = "MP3"
                        } else if (contentType.contains("mp4") || contentType.contains("m4a") || contentType.contains("aac")) {
                            extension = "m4a"
                            mimeType = "audio/mp4"
                            formatBadge = "M4A AAC"
                        }
                        bytesReadTotal = transfer.bytesDownloaded
                        totalBytesRecorded = transfer.totalBytes

                        val detected = detectValidContainer(rawFile)
                        if (detected != null) {
                            // SimpMusic/Metrolist style: accept whatever valid
                            // audio YouTube served (opus/webm/m4a/mp3) — remux
                            // below normalizes it. Never fail on mime mismatch.
                            extension = detected
                            mimeType = when (detected) {
                                "m4a" -> "audio/mp4"
                                "webm" -> "audio/webm"
                                "opus" -> "audio/ogg"
                                "mp3" -> "audio/mpeg"
                                "flac" -> "audio/flac"
                                else -> mimeType
                            }
                        } else if (rawFile.length() < MIN_VALID_AUDIO_BYTES || !hasExpectedContainer(rawFile, extension)) {
                            // Only reject when the payload is not audio at all
                            // (HTML error page / truncated). A valid container
                            // with an unexpected extension is kept.
                            if (detectValidContainer(rawFile) == null && rawFile.length() < MIN_VALID_AUDIO_BYTES) {
                                throw IOException("Downloaded payload is not valid audio (${rawFile.length()} bytes)")
                            }
                        }
                        downloadSucceeded = true
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (ytError: Throwable) {
                        // Surface the real reason (no match vs no stream vs
                        // network) so a playable song never shows a generic skip.
                        val reason = ytError.localizedMessage?.takeIf { it.isNotBlank() }
                            ?: "Stream unavailable"
                        val shortReason = if (reason.length > 90) reason.take(90) + "…" else reason
                        android.util.Log.w("TrackDownloadManager", "YouTube download failed for $title by $artist: $reason", ytError)
                        tempDownloadFile?.let { runCatching { if (it.exists()) it.delete() } }
                        tempDownloadFile = null
                        updateProgress(
                            DownloadProgress(
                                key = key,
                                title = title,
                                artist = artist,
                                progressPercent = 0,
                                error = "Skipped: $shortReason",
                            ),
                        )
                        runCatching {
                            showErrorNotification(notifId, key, title, artist, "Skipped: $shortReason")
                        }
                        return
                    }
                }

                // 3. Proactively start lyrics lookup concurrently with the download
                val shouldDownloadLyrics = runCatching {
                    settingsPreferences.settings.first().downloadLyrics
                }.getOrDefault(true)

                val lyricsDeferred = if (shouldDownloadLyrics) {
                    async(Dispatchers.IO) {
                        runCatching {
                            lyricsRepository.getLyrics(
                                title = finalTitle,
                                artist = finalArtist,
                                album = resolvedAlbum,
                                durationSeconds = null,
                            )
                        }.getOrNull()
                    }
                } else {
                    null
                }

                    val downloadedFile = tempDownloadFile ?: throw IOException("Downloaded file is missing")
                    var currentAudioFile = downloadedFile

                    // Losslessly remux WebM Opus into standard Ogg Opus for universal player & tag compatibility
                    if (extension == "webm") {
                        val opusFile = File.createTempFile("dl_remux_", ".opus", context.cacheDir)
                        if (WebmOpusRemuxer.remux(currentAudioFile, opusFile)) {
                            currentAudioFile.delete()
                            currentAudioFile = opusFile
                            tempDownloadFile = opusFile
                            extension = "opus"
                            mimeType = "audio/ogg"
                            formatBadge = "OPUS"
                        } else {
                            opusFile.delete()
                        }
                    }

                    // 2b. Tidal lossless DASH is FLAC carried inside MP4. Users who
                    // asked for FLAC expect a real .flac file, and an .m4a holding
                    // FLAC reads as "AAC" to players and tag tools. Unwrap the
                    // container losslessly — STREAMINFO from the dfLa box plus the
                    // raw frames from every mdat; nothing is decoded or re-encoded,
                    // so 24-bit hi-res stays bit-exact. On failure the .m4a is kept
                    // rather than losing a completed download.
                    if (dashIsFlacInMp4 && extension == "m4a") {
                        val nativeFlac = File.createTempFile("dl_flac_", ".flac", context.cacheDir)
                        if (Mp4FlacRemuxer.remux(currentAudioFile, nativeFlac)) {
                            runCatching { currentAudioFile.delete() }
                            currentAudioFile = nativeFlac
                            tempDownloadFile = nativeFlac
                            extension = "flac"
                            mimeType = "audio/flac"
                            isLossless = true
                        } else {
                            runCatching { nativeFlac.delete() }
                            android.util.Log.w(
                                "TrackDownloadManager",
                                "FLAC unwrap failed for $title by $artist (codec=$dashManifestCodec); keeping .m4a",
                            )
                        }
                    }

                    // 3a. Served clear? The box-walk proves no sample-encryption
                    // boxes anywhere: bytes are already pure playable audio.
                    // Skip transcode, license and sidecar entirely.
                    val moduleClear = moduleDescriptor?.takeIf { it.drm != null }?.let { desc ->
                        desc.stream.type != "progressive" &&
                            !Mp4EncryptionScanner.isEncrypted(currentAudioFile)
                    } == true

                    // 3b. Module DRM: transcode decrypted PCM into true FLAC so the
                    // stored file plays in any local player. Any failure falls
                    // through to the license-persisted encrypted path below.
                    var transcodedFlac: File? = null
                    val transcodeDesc = moduleDescriptor?.takeIf { it.drm != null && !moduleClear }?.takeIf { desc ->
                        // Extension decides; missing/unreachable policy keeps current behavior.
                        try {
                            moduleResolver.shouldTranscode(desc)
                        } catch (cancellation: CancellationException) {
                            throw cancellation
                        } catch (_: Exception) {
                            true
                        }
                    }
                    if (transcodeDesc != null) {
                        val transResult = try {
                            flacTranscoder.transcodeToFlac(
                                sourceFile = currentAudioFile,
                                descriptor = transcodeDesc,
                                title = finalTitle,
                                artist = finalArtist,
                                album = resolvedAlbum,
                                artworkUri = resolvedArtworkUrl,
                            )
                        } catch (cancellation: CancellationException) {
                            throw cancellation
                        } catch (_: Exception) {
                            null
                        }
                        transcodedFlac = transResult?.file
                        if (transcodedFlac != null) {
                            runCatching { currentAudioFile.delete() }
                            currentAudioFile = transcodedFlac
                            tempDownloadFile = transcodedFlac
                            moduleLicenseDeferred?.cancel()
                            extension = "flac"
                            mimeType = "audio/flac"
                            formatBadge = try {
                                moduleResolver.badgeFor(transcodeDesc, segBridge.audioBadge(transcodeDesc))
                            } catch (cancellation: CancellationException) {
                                throw cancellation
                            } catch (_: Exception) {
                                segBridge.audioBadge(transcodeDesc)
                            }
                            isLossless = true
                        }
                    }

                    val safeFilename = sanitizeFilename("$finalArtist - $finalTitle") + ".$extension"

                    // 4. Resolve exact audio duration from downloaded file
                    val durationRetriever = android.media.MediaMetadataRetriever()
                    try {
                        durationRetriever.setDataSource(currentAudioFile.absolutePath)
                        val durStr = durationRetriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                        durStr?.toLongOrNull()?.takeIf { it > 0 }?.let { durationMs = it }
                        if (resolvedAlbum.isNullOrBlank()) {
                            resolvedAlbum = durationRetriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM)
                                ?.takeIf(String::isNotBlank)
                        }
                    } catch (_: Exception) {
                    } finally {
                        runCatching { durationRetriever.release() }
                    }

                    // 5. Complete lyrics resolution (using concurrent result or duration-assisted fallback)
                    var hasLyrics = false
                    var syncedLyrics: String? = null
                    var plainLyrics: String? = null
                    var lrcPath: String? = null

                    if (shouldDownloadLyrics) {
                        var lyricsRecord = lyricsDeferred?.await()
                        if (lyricsRecord !is LyricsResult.Success && durationMs > 0) {
                            lyricsRecord = runCatching {
                                lyricsRepository.getLyrics(
                                    title = finalTitle,
                                    artist = finalArtist,
                                    album = resolvedAlbum,
                                    durationSeconds = (durationMs / 1000).toInt(),
                                )
                            }.getOrNull()
                        }

                        if (lyricsRecord is LyricsResult.Success) {
                            val lyrics = lyricsRecord
                            syncedLyrics = lyrics.lines.takeIf { lyrics.isSynced && it.isNotEmpty() }
                                ?.joinToString("\n") { line ->
                                    val timeMs = line.timeMs.coerceAtLeast(0L)
                                    String.format(java.util.Locale.ROOT, "[%02d:%02d.%02d]%s",
                                        timeMs / 60_000, timeMs / 1_000 % 60, timeMs / 10 % 100, line.text)
                                }
                            plainLyrics = lyrics.plainLyrics?.takeIf(String::isNotBlank)
                                ?: lyrics.lines.takeIf { it.isNotEmpty() }?.joinToString("\n") { it.text }
                            hasLyrics = !(syncedLyrics.isNullOrBlank() && plainLyrics.isNullOrBlank())
                        }
                    }

                    if (resolvedArtworkUrl == null) {
                        // await() outside runCatching used to fail the whole
                        // download when the artwork fetch itself threw.
                        resolvedArtworkUrl = runCatching { artworkFallback?.await() }.getOrNull()
                    } else {
                        artworkFallback?.cancel()
                    }
                    if (resolvedArtworkUrl == null) {
                        // Last resort (SimpMusic/Metrolist style): the YouTube
                        // thumbnail for the exact downloaded video always exists.
                        resolvedArtworkUrl = resolvedYtVideoId?.takeIf { it.isNotBlank() }
                            ?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
                            ?: preloadedBestMatch?.artworkUrl?.takeIf { ArtworkNormalizer.isRealImage(it) }
                    }

                    // 4. Embed metadata, cover art AND lyrics directly into the
                    // downloaded audio file (container-aware: Vorbis comments +
                    // PICTURE for FLAC/Opus, Matroska tags for WebM,
                    // iTunes atoms for M4A, ID3v2.3 otherwise).
                    val metadataEmbedded = audioTagWriter.embedMetadata(
                        audioFile = currentAudioFile,
                        title = finalTitle,
                        artist = finalArtist,
                        album = resolvedAlbum,
                        artworkUrl = resolvedArtworkUrl,
                        artworkFallbackUrl = preloadedBestMatch?.artworkUrl,
                        lyrics = if (shouldDownloadLyrics) (syncedLyrics ?: plainLyrics) else null,
                        year = year,
                    )
                    if (!metadataEmbedded) {
                        android.util.Log.w("TrackDownloadManager", "Could not safely embed audio metadata; preserving audio file")
                    }

                    // 5. Transfer tagged file to public storage / MediaStore
                    val dirName = sanitizeDownloadFolderName(misc.downloadFolder)
                    val subpath = downloadSubpath(
                        artist = finalArtist,
                        album = resolvedAlbum,
                        year = year,
                        structure = misc.downloadStructure,
                        useAlbumArtist = misc.useAlbumArtistForFolders,
                        primaryOnly = misc.primaryArtistOnly,
                    )
                    ensureDownloadStillAllowed()
                    val (destStream, uri, file) = openPublicOutputStream(
                        filename = safeFilename,
                        mimeType = mimeType,
                        title = finalTitle,
                        artist = finalArtist,
                        album = resolvedAlbum,
                        year = year,
                        durationMs = durationMs,
                        dirName = dirName,
                        subpath = subpath,
                        treeUri = customTreeUri,
                    )
                    destinationUri = uri
                    destinationFile = file
                    if (uri != null) activeUris[key] = uri
                    if (file != null) activeFiles[key] = file

                    val taggedFileLength = currentAudioFile.length()
                    val copiedBytes = currentAudioFile.inputStream().use { input ->
                        destStream.use { output ->
                            val copied = input.copyTo(output, DOWNLOAD_BUFFER_SIZE)
                            output.flush()
                            if (output is FileOutputStream) output.fd.sync()
                            copied
                        }
                    }
                    if (copiedBytes != taggedFileLength) {
                        throw IOException("Public file copy truncated: received $copiedBytes of $taggedFileLength bytes")
                    }

                    // 6. Mark public MediaStore file as finished (IS_PENDING = 0)
                    finalizePublicFile(uri)
                    if (file != null) {
                        MediaScannerConnection.scanFile(
                            context,
                            arrayOf(file.absolutePath),
                            arrayOf(mimeType),
                            null,
                        )
                    }

                    val publicMusicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), dirName)
                    val publicSubdir = if (subpath.isNotBlank()) File(publicMusicDir, subpath) else publicMusicDir
                    val expectedPublicFile = File(publicSubdir, safeFilename)
                    val finalPath = file?.absolutePath
                        ?: expectedPublicFile.takeIf { it.exists() && it.length() > 0 }?.absolutePath
                        ?: uri?.toString()
                        ?: expectedPublicFile.absolutePath


                // 7. Also write the sidecar .lrc companion file for players that read them.
                // Stop before creating lyrics or the database row if a wipe has
                // cancelled this worker; the wipe joins us before it deletes rows.
                ensureDownloadStillAllowed()
                if (shouldDownloadLyrics) {
                    val lyricsText = syncedLyrics ?: plainLyrics
                    if (!lyricsText.isNullOrBlank()) {
                        val lrcFilename = sanitizeFilename("$finalArtist - $finalTitle") + ".lrc"
                        lrcPath = writePublicCompanionFile(lrcFilename, lyricsText, "text/plain", dirName, subpath, customTreeUri)
                    }
                }

                // 6. Persist to Room database (finalKey never embeds counters,
                // so one album can no longer fan out into N artists/albums).
                val entity = DownloadedTrackEntity(
                    trackKey = finalKey,
                    title = finalTitle,
                    artist = finalArtist,
                    album = resolvedAlbum.orEmpty(),
                    artworkUrl = resolvedArtworkUrl,
                    filePath = finalPath,
                    mediaStoreUri = uri?.toString(),
                    fileSizeBytes = currentAudioFile.length(),
                    formatBadge = formatBadge,
                    durationMs = durationMs,
                    isLossless = isLossless,
                    hasLyrics = hasLyrics,
                    syncedLyrics = syncedLyrics,
                    plainLyrics = plainLyrics,
                    lrcFilePath = lrcPath,
                    downloadedAtMillis = System.currentTimeMillis(),
                )
                downloadedTrackDao.insert(entity)

                // 6b. Module DRM: persist offline keys + sidecar so the encrypted
                // file plays without network. Skipped when transcoding already
                // produced a plain FLAC, or the bytes arrived clear (3a).
                if (moduleDescriptor?.drm != null && transcodedFlac == null && !moduleClear) {
                    val drm = moduleDescriptor!!.drm!!
                    val keys = try {
                        moduleLicenseDeferred?.await()
                    } catch (_: Exception) {
                        null
                    } ?: throw IOException("Offline license refused by provider; retry while online")
                    val withKeys = moduleDescriptor!!.copy(drm = drm.copy(keySetIdB64 = keys.keySetIdB64))
                    moduleManager.writeOfflineSidecar(
                        finalTitle, finalArtist,
                        OfflineSidecar(
                            descriptorJson = moduleManager.encodeDescriptor(withKeys),
                            keySetIdB64 = keys.keySetIdB64,
                            licenseUrl = drm.licenseUrl,
                            licenseExpiresAtMs = keys.licenseExpiresAtMs,
                            audioFilePath = finalPath,
                            mediaStoreUri = uri?.toString().orEmpty(),
                            bytes = currentAudioFile.length(),
                            downloadedAtMs = System.currentTimeMillis(),
                        ),
                    )
                }

                updateProgress(
                    DownloadProgress(
                        key = key,
                        title = finalTitle,
                        artist = finalArtist,
                        progressPercent = 100,
                        bytesDownloaded = bytesReadTotal,
                        totalBytes = if (totalBytesRecorded > 0) totalBytesRecorded else bytesReadTotal,
                        formatBadge = formatBadge,
                        isFinished = true,
                    ),
                )

                // Surface missing extras honestly instead of silently:
                // the file is fine, but the user sees what didn't attach.
                val missingExtras = buildList {
                    if (shouldDownloadLyrics && !hasLyrics) add("no lyrics")
                    if (resolvedArtworkUrl == null) add("no art")
                    if (!metadataEmbedded) add("untagged")
                }
                if (missingExtras.isNotEmpty()) {
                    android.util.Log.w(
                        "TrackDownloadManager",
                        "Download complete with missing extras for $finalTitle by $finalArtist: ${missingExtras.joinToString()}",
                    )
                }
                val completedBadge = if (missingExtras.isEmpty()) formatBadge else {
                    "$formatBadge • ${missingExtras.joinToString(" + ")}"
                }
                runCatching { showCompletedNotification(notifId, finalTitle, finalArtist, completedBadge) }
            } catch (cancelled: CancellationException) {
                // Cancelled by user — clean up partial file
                destinationUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
                destinationFile?.let { runCatching { if (it.exists()) it.delete() } }
                notificationManager?.cancel(notifId)
                _downloads.update { it - key }
            } catch (oom: OutOfMemoryError) {
                // Memory pressure (parallel ranges + decoded cover art) used
                // to escape as an uncaught Error and kill the whole process.
                // Fail just this download instead so the app survives.
                android.util.Log.e("TrackDownloadManager", "Out of memory downloading $title", oom)
                destinationUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
                destinationFile?.let { runCatching { if (it.exists()) it.delete() } }
                updateProgress(
                    DownloadProgress(
                        key = key,
                        title = title,
                        artist = artist,
                        error = "Not enough memory — close other apps and download one song at a time",
                    ),
                )
                runCatching {
                    showErrorNotification(notifId, key, title, artist, "Not enough memory — retry one song at a time")
                }
            } catch (error: Exception) {
                destinationUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
                destinationFile?.let { runCatching { if (it.exists()) it.delete() } }
                updateProgress(
                    DownloadProgress(
                        key = key,
                        title = title,
                        artist = artist,
                        error = error.localizedMessage ?: error.message ?: "Download failed",
                    ),
                )
                runCatching {
                    showErrorNotification(notifId, key, title, artist, error.localizedMessage ?: "Failed")
                }
            } finally {
                runCatching { downloadSlots.release() }
                activeKeys.remove(key)
                activeJobs.remove(key)
                activeUris.remove(key)
                activeFiles.remove(key)
                reconnectGenerations.remove(key)
                tempDownloadFile?.let { runCatching { if (it.exists()) it.delete() } }
            }
    }

    private suspend fun downloadToTempFile(
        downloadKey: String,
        url: String,
        target: File,
        requestHeaders: Map<String, String>,
        expectedContentLength: Long?,
        useParallelRanges: Boolean,
        onConnectionStateChanged: (Boolean) -> Unit,
        onProgress: (downloadedBytes: Long, totalBytes: Long) -> Unit,
    ): DownloadTransfer {
        val parallelLength = expectedContentLength
            ?.takeIf { useParallelRanges && it >= MIN_PARALLEL_DOWNLOAD_BYTES }
        if (parallelLength != null) {
            try {
                return downloadInParallel(
                    url = url,
                    target = target,
                    requestHeaders = requestHeaders,
                    totalLength = parallelLength,
                    downloadKey = downloadKey,
                    onConnectionStateChanged = onConnectionStateChanged,
                    onProgress = onProgress,
                )
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Exception) {
                android.util.Log.w(
                    "TrackDownloadManager",
                    "Validated range download unavailable; using one stream",
                    error,
                )
                truncateFile(target)
            }
        }

        return downloadSingleStream(
            downloadKey = downloadKey,
            url = url,
            target = target,
            requestHeaders = requestHeaders,
            expectedContentLength = expectedContentLength,
            onConnectionStateChanged = onConnectionStateChanged,
            onProgress = onProgress,
        )
    }

    private suspend fun downloadInParallel(
        url: String,
        target: File,
        requestHeaders: Map<String, String>,
        totalLength: Long,
        downloadKey: String,
        onConnectionStateChanged: (Boolean) -> Unit,
        onProgress: (downloadedBytes: Long, totalBytes: Long) -> Unit,
    ): DownloadTransfer = coroutineScope {
        val partSize = (totalLength + PARALLEL_YOUTUBE_PARTS - 1L) / PARALLEL_YOUTUBE_PARTS
        val ranges = (0 until PARALLEL_YOUTUBE_PARTS).mapNotNull { index ->
            val start = index * partSize
            if (start >= totalLength) return@mapNotNull null
            DownloadRange(start, minOf(totalLength - 1L, start + partSize - 1L))
        }
        RandomAccessFile(target, "rw").use { it.setLength(totalLength) }

        val downloadedBytes = AtomicLong(0L)
        val waitingRanges = AtomicInteger(0)
        val rangeConnectionStateChanged: (Boolean) -> Unit = { isWaiting ->
            val waitingCount = if (isWaiting) {
                waitingRanges.incrementAndGet()
            } else {
                waitingRanges.updateAndGet { count -> (count - 1).coerceAtLeast(0) }
            }
            onConnectionStateChanged(waitingCount > 0)
        }
        val contentTypes = ranges.map { range ->
            async {
                var downloadedBytesInRange = 0L
                retryInterruptedTransfer(downloadKey, rangeConnectionStateChanged) {
                    downloadRange(
                        url = url,
                        target = target,
                        requestHeaders = requestHeaders,
                        range = DownloadRange(range.start + downloadedBytesInRange, range.endInclusive),
                        expectedTotal = totalLength,
                    ) { delta ->
                        downloadedBytesInRange += delta
                        onProgress(downloadedBytes.addAndGet(delta.toLong()), totalLength)
                    }
                }
            }
        }.awaitAll()

        val finalLength = downloadedBytes.get()
        if (finalLength != totalLength || target.length() != totalLength) {
            throw IOException("Parallel download truncated: received $finalLength of $totalLength bytes")
        }
        RandomAccessFile(target, "rw").use { it.fd.sync() }
        DownloadTransfer(
            bytesDownloaded = finalLength,
            totalBytes = totalLength,
            contentType = contentTypes.firstOrNull { it.isNotBlank() }.orEmpty(),
        )
    }

    private suspend fun downloadRange(
        url: String,
        target: File,
        requestHeaders: Map<String, String>,
        range: DownloadRange,
        expectedTotal: Long,
        onBytesRead: (Int) -> Unit,
    ): String = suspendCancellableCoroutine { continuation ->
        val request = buildDownloadRequest(url, requestHeaders, range)
        val call = downloadClient.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val contentType = response.use { currentResponse ->
                        validateMediaResponse(currentResponse, expectedCode = 206)
                        val parsedRange = parseContentRange(currentResponse.header("Content-Range"))
                            ?: throw DownloadProtocolException("Missing Content-Range for parallel download")
                        if (parsedRange.start != range.start ||
                            parsedRange.endInclusive != range.endInclusive ||
                            parsedRange.total != expectedTotal
                        ) {
                            throw DownloadProtocolException("Mismatched Content-Range ${currentResponse.header("Content-Range")}")
                        }

                        val body = currentResponse.body
                            ?: throw DownloadProtocolException("Empty range response body")
                        val bodyLength = body.contentLength()
                        if (bodyLength > 0L && bodyLength != range.length) {
                            throw DownloadProtocolException("Range length mismatch: received $bodyLength of ${range.length} bytes")
                        }

                        RandomAccessFile(target, "rw").use { output ->
                            output.seek(range.start)
                            body.byteStream().use { input ->
                                val buffer = ByteArray(DOWNLOAD_BUFFER_SIZE)
                                var remaining = range.length
                                while (remaining > 0L) {
                                    if (!continuation.isActive) throw CancellationException("Download cancelled")
                                    val read = try {
                                        input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                                    } catch (error: IOException) {
                                        throw DownloadInterruptedException("Connection interrupted while reading audio", error)
                                    }
                                    if (read < 0) {
                                        throw DownloadInterruptedException("Range truncated with $remaining bytes remaining")
                                    }
                                    output.write(buffer, 0, read)
                                    remaining -= read
                                    onBytesRead(read)
                                }
                            }
                        }
                        currentResponse.header("Content-Type").orEmpty()
                    }
                    if (continuation.isActive) continuation.resume(contentType)
                } catch (error: Exception) {
                    if (continuation.isActive) continuation.resumeWithException(error)
                }
            }
        })
    }

    private suspend fun downloadSingleStream(
        downloadKey: String,
        url: String,
        target: File,
        requestHeaders: Map<String, String>,
        expectedContentLength: Long?,
        onConnectionStateChanged: (Boolean) -> Unit,
        onProgress: (downloadedBytes: Long, totalBytes: Long) -> Unit,
    ): DownloadTransfer {
        val expectedLength = expectedContentLength?.takeIf { it > 0L }
        return retryInterruptedTransfer(downloadKey, onConnectionStateChanged) {
            if (expectedLength != null && target.length() > expectedLength) truncateFile(target)
            if (expectedLength != null && target.length() == expectedLength && expectedLength >= MIN_VALID_AUDIO_BYTES) {
                onProgress(expectedLength, expectedLength)
                return@retryInterruptedTransfer DownloadTransfer(expectedLength, expectedLength, "")
            }
            downloadSingleStreamAttempt(
                url = url,
                target = target,
                requestHeaders = requestHeaders,
                expectedContentLength = expectedLength,
                onProgress = onProgress,
            )
        }
    }

    private suspend fun downloadSingleStreamAttempt(
        url: String,
        target: File,
        requestHeaders: Map<String, String>,
        expectedContentLength: Long?,
        onProgress: (downloadedBytes: Long, totalBytes: Long) -> Unit,
    ): DownloadTransfer = suspendCancellableCoroutine { continuation ->
        val resumeOffset = target.length().coerceAtLeast(0L)
        val call = downloadClient.newCall(
            buildDownloadRequest(url, requestHeaders, range = null, resumeOffset = resumeOffset),
        )
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val transfer = response.use { currentResponse ->
                        validateMediaResponse(currentResponse)
                        val body = currentResponse.body
                            ?: throw DownloadProtocolException("Empty response body")
                        val responseLength = body.contentLength().takeIf { it > 0L }
                        val partialRange = if (currentResponse.code == 206) {
                            parseContentRange(currentResponse.header("Content-Range"))
                                ?: throw DownloadProtocolException("Missing Content-Range for partial response")
                        } else {
                            null
                        }
                        if (partialRange != null && (partialRange.start != resumeOffset ||
                                partialRange.endInclusive + 1L != partialRange.total)
                        ) {
                            throw DownloadProtocolException("Server returned an unexpected audio range")
                        }
                        if (partialRange != null && expectedContentLength != null &&
                            partialRange.total != expectedContentLength
                        ) {
                            throw DownloadProtocolException(
                                "Download size changed: expected $expectedContentLength, received ${partialRange.total}",
                            )
                        }

                        val totalLength = partialRange?.total
                            ?: responseLength
                            ?: expectedContentLength?.takeIf { it > 0L }
                            ?: -1L
                        if (responseLength != null && expectedContentLength != null &&
                            currentResponse.code == 200 && responseLength != expectedContentLength
                        ) {
                            throw DownloadProtocolException(
                                "Download size changed: expected $expectedContentLength, received $responseLength",
                            )
                        }

                        val append = resumeOffset > 0L && partialRange != null
                        var downloadedBytes = if (append) resumeOffset else 0L
                        FileOutputStream(target, append).use { output ->
                            body.byteStream().use { input ->
                                val buffer = ByteArray(DOWNLOAD_BUFFER_SIZE)
                                while (true) {
                                    if (!continuation.isActive) throw CancellationException("Download cancelled")
                                    val read = try {
                                        input.read(buffer)
                                    } catch (error: IOException) {
                                        throw DownloadInterruptedException("Connection interrupted while reading audio", error)
                                    }
                                    if (read < 0) break
                                    output.write(buffer, 0, read)
                                    downloadedBytes += read
                                    onProgress(downloadedBytes, totalLength)
                                }
                            }
                            output.flush()
                            output.fd.sync()
                        }
                        if (downloadedBytes < MIN_VALID_AUDIO_BYTES) {
                            throw DownloadProtocolException("Downloaded audio payload is too small")
                        }
                        if (totalLength > 0L && downloadedBytes != totalLength) {
                            if (downloadedBytes < totalLength) {
                                throw DownloadInterruptedException(
                                    "Download truncated: received $downloadedBytes of $totalLength bytes",
                                )
                            }
                            throw DownloadProtocolException(
                                "Download exceeded expected size: received $downloadedBytes of $totalLength bytes",
                            )
                        }

                        DownloadTransfer(
                            bytesDownloaded = downloadedBytes,
                            totalBytes = totalLength.takeIf { it > 0L } ?: downloadedBytes,
                            contentType = currentResponse.header("Content-Type").orEmpty(),
                        )
                    }
                    if (continuation.isActive) continuation.resume(transfer)
                } catch (error: Exception) {
                    if (continuation.isActive) continuation.resumeWithException(error)
                }
            }
        })
    }

    private data class ParsedDashManifest(
        val initUrl: String,
        val mediaTemplate: String,
        val segmentCount: Int,
        val startNumber: Int = 1,
        /**
         * The Representation's declared codec, e.g. `flac`, `mp4a.40.2`, `ec-3`.
         * Tidal serves AAC for the LOW/HIGH tiers and FLAC-in-MP4 for lossless,
         * so the manifest — not the descriptor's assumption — decides whether a
         * download really is lossless.
         */
        val codec: String = "",
    )

    private fun parseTidalDashManifest(baseUrl: String): ParsedDashManifest? = runCatching {
        val trimmed = baseUrl.trim()
        val xmlStr = when {
            trimmed.startsWith("data:application/dash+xml") -> {
                if (trimmed.contains("base64,")) {
                    val b64 = trimmed.substringAfter("base64,")
                    String(android.util.Base64.decode(b64, android.util.Base64.DEFAULT), Charsets.UTF_8)
                } else {
                    java.net.URLDecoder.decode(trimmed.substringAfter(","), "UTF-8")
                }
            }
            trimmed.startsWith("<?xml") || trimmed.startsWith("<MPD") -> trimmed
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> {
                if (trimmed.contains(".mpd", ignoreCase = true) || trimmed.contains("dash", ignoreCase = true)) {
                    val req = Request.Builder().url(trimmed).get().build()
                    downloadClient.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) resp.body?.string().orEmpty() else ""
                    }
                } else ""
            }
            else -> return@runCatching null
        }
        if (xmlStr.isBlank()) return@runCatching null

        val initMatch = Regex("""initialization=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?: Regex("""<Initialization\s+[^>]*sourceURL=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?: Regex("""sourceURL=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?: return@runCatching null
        var initUrl = initMatch.groupValues[1].replace("&amp;", "&")

        val mediaMatch = Regex("""media=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?: Regex("""<SegmentTemplate\s+[^>]*media=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?: Regex("""<SegmentURL\s+[^>]*media=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?: return@runCatching null
        var mediaTemplate = mediaMatch.groupValues[1].replace("&amp;", "&")

        val baseMatch = Regex("""<BaseURL[^>]*>([^<]+)</BaseURL>""", RegexOption.IGNORE_CASE).find(xmlStr)
        val baseUrlPrefix = baseMatch?.groupValues?.get(1)?.trim()?.replace("&amp;", "&")
            ?: if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
                trimmed.substringBeforeLast('/') + "/"
            } else null
        if (!baseUrlPrefix.isNullOrBlank()) {
            if (!initUrl.startsWith("http://", ignoreCase = true) && !initUrl.startsWith("https://", ignoreCase = true)) {
                initUrl = if (baseUrlPrefix.endsWith("/") || initUrl.startsWith("/")) {
                    "${baseUrlPrefix.trimEnd('/')}/${initUrl.trimStart('/')}"
                } else {
                    "$baseUrlPrefix$initUrl"
                }
            }
            if (!mediaTemplate.startsWith("http://", ignoreCase = true) && !mediaTemplate.startsWith("https://", ignoreCase = true)) {
                mediaTemplate = if (baseUrlPrefix.endsWith("/") || mediaTemplate.startsWith("/")) {
                    "${baseUrlPrefix.trimEnd('/')}/${mediaTemplate.trimStart('/')}"
                } else {
                    "$baseUrlPrefix$mediaTemplate"
                }
            }
        }
        if (!initUrl.startsWith("http://", ignoreCase = true) && !initUrl.startsWith("https://", ignoreCase = true)) {
            return@runCatching null
        }
        if (!mediaTemplate.startsWith("http://", ignoreCase = true) && !mediaTemplate.startsWith("https://", ignoreCase = true)) {
            return@runCatching null
        }

        val codec = Regex("""codecs=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            ?.groupValues
            ?.get(1)
            ?.trim()
            ?.lowercase()
            .orEmpty()

        var count = 0
        val sRegex = Regex("""<S\s+[^>]*>""", RegexOption.IGNORE_CASE)
        for (match in sRegex.findAll(xmlStr)) {
            val sTag = match.value
            val rMatch = Regex("""r=["']?(\d+)["']?""", RegexOption.IGNORE_CASE).find(sTag)
            val r = rMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0
            count += 1 + r
        }
        if (count <= 0) {
            val durationMatch = Regex("""mediaPresentationDuration=["']PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?["']""", RegexOption.IGNORE_CASE).find(xmlStr)
            val segTemplateMatch = Regex("""<(?:SegmentTemplate|SegmentList)\b[^>]*>""", RegexOption.IGNORE_CASE).find(xmlStr)?.value
            val segDuration = segTemplateMatch?.let { Regex("""\bduration=["']([0-9.]+)["']""", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.toDoubleOrNull() } ?: 1.0
            val timescale = segTemplateMatch?.let { Regex("""\btimescale=["']([0-9.]+)["']""", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.toDoubleOrNull() } ?: 1.0
            if (durationMatch != null) {
                val hours = durationMatch.groupValues.getOrNull(1)?.toDoubleOrNull() ?: 0.0
                val min = durationMatch.groupValues.getOrNull(2)?.toDoubleOrNull() ?: 0.0
                val sec = durationMatch.groupValues.getOrNull(3)?.toDoubleOrNull() ?: 0.0
                val totalSec = hours * 3600.0 + min * 60.0 + sec
                val segSec = segDuration / timescale
                if (segSec > 0) {
                    count = Math.ceil(totalSec / segSec).toInt()
                }
            }
        }
        if (count <= 0) count = 50
        val startNumberMatch = Regex("""startNumber=["'](\d+)["']""", RegexOption.IGNORE_CASE).find(xmlStr)
        val startNumber = startNumberMatch?.groupValues?.get(1)?.toIntOrNull() ?: 1

        ParsedDashManifest(
            initUrl = initUrl,
            mediaTemplate = mediaTemplate,
            segmentCount = count,
            startNumber = startNumber,
            codec = codec,
        )
    }.getOrNull()

    private data class DashFetchResult(
        val bytesWritten: Long,
        val stoppedEarly: Boolean,
        val completedSegments: Int,
        val expectedSegments: Int,
    )

    private suspend fun downloadDashSegmentsToTempFile(
        downloadKey: String,
        notificationId: Int,
        title: String,
        artist: String,
        formatBadge: String,
        initUrl: String,
        mediaTemplate: String,
        segmentCount: Int,
        startNumber: Int = 1,
        headers: Map<String, String>,
        target: File,
    ): DashFetchResult = withContext(Dispatchers.IO) {
        val totalParts = segmentCount + 1
        var completedParts = 0
        var totalBytesWritten = 0L
        var stoppedEarly = false
        val targetStream = FileOutputStream(target, false)

        try {
            // 1. Download initialization segment (0.mp4) containing ftyp and moov boxes
            val initReq = Request.Builder()
                .url(initUrl)
                .apply {
                    headers.forEach { (k, v) -> addHeader(k, v) }
                    if (headers.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
                        addHeader("User-Agent", DOWNLOAD_USER_AGENT)
                    }
                }
                .build()

            downloadClient.newCall(initReq).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("Failed to download DASH init chunk: HTTP ${resp.code}")
                val body = resp.body ?: throw IOException("Empty DASH init body")
                val copied = body.byteStream().copyTo(targetStream, DOWNLOAD_BUFFER_SIZE)
                totalBytesWritten += copied
            }
            completedParts++
            val initPercent = ((completedParts * 100) / totalParts).coerceIn(0, 100)
            updateProgress(
                DownloadProgress(
                    key = downloadKey, title = title, artist = artist,
                    progressPercent = initPercent,
                    bytesDownloaded = totalBytesWritten,
                    formatBadge = formatBadge,
                )
            )

            // 2. Download media segments in order and append directly to the file
            val endNumber = startNumber + segmentCount - 1
            for (segIndex in startNumber..endNumber) {
                currentCoroutineContext().ensureActive()
                val segUrl = mediaTemplate.replace(Regex("""\${'$'}Number(?:%0(\d+)d)?\${'$'}""")) { m ->
                    val pad = m.groupValues.getOrNull(1)?.toIntOrNull()
                    if (pad != null) segIndex.toString().padStart(pad, '0') else segIndex.toString()
                }
                val segReq = Request.Builder()
                    .url(segUrl)
                    .apply {
                        headers.forEach { (k, v) -> addHeader(k, v) }
                        if (headers.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
                            addHeader("User-Agent", DOWNLOAD_USER_AGENT)
                        }
                    }
                    .build()

                var stopThis = false
                downloadClient.newCall(segReq).execute().use { resp ->
                    if (resp.code == 404 && segIndex > startNumber) {
                        stopThis = true
                        stoppedEarly = true
                        return@use
                    }
                    if (!resp.isSuccessful) throw IOException("Failed to download DASH segment $segIndex: HTTP ${resp.code}")
                    val body = resp.body ?: throw IOException("Empty body for DASH segment $segIndex")
                    val copied = body.byteStream().copyTo(targetStream, DOWNLOAD_BUFFER_SIZE)
                    totalBytesWritten += copied
                }
                if (stopThis) break

                completedParts++
                val percent = ((completedParts * 100) / totalParts).coerceIn(0, 100)
                updateProgress(
                    DownloadProgress(
                        key = downloadKey, title = title, artist = artist,
                        progressPercent = percent,
                        bytesDownloaded = totalBytesWritten,
                        totalBytes = -1L,
                        formatBadge = formatBadge,
                    )
                )
                if (percent % 10 == 0 || segIndex == segmentCount) {
                    runCatching {
                        showDownloadNotification(notificationId, downloadKey, title, artist, percent, false, formatBadge)
                    }
                }
            }
            targetStream.flush()
            targetStream.fd.sync()
            DashFetchResult(
                bytesWritten = totalBytesWritten,
                stoppedEarly = stoppedEarly,
                completedSegments = completedParts - 1,
                expectedSegments = segmentCount,
            )
        } finally {
            runCatching { targetStream.close() }
        }
    }

    private suspend fun <T> retryInterruptedTransfer(
        downloadKey: String,
        onConnectionStateChanged: (Boolean) -> Unit,
        transfer: suspend () -> T,
    ): T {
        var failureCount = 0
        while (true) {
            try {
                return transfer()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: IOException) {
                if (!error.isReconnectableTransferFailure()) throw error
                failureCount++
                // Bounded: an endlessly failing URL used to retry forever and
                // freeze the download (and its slot). Offline periods still
                // wait inside awaitRetryOpportunity, costing one attempt each.
                if (failureCount > MAX_TRANSFER_RETRIES) throw error
                onConnectionStateChanged(true)
                try {
                    awaitRetryOpportunity(downloadKey, failureCount)
                } finally {
                    onConnectionStateChanged(false)
                }
            }
        }
    }

    private suspend fun awaitRetryOpportunity(downloadKey: String, failureCount: Int) {
        val reconnectGeneration = reconnectGenerations[downloadKey]
            ?: throw CancellationException("Download cancelled")
        val observedGeneration = reconnectGeneration.get()
        val retryDelayMs = (RECONNECT_RETRY_BASE_DELAY_MS *
            (1L shl (failureCount - 1).coerceIn(0, 5)))
            .coerceAtMost(RECONNECT_RETRY_MAX_DELAY_MS)
        var elapsedMs = 0L
        while (true) {
            currentCoroutineContext().ensureActive()
            if (reconnectGeneration.get() != observedGeneration) return
            if (elapsedMs >= retryDelayMs && hasUsableNetwork()) return
            delay(RECONNECT_POLL_INTERVAL_MS)
            elapsedMs += RECONNECT_POLL_INTERVAL_MS
        }
    }

    private fun hasUsableNetwork(): Boolean = runCatching {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return@runCatching true
        val network = manager.activeNetwork ?: return@runCatching false
        val capabilities = manager.getNetworkCapabilities(network) ?: return@runCatching false
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }.getOrDefault(true)

    private fun IOException.isReconnectableTransferFailure(): Boolean {
        if (this is DownloadProtocolException) return false
        if (this is DownloadHttpException) {
            return statusCode == 408 || statusCode == 425 || statusCode == 429 || statusCode in 500..599
        }
        return generateSequence<Throwable>(this) { it.cause }
            .take(8)
            .any {
                it is DownloadInterruptedException ||
                    it is EOFException ||
                    it is ConnectException ||
                    it is NoRouteToHostException ||
                    it is SocketException ||
                    it is UnknownHostException ||
                    it is InterruptedIOException
            }
    }

    private fun buildDownloadRequest(
        url: String,
        requestHeaders: Map<String, String>,
        range: DownloadRange?,
        resumeOffset: Long = 0L,
    ): Request {
        val builder = Request.Builder().url(url)
        requestHeaders.forEach { (name, value) -> builder.header(name, value) }
        if (requestHeaders.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
            builder.header("User-Agent", DOWNLOAD_USER_AGENT)
        }
        builder.header("Accept", "*/*")
        builder.header("Accept-Encoding", "identity")
        when {
            range != null -> builder.header("Range", "bytes=${range.start}-${range.endInclusive}")
            resumeOffset > 0L -> builder.header("Range", "bytes=$resumeOffset-")
        }
        return builder.build()
    }

    private fun validateMediaResponse(response: Response, expectedCode: Int? = null) {
        if (response.code != 200 && response.code != 206) {
            throw DownloadHttpException(response.code)
        }
        if (expectedCode != null && response.code != expectedCode) {
            throw DownloadProtocolException("Server does not support resumable byte ranges")
        }

        val contentType = response.header("Content-Type").orEmpty().lowercase()
        if (contentType.contains("text/html") ||
            contentType.contains("application/json") ||
            contentType.contains("text/plain")
        ) {
            throw DownloadProtocolException("Invalid download payload ($contentType)")
        }
    }

    private fun parseContentRange(header: String?): ParsedContentRange? {
        val match = header?.trim()?.let(CONTENT_RANGE_PATTERN::matchEntire) ?: return null
        return ParsedContentRange(
            start = match.groupValues[1].toLongOrNull() ?: return null,
            endInclusive = match.groupValues[2].toLongOrNull() ?: return null,
            total = match.groupValues[3].toLongOrNull() ?: return null,
        )
    }

    private fun truncateFile(file: File) {
        RandomAccessFile(file, "rw").use { it.setLength(0L) }
    }

    private fun isDashUrl(url: String, mime: String = ""): Boolean {
        val trimmed = url.trimStart()
        return trimmed.startsWith("data:application/dash+xml") ||
            trimmed.startsWith("<?xml") ||
            trimmed.startsWith("<MPD") ||
            url.contains(".mpd", ignoreCase = true) ||
            mime.contains("dash", ignoreCase = true)
    }

    private fun detectValidContainer(file: File): String? = runCatching {
        if (file.length() < 12L) return@runCatching null
        val header = ByteArray(12)
        RandomAccessFile(file, "r").use { input ->
            if (input.read(header) != header.size) return@runCatching null
        }
        when {
            header.copyOfRange(0, 4).contentEquals(byteArrayOf('f'.code.toByte(), 'L'.code.toByte(), 'a'.code.toByte(), 'C'.code.toByte())) -> "flac"
            header.copyOfRange(4, 8).contentEquals(byteArrayOf('f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte())) -> "m4a"
            header.copyOfRange(0, 4).contentEquals(byteArrayOf(0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte())) -> "webm"
            header.copyOfRange(0, 4).contentEquals(byteArrayOf('O'.code.toByte(), 'g'.code.toByte(), 'g'.code.toByte(), 'S'.code.toByte())) -> "opus"
            header.copyOfRange(0, 3).contentEquals(byteArrayOf('I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte())) ||
                ((header[0].toInt() and 0xFF) == 0xFF && (header[1].toInt() and 0xE0) == 0xE0) -> "mp3"
            else -> null
        }
    }.getOrNull()

    private fun hasExpectedContainer(file: File, extension: String): Boolean = runCatching {
        if (file.length() < 12L) return@runCatching false
        val detected = detectValidContainer(file) ?: return@runCatching false
        val ext = extension.lowercase()
        when (ext) {
            "flac" -> detected == "flac"
            "m4a" -> detected == "m4a"
            "webm" -> detected == "webm"
            "opus" -> detected == "opus" || detected == "webm"
            "ogg" -> detected == "opus"
            "mp3" -> detected == "mp3"
            else -> false
        }
    }.getOrDefault(false)

    /**
     * Mirrors playback's spatial check (`MusicPlayer.isSpatialAudioSupportedOnDevice`):
     * hardware decoder, bundled FFmpeg decoder, or Android S_V2+ Spatializer.
     */
    private fun isAtmosCapableDevice(): Boolean = runCatching {
        val decoder = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.any { info ->
            !info.isEncoder && info.supportedTypes.any { type ->
                type.equals("audio/eac3-joc", ignoreCase = true) ||
                    type.equals("audio/eac3", ignoreCase = true) ||
                    type.equals("audio/ac3", ignoreCase = true)
            }
        }
        val ffmpeg = runCatching {
            androidx.media3.decoder.ffmpeg.FfmpegLibrary.isAvailable() &&
                androidx.media3.decoder.ffmpeg.FfmpegLibrary.supportsFormat(androidx.media3.common.MimeTypes.AUDIO_E_AC3)
        }.getOrDefault(false)
        if (decoder || ffmpeg) return@runCatching true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S_V2) {
            val am = context.getSystemService(AudioManager::class.java)
            val spatializer = am?.spatializer
            if (spatializer != null && (spatializer.isAvailable || spatializer.isEnabled)) {
                return@runCatching true
            }
        }
        false
    }.getOrDefault(false)

    private fun updateProgress(progress: DownloadProgress) {
        _downloads.update { it + (progress.key to progress) }
    }

    private fun openPublicOutputStream(
        filename: String,
        mimeType: String,
        title: String,
        artist: String,
        album: String?,
        year: String? = null,
        durationMs: Long = 0L,
        dirName: String = PUBLIC_DIR_NAME,
        subpath: String = "",
        treeUri: Uri? = null,
    ): Triple<java.io.OutputStream, Uri?, File?> {
        val resolver = context.contentResolver
        val safeDir = sanitizeDownloadFolderName(dirName)
        val safeSubpath = subpath.split('/').map { sanitizeFilename(it.trim()) }
            .filter { it.isNotBlank() }.joinToString("/")
        val audioRelativePath = if (safeSubpath.isNotBlank()) {
            "${Environment.DIRECTORY_MUSIC}/$safeDir/$safeSubpath"
        } else {
            "${Environment.DIRECTORY_MUSIC}/$safeDir"
        }

        // Custom SAF folder (SD card etc.): write straight into the user's
        // chosen tree, honoring the same artist/album subfolders. Any failure
        // throws so the download surfaces an error instead of silently
        // landing in internal storage.
        if (treeUri != null) {
            val segments = safeSubpath.split('/').filter { it.isNotBlank() }
            val audioMime = when {
                mimeType.contains("mp4") || mimeType.contains("m4a") || mimeType.contains("aac") -> "audio/mp4"
                mimeType.contains("flac") -> "audio/flac"
                mimeType.contains("mp3") || mimeType.contains("mpeg") -> "audio/mpeg"
                mimeType.contains("webm") -> "audio/webm"
                mimeType.contains("ogg") || mimeType.contains("opus") -> "audio/ogg"
                mimeType.contains("wav") -> "audio/x-wav"
                else -> "audio/mp4"
            }
            val safUri = SafTreeFiles.createFile(context, treeUri, segments, filename, audioMime)
                ?: throw IOException("Custom download folder unavailable — reselect it in Downloads → Download location")
            val stream = SafTreeFiles.openWriteStream(context, safUri)
                ?: throw IOException("Could not write to the custom download folder")
            return Triple(stream, safUri, null)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android MediaStore Audio only accepts standard audio MIME types
            val audioMime = when {
                mimeType.contains("mp4") || mimeType.contains("m4a") || mimeType.contains("aac") -> "audio/mp4"
                mimeType.contains("flac") -> "audio/flac"
                mimeType.contains("mp3") || mimeType.contains("mpeg") -> "audio/mpeg"
                mimeType.contains("webm") -> "audio/webm"
                mimeType.contains("ogg") || mimeType.contains("opus") -> "audio/ogg"
                mimeType.contains("wav") -> "audio/x-wav"
                else -> "audio/mp4"
            }

            // Remove any pre-existing entry with the same filename IN THE SAME
            // FOLDER to avoid Android appending (1), (2), etc. Scoped to the
            // relative path so identically-named tracks in other album folders survive.
            runCatching {
                resolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Audio.Media._ID),
                    "${MediaStore.Audio.Media.DISPLAY_NAME} = ? AND ${MediaStore.Audio.Media.RELATIVE_PATH} = ?",
                    arrayOf(filename, "$audioRelativePath/"),
                    null,
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val oldUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                        runCatching { resolver.delete(oldUri, null, null) }
                    }
                }
            }

            val audioContentValues = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, filename)
                put(MediaStore.Audio.Media.MIME_TYPE, audioMime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, audioRelativePath)
                put(MediaStore.Audio.Media.TITLE, title)
                put(MediaStore.Audio.Media.ARTIST, artist)
                put(MediaStore.Audio.Media.ALBUM_ARTIST, artist)
                if (!album.isNullOrBlank()) put(MediaStore.Audio.Media.ALBUM, album)
                val yearInt = year?.filter { it.isDigit() }?.take(4)?.toIntOrNull()
                if (yearInt != null && yearInt > 0) {
                    put(MediaStore.Audio.Media.YEAR, yearInt)
                }
                if (durationMs > 0) put(MediaStore.Audio.Media.DURATION, durationMs)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }

            val audioUri = runCatching { resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, audioContentValues) }.getOrNull()
            if (audioUri != null) {
                val stream = resolver.openOutputStream(audioUri, "wt")
                    ?: resolver.openOutputStream(audioUri)
                if (stream != null) return Triple(stream, audioUri, null)
            }

            // Fallback 1: MediaStore.Downloads (pure download columns only)
            val downloadsRelativePath = if (safeSubpath.isNotBlank()) {
                "${Environment.DIRECTORY_DOWNLOADS}/$safeDir/Music/$safeSubpath"
            } else {
                "${Environment.DIRECTORY_DOWNLOADS}/$safeDir/Music"
            }
            val downloadContentValues = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, if (mimeType.isNotBlank()) mimeType else "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, downloadsRelativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val downloadUri = runCatching { resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, downloadContentValues) }.getOrNull()
            if (downloadUri != null) {
                val stream = resolver.openOutputStream(downloadUri, "wt")
                    ?: resolver.openOutputStream(downloadUri)
                if (stream != null) return Triple(stream, downloadUri, null)
            }

            // Fallback 2: Direct public / external app music directory
            val fallbackBase = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
                ?: File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), safeDir).apply { if (!exists()) mkdirs() }
            val fallbackDir = if (safeSubpath.isNotBlank()) File(fallbackBase, safeSubpath) else fallbackBase
            if (!fallbackDir.exists()) fallbackDir.mkdirs()
            val fallbackFile = File(fallbackDir, filename)
            val stream = FileOutputStream(fallbackFile)
            return Triple(stream, null, fallbackFile)
        } else {
            // Android 9 and below
            val musicBase = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), safeDir)
            val musicDir = if (safeSubpath.isNotBlank()) File(musicBase, safeSubpath) else musicBase
            if (!musicDir.exists()) musicDir.mkdirs()
            val file = File(musicDir, filename)
            val stream = FileOutputStream(file)
            return Triple(stream, null, file)
        }
    }


    private fun finalizePublicFile(uri: Uri?) {
        // IS_PENDING only exists on MediaStore Uris — SAF document Uris are
        // already visible once the stream closes.
        if (uri != null && uri.authority == MediaStore.AUTHORITY && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            runCatching { context.contentResolver.update(uri, contentValues, null, null) }
        }
    }

    private fun showDownloadNotification(
        notificationId: Int,
        downloadKey: String,
        title: String,
        artist: String,
        progress: Int,
        isIndeterminate: Boolean,
        badgeText: String,
        isWaitingForConnection: Boolean = false,
    ) {
        val cancelIntent = Intent(context, DownloadCancelReceiver::class.java).apply {
            action = ACTION_CANCEL_DOWNLOAD
            putExtra(EXTRA_DOWNLOAD_KEY, downloadKey)
        }
        val cancelPendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0),
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (isWaitingForConnection) "Waiting for connection" else "Downloading \"$title\"")
            .setContentText(
                if (isWaitingForConnection) "\"$title\" by $artist \u2022 $progress% saved"
                else "$artist \u2022 $badgeText ($progress%)",
            )
            .setProgress(100, progress, isIndeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(viewDownloadsPendingIntent(notificationId))

        if (isWaitingForConnection) {
            builder.addAction(
                android.R.drawable.ic_popup_sync,
                "Reconnect",
                reconnectPendingIntent(notificationId, downloadKey, title, artist),
            )
        }
        val notification = builder
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelPendingIntent)
            .build()

        runCatching { notificationManager?.notify(notificationId, notification) }
    }

    private fun showCompletedNotification(
        notificationId: Int,
        title: String,
        artist: String,
        badgeText: String,
    ) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Download Complete")
            .setContentText("\"$title\" by $artist ($badgeText)")
            .setOngoing(false)
            .setAutoCancel(true)
            .setContentIntent(viewDownloadsPendingIntent(notificationId))
            .build()

        runCatching { notificationManager?.notify(notificationId, notification) }
    }

    private fun showErrorNotification(
        notificationId: Int,
        downloadKey: String,
        title: String,
        artist: String,
        error: String,
    ) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Download Failed")
            .setContentText("\"$title\" by $artist: $error")
            .setOngoing(false)
            .setAutoCancel(true)
            .setContentIntent(viewDownloadsPendingIntent(notificationId))
            .addAction(
                android.R.drawable.ic_popup_sync,
                "Reconnect",
                reconnectPendingIntent(notificationId, downloadKey, title, artist),
            )
            .build()

        runCatching { notificationManager?.notify(notificationId, notification) }
    }

    private fun viewDownloadsPendingIntent(requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = ACTION_VIEW_DOWNLOADS
            putExtra(EXTRA_NAVIGATE_TO, "downloads")
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun reconnectPendingIntent(
        requestCode: Int,
        downloadKey: String,
        title: String,
        artist: String,
    ): PendingIntent {
        val intent = Intent(context, DownloadCancelReceiver::class.java).apply {
            action = ACTION_RECONNECT_DOWNLOAD
            putExtra(EXTRA_DOWNLOAD_KEY, downloadKey)
            putExtra(EXTRA_DOWNLOAD_TITLE, title)
            putExtra(EXTRA_DOWNLOAD_ARTIST, artist)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun writePublicCompanionFile(
        filename: String,
        content: String,
        mimeType: String,
        dirName: String = PUBLIC_DIR_NAME,
        subpath: String = "",
        treeUri: Uri? = null,
    ): String? {
        val safeDir = sanitizeDownloadFolderName(dirName)
        val safeSubpath = subpath.split('/').map { sanitizeFilename(it.trim()) }
            .filter { it.isNotBlank() }.joinToString("/")
        // Custom SAF folder: keep the .lrc next to its track in the same
        // tree. Lyrics are optional, so failures degrade to null.
        if (treeUri != null) {
            return runCatching {
                val segments = safeSubpath.split('/').filter { it.isNotBlank() }
                val fileUri = SafTreeFiles.createFile(context, treeUri, segments, filename, mimeType)
                    ?: return@runCatching null
                val stream = context.contentResolver.openOutputStream(fileUri, "wt")
                    ?: return@runCatching null
                stream.use { os ->
                    os.write(content.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                fileUri.toString()
            }.getOrNull()
        }
        // Mirror the audio subfolder so .lrc sits next to its track. Note the
        // audio lives under Music/ while companions live under Downloads/.
        val lrcRelativePath = if (safeSubpath.isNotBlank()) {
            "${Environment.DIRECTORY_DOWNLOADS}/$safeDir/Music/$safeSubpath"
        } else {
            "${Environment.DIRECTORY_DOWNLOADS}/$safeDir/Music"
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver

                // Remove pre-existing companion file with the same name IN THE
                // SAME FOLDER to prevent (1).lrc duplicates.
                runCatching {
                    resolver.query(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        arrayOf(MediaStore.Downloads._ID),
                        "${MediaStore.Downloads.DISPLAY_NAME} = ? AND ${MediaStore.Downloads.RELATIVE_PATH} = ?",
                        arrayOf(filename, "$lrcRelativePath/"),
                        null,
                    )?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.Downloads._ID)
                        while (cursor.moveToNext()) {
                            val id = cursor.getLong(idCol)
                            val oldUri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id.toString())
                            runCatching { resolver.delete(oldUri, null, null) }
                        }
                    }
                }

                val contentValues = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, lrcRelativePath)
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                val uri = runCatching { resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues) }.getOrNull()
                if (uri != null) {
                    resolver.openOutputStream(uri, "wt")?.use { os ->
                        os.write(content.toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                    uri.toString()
                } else {
                    val fallbackBase = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
                        ?: File(context.filesDir, "lyrics").apply { if (!exists()) mkdirs() }
                    val fallbackDir = if (safeSubpath.isNotBlank()) File(fallbackBase, safeSubpath) else fallbackBase
                    if (!fallbackDir.exists()) fallbackDir.mkdirs()
                    val file = File(fallbackDir, filename)
                    file.writeText(content, Charsets.UTF_8)
                    file.absolutePath
                }
            } else {
                val musicBase = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), safeDir)
                val musicDir = if (safeSubpath.isNotBlank()) File(musicBase, safeSubpath) else musicBase
                if (!musicDir.exists()) musicDir.mkdirs()
                val file = File(musicDir, filename)
                file.writeText(content, Charsets.UTF_8)
                file.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }


    suspend fun deleteDownloadedTrack(track: DownloadedTrackEntity) = withContext(Dispatchers.IO) {
        downloadedTrackDao.delete(track)
        // Delete physical audio file
        if (!track.mediaStoreUri.isNullOrBlank()) {
            runCatching { context.contentResolver.delete(Uri.parse(track.mediaStoreUri), null, null) }
        }
        if (track.filePath.isNotBlank()) {
            runCatching {
                val f = File(track.filePath)
                if (f.exists()) f.delete()
            }
        }
        // Delete companion .lrc file if present
        if (!track.lrcFilePath.isNullOrBlank()) {
            if (track.lrcFilePath.startsWith("content://")) {
                runCatching { context.contentResolver.delete(Uri.parse(track.lrcFilePath), null, null) }
            } else {
                runCatching {
                    val lf = File(track.lrcFilePath)
                    if (lf.exists()) lf.delete()
                }
            }
        }
    }

    /**
     * Cancels in-flight downloads, waits until those workers finish, then deletes
     * each persisted audio file, lyric file, and content URI before removing that
     * row. A missing file is success. Permission errors and failed deletes keep
     * the row so a later wipe can retry, and they fail this call.
     * New [downloadTrack] calls are refused until the guard is released.
     */
    suspend fun clearAllDownloads() {
        val jobs = synchronized(admissionLock) {
            downloadsWiping = true
            activeJobs.values.toList()
        }
        // Ask workers to stop before the first suspension point so a caller
        // cancelled immediately after this still cannot race a new insert in.
        jobs.forEach { it.cancel() }
        try {
            withContext(Dispatchers.IO) {
                // Existing cancellation also drops partial MediaStore rows and files.
                cancelAllDownloads()
                jobs.forEach { job ->
                    job.cancel()
                    job.join()
                }
                val tracks = downloadedTrackDao.getAllList()
                val failed = ArrayList<DownloadedTrackEntity>(tracks.size)
                for (track in tracks) {
                    ensureActive()
                    if (deleteRecordedDownload(track)) {
                        downloadedTrackDao.delete(track)
                    } else {
                        failed += track
                    }
                }
                if (failed.isNotEmpty()) {
                    throw IOException("Failed to delete ${failed.size} downloaded track(s)")
                }
            }
        } finally {
            synchronized(admissionLock) {
                downloadsWiping = false
            }
        }
    }

    private suspend fun ensureDownloadStillAllowed() {
        currentCoroutineContext().ensureActive()
        if (downloadsWiping) throw CancellationException("Downloads are being cleared")
    }

    /** Queued worker cancelled before it acquired a download slot. */
    private fun forgetDownloadKey(key: String) {
        activeKeys.remove(key)
        activeJobs.remove(key)
        reconnectGenerations.remove(key)
        _downloads.update { it - key }
    }

    /** Worker that already holds a slot must release it exactly once. */
    private fun abandonAcquiredDownload(key: String) {
        runCatching { downloadSlots.release() }
        activeUris.remove(key)?.let { uri ->
            runCatching { context.contentResolver.delete(uri, null, null) }
        }
        activeFiles.remove(key)?.let { file ->
            runCatching { if (file.exists()) file.delete() }
        }
        forgetDownloadKey(key)
    }

    private fun deleteRecordedDownload(track: DownloadedTrackEntity): Boolean {
        val uriDeleted = deleteContentUriIfRecorded(track.mediaStoreUri)
        val audioDeleted = deleteFileIfRecorded(track.filePath)
        val lyricsDeleted = deleteFileIfRecorded(track.lrcFilePath)
        if (!uriDeleted || !audioDeleted || !lyricsDeleted) {
            android.util.Log.w(
                "TrackDownloadManager",
                "Kept download row for ${track.title} by ${track.artist}; deletion can be retried",
            )
        }
        return uriDeleted && audioDeleted && lyricsDeleted
    }

    private fun deleteFileIfRecorded(path: String?): Boolean {
        if (path.isNullOrBlank()) return true
        if (path.startsWith("content://")) return deleteContentUriIfRecorded(path)
        val file = File(path)
        if (!file.exists()) return true
        return try {
            file.delete() || !file.exists()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (security: SecurityException) {
            android.util.Log.w("TrackDownloadManager", "Couldn't delete download file $path", security)
            false
        }
    }

    private fun deleteContentUriIfRecorded(uriString: String?): Boolean {
        if (uriString.isNullOrBlank()) return true
        val uri = try {
            Uri.parse(uriString)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            return false
        }
        try {
            context.contentResolver.delete(uri, null, null)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: FileNotFoundException) {
            return true
        } catch (security: SecurityException) {
            android.util.Log.w("TrackDownloadManager", "Couldn't delete download uri $uriString", security)
            return false
        } catch (error: Exception) {
            android.util.Log.w("TrackDownloadManager", "Download uri delete failed for $uriString", error)
        }
        return !contentUriStillPresent(uri)
    }

    /** True when the provider can still open the URI, so the row must stay retryable. */
    private fun contentUriStillPresent(uri: Uri): Boolean = try {
        context.contentResolver.openInputStream(uri)?.use { true } ?: false
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: FileNotFoundException) {
        false
    } catch (_: IllegalArgumentException) {
        false
    } catch (_: SecurityException) {
        true
    } catch (_: Exception) {
        true
    }

    /**
     * One-time self-heal for libraries corrupted before counter-string
     * hardening ("15 ml listens", "Track 16", ... as artist, one album fanned
     * out into N single-track albums). Runs offline-first inside
     * [syncDownloadsFromStorage]: groups by album to restore the dominant real
     * artist without network, then best-effort re-resolves leftovers via
     * InnerTube. Never deletes user files, only fixes DB rows (and best-effort
     * file tags). Safe to run on every sync; no-ops when clean.
     */
    suspend fun repairCorruptedDownloadMetadata() = withContext(Dispatchers.IO) {
        val all = runCatching { downloadedTrackDao.getAllList() }.getOrNull().orEmpty()
        if (all.isEmpty()) return@withContext
        val corrupted = all.filter { ArtistHelper.isPlayCountOrStat(it.artist) }
        if (corrupted.isEmpty()) return@withContext

        // Offline pass: within each album, adopt the dominant non-stat artist.
        // This reunites "one album -> N artists/albums" without any network.
        val byAlbum = all.groupBy { it.album.trim().lowercase() }
        var fixedOffline = 0
        for (corrupt in corrupted.toList()) {
            val albumKey = corrupt.album.trim().lowercase()
            if (albumKey.isBlank() || albumKey == "singles") continue
            val siblings = byAlbum[albumKey].orEmpty()
            val dominant = siblings.map { it.artist.trim() }
                .filter { it.isNotBlank() && !ArtistHelper.isPlayCountOrStat(it) }
                .groupBy { it.lowercase() }
                .maxByOrNull { it.value.size }
                ?.value?.firstOrNull()
            if (dominant.isNullOrBlank()) continue
            val newKey = makeDownloadKey(corrupt.title, dominant)
            val clash = runCatching { downloadedTrackDao.findByTrackKey(newKey) }.getOrNull()
            try {
                if (clash != null && clash.id != corrupt.id) {
                    // Good row already holds the correct key; drop the dupe.
                    runCatching { downloadedTrackDao.delete(corrupt) }
                } else {
                    runCatching {
                        downloadedTrackDao.insert(
                            corrupt.copy(artist = dominant, trackKey = newKey),
                        )
                    }
                    // Best-effort file retag so external players / re-imports
                    // don't resurrect the counter string.
                    runCatching {
                        val f = File(corrupt.filePath)
                        if (f.exists() && f.isFile) {
                            audioTagWriter.embedMetadata(
                                audioFile = f,
                                title = corrupt.title,
                                artist = dominant,
                                album = corrupt.album.takeIf { it.isNotBlank() },
                                artworkUrl = corrupt.artworkUrl,
                                artworkFallbackUrl = null,
                                lyrics = corrupt.syncedLyrics ?: corrupt.plainLyrics,
                                year = null,
                            )
                        }
                    }
                }
                fixedOffline++
            } catch (_: Exception) { }
        }

        // Network pass for leftovers (no dominant sibling, or Singles/blank album).
        val remaining = runCatching { downloadedTrackDao.getAllList() }.getOrNull().orEmpty()
            .filter { ArtistHelper.isPlayCountOrStat(it.artist) }
            .take(25)
        for (corrupt in remaining) {
            try {
                val albumHint = corrupt.album.trim()
                    .takeUnless { ArtistHelper.isPlayCountOrStat(it) }.orEmpty()
                val match = runCatching {
                    if (albumHint.isNotBlank()) {
                        innerTube.findBestMatchOrNull(corrupt.title, albumHint, prefetchStreams = false)
                    } else {
                        innerTube.findBestMatchOrNull(corrupt.title, "", prefetchStreams = false)
                    }
                }.getOrNull() ?: continue
                val cleanArtist = match.artist.trim()
                    .takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                    ?.takeIf { it.isNotBlank() } ?: continue
                val cleanAlbum = match.album?.trim()
                    ?.takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                    ?.takeIf { it.isNotBlank() } ?: corrupt.album
                // Don't adopt a different song's metadata: title must still match.
                if (!match.title.equals(corrupt.title, ignoreCase = true) &&
                    match.title.lowercase().none { it in corrupt.title.lowercase() } &&
                    corrupt.title.lowercase().none { it in match.title.lowercase() }
                ) continue
                val newKey = makeDownloadKey(corrupt.title, cleanArtist)
                val clash = runCatching { downloadedTrackDao.findByTrackKey(newKey) }.getOrNull()
                if (clash != null && clash.id != corrupt.id) {
                    runCatching { downloadedTrackDao.delete(corrupt) }
                } else {
                    runCatching {
                        downloadedTrackDao.insert(
                            corrupt.copy(artist = cleanArtist, album = cleanAlbum, trackKey = newKey),
                        )
                    }
                    runCatching {
                        val f = File(corrupt.filePath)
                        if (f.exists() && f.isFile) {
                            audioTagWriter.embedMetadata(
                                audioFile = f,
                                title = corrupt.title,
                                artist = cleanArtist,
                                album = cleanAlbum.takeIf { it.isNotBlank() },
                                artworkUrl = corrupt.artworkUrl,
                                artworkFallbackUrl = match.artworkUrl,
                                lyrics = corrupt.syncedLyrics ?: corrupt.plainLyrics,
                                year = null,
                            )
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    suspend fun syncDownloadsFromStorage() = withContext(Dispatchers.IO) {
        runCatching { repairCorruptedDownloadMetadata() }
        val existingEntities = downloadedTrackDao.getAllList().toMutableList()
        val existingPaths = existingEntities.map { it.filePath }.toMutableSet()
        val existingUris = existingEntities.mapNotNull { it.mediaStoreUri }.toMutableSet()
        val existingKeys = existingEntities.map { makeDownloadKey(it.title, it.artist) }.toMutableSet()
        val dirName = currentDownloadDirName()

        // 1. Scan download directories on device (active folder + legacy default, incl. subfolders)
        val musicDirs = downloadSearchDirs(dirName).filter { it.exists() && it.isDirectory }
        val seenDirs = mutableSetOf<String>()
        val audioExtensions = setOf("flac", "m4a", "mp3", "opus", "ogg", "webm")
        for (musicDir in musicDirs) {
            if (!seenDirs.add(musicDir.absolutePath)) continue
            val audioFiles = musicDir.walkTopDown().maxDepth(6)
                .filter { file -> file.isFile && file.extension.lowercase() in audioExtensions }
                .toList()

            for (file in audioFiles) {
                if (file.absolutePath in existingPaths) continue

                val retriever = android.media.MediaMetadataRetriever()
                try {
                    retriever.setDataSource(file.absolutePath)
                    val rawTitle = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE)
                        ?.ifBlank { null } ?: file.nameWithoutExtension.substringAfter(" - ").ifBlank { file.nameWithoutExtension }
                    val rawArtist = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        ?.ifBlank { null } ?: file.nameWithoutExtension.substringBefore(" - ").ifBlank { "Unknown Artist" }
                    val rawAlbum = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
                    // Never import counter strings as metadata; fall back to
                    // filename/folder rather than "15 ml listens".
                    val title = rawTitle.trim().takeIf { it.isNotBlank() } ?: file.nameWithoutExtension
                    var artist = rawArtist.trim().takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                    if (artist.isNullOrBlank()) {
                        val parentName = file.parentFile?.name.orEmpty()
                        artist = parentName.takeUnless {
                            it.isBlank() || it.equals("Singles", ignoreCase = true) ||
                                it.equals(dirName, ignoreCase = true) ||
                                it.equals("Music", ignoreCase = true) ||
                                ArtistHelper.isPlayCountOrStat(it)
                        } ?: file.nameWithoutExtension.substringBefore(" - ")
                            .takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                        ?: "Unknown Artist"
                    }
                    artist = artist!!.trim().ifBlank { "Unknown Artist" }
                    val trackKey = makeDownloadKey(title, artist)
                    if (trackKey in existingKeys) continue

                    val album = rawAlbum.trim().takeUnless { ArtistHelper.isPlayCountOrStat(it) }.orEmpty()
                    val durStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                    val durMs = durStr?.toLongOrNull() ?: 0L
                    val bitRateStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE)
                    val bitrateKbps = bitRateStr?.toIntOrNull()?.let { it / 1000 }

                    val ext = file.extension.lowercase()
                    val badge = when (ext) {
                        "flac" -> "FLAC"
                        "m4a", "mp4", "aac" -> "M4A AAC"
                        "mp3" -> "320k MP3"
                        "opus", "ogg" -> "OPUS"
                        else -> "AUDIO"
                    }

                    val lrcFile = File(file.parentFile ?: musicDir, file.nameWithoutExtension + ".lrc")
                    val hasLyrics = lrcFile.exists() && lrcFile.length() > 0
                    val lrcText = if (hasLyrics) runCatching { lrcFile.readText() }.getOrNull() else null

                    val entity = DownloadedTrackEntity(
                        trackKey = trackKey,
                        title = title,
                        artist = artist,
                        album = album,
                        filePath = file.absolutePath,
                        fileSizeBytes = file.length(),
                        formatBadge = badge,
                        durationMs = durMs,
                        bitrateKbps = bitrateKbps,
                        isLossless = ext == "flac",
                        hasLyrics = hasLyrics,
                        syncedLyrics = if (lrcText?.contains("[") == true) lrcText else null,
                        plainLyrics = if (lrcText?.contains("[") != true) lrcText else null,
                        lrcFilePath = if (hasLyrics) lrcFile.absolutePath else null,
                        downloadedAtMillis = file.lastModified(),
                    )
                    downloadedTrackDao.insert(entity)
                    existingPaths.add(file.absolutePath)
                    existingKeys.add(trackKey)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (oom: OutOfMemoryError) {
                    // One corrupt/huge file's metadata must not abort the
                    // whole sync or kill the process — skip it.
                    android.util.Log.e("TrackDownloadManager", "Skipping file after OOM: ${file.name}", oom)
                } catch (e: Exception) {
                    android.util.Log.e("TrackDownloadManager", "Failed to import file: ${file.name}", e)
                } finally {
                    runCatching { retriever.release() }
                }
            }
        }

        // 2. Query MediaStore for items in the download folders (active + legacy)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.RELATIVE_PATH,
                MediaStore.Audio.Media.DATE_ADDED,
            )
            val selection: String
            val selectionArgs: Array<String>
            if (dirName != LEGACY_PUBLIC_DIR_NAME) {
                selection = "(${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?)"
                selectionArgs = arrayOf("Music/$dirName%", "Music/$LEGACY_PUBLIC_DIR_NAME%")
            } else {
                selection = "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?"
                selectionArgs = arrayOf("Music/$dirName%")
            }

            runCatching {
                context.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    selectionArgs,
                    null,
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                        if (uri.toString() in existingUris) continue

                        val rawTitle = cursor.getString(titleCol) ?: "Unknown Track"
                        val rawArtist = cursor.getString(artistCol) ?: "Unknown Artist"
                        val rawAlbum = cursor.getString(albumCol).orEmpty()
                        val title = rawTitle.trim().takeIf { it.isNotBlank() } ?: "Unknown Track"
                        val artist = rawArtist.trim()
                            .takeUnless { ArtistHelper.isPlayCountOrStat(it) }
                            ?.takeIf { it.isNotBlank() } ?: "Unknown Artist"
                        val trackKey = makeDownloadKey(title, artist)
                        if (trackKey in existingKeys) continue

                        val album = rawAlbum.trim()
                            .takeUnless { ArtistHelper.isPlayCountOrStat(it) }.orEmpty()
                        val durMs = cursor.getLong(durCol)
                        val size = cursor.getLong(sizeCol)
                        val mime = cursor.getString(mimeCol).orEmpty().lowercase()
                        val date = cursor.getLong(dateCol) * 1000L

                        val isFlac = mime.contains("flac")
                        val isM4a = mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac")
                        val isMp3 = mime.contains("mp3") || mime.contains("mpeg")
                        val isOpus = mime.contains("opus") || mime.contains("ogg")

                        val badge = when {
                            isFlac -> "FLAC"
                            isM4a -> "M4A AAC"
                            isMp3 -> "320k MP3"
                            isOpus -> "OPUS"
                            else -> "AUDIO"
                        }

                        val entity = DownloadedTrackEntity(
                            trackKey = trackKey,
                            title = title,
                            artist = artist,
                            album = album,
                            filePath = uri.toString(),
                            mediaStoreUri = uri.toString(),
                            fileSizeBytes = size,
                            formatBadge = badge,
                            durationMs = durMs,
                            isLossless = isFlac,
                            downloadedAtMillis = if (date > 0) date else System.currentTimeMillis(),
                        )
                downloadedTrackDao.insert(entity)
                        existingUris.add(uri.toString())
                        existingKeys.add(trackKey)
                    }
                }
            }
        }
    }

    private fun com.lastwave.app.data.music.YouTubeAudioStream.isOpusStream(): Boolean {
        val m = mimeType.orEmpty().lowercase()
        return m.contains("webm") || m.contains("ogg") ||
            codec.orEmpty().contains("opus", ignoreCase = true)
    }

    private fun sanitizeFilename(title: String): String =
        title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "track" }
}
